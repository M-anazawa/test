
ChatGPTから次の指摘がありました
内容に確認し、指摘が正しければ修正をお願いします

### ChatGPT指摘事項
全体としてかなり整理されています。
このままでも大枠は問題ありませんが、Terraform 用のサービスプリンシパル認証まわりでは、3点だけ修正した方がよいです。Databricks では OAuth M2M に DATABRICKS_HOST、DATABRICKS_CLIENT_ID、DATABRICKS_CLIENT_SECRET を使い、アカウント API では DATABRICKS_ACCOUNT_ID も使います。DATABRICKS_HOST は account では https://accounts.cloud.databricks.com、workspace では workspace URL を使います。

1つ目の修正点は、Workspace-level SP の権限要件です。
設計書では 40-dbx-uc-s12 用の Workspace-level SP に「Workspace admin」とありますが、Storage Credential / External Location の作成に必要なのは Unity Catalog 側の権限です。Databricks の公式ドキュメントでは、external location 作成には CREATE STORAGE CREDENTIAL と CREATE EXTERNAL LOCATION が必要で、metastore admin にはこれらが既定で付与されます。つまり、Workspace admin だけでは不十分な可能性があるため、設計書の表は「Workspace admin」ではなく、少なくとも「metastore admin または必要な UC 権限を付与された SP」に直した方が安全です。

2つ目の修正点は、“Workspace-level 用 OAuth secret” という表現です。
サービスプリンシパルの OAuth secret は SP に属する秘密情報であり、workspace 専用の別種 secret ではありません。Databricks では service principal に secret を生成し、その SP を workspace に割り当てて使います。したがって、22.6 の「Workspace-level用のOAuth secretを生成」は技術的には誤りではないものの、“workspace 用に別 secret を追加発行する運用” と読めます。実際には、同一 SP の既存 secret を再利用してもよく、分離したい場合だけ別 secret を発行する、という書き方にした方が正確です。Databricks では SP を workspace に割り当てられ、secret は生成時に 1〜730 日の lifetime を設定し、画面を離れると再表示できません。

3つ目の修正点は、SP を2つに分ける理由を明文化することです。
今の設計は
・Account-level SP
・Workspace-level SP
の2SP分離ですが、これは可能です。ただし Databricks の OAuth M2M 自体は、1つの SP を account admin にし、必要な workspace に割り当てて再利用する構成でも成立します。なので、現状の設計を採るなら、
「権限分離・誤操作防止・secret ローテーション影響範囲の分離のため 2SP 構成を採用する」
と明記すると、設計意図がより明確になります。workspace に割り当てられていない SP は workspace API で 403 になり得ます。

そのうえで、良い点もあります。
Secrets Manager に account 用と workspace 用を分ける方針は、誤投入防止として妥当です。OAuth M2M を使う方針も Databricks の推奨に沿っています。

修正文のイメージだけ挙げると、22.3 は次のようにすると通りが良いです。
・Account-level SP: 30-dbx-account-s12, 40-dbx-account-s00 用。Account admin
・Workspace-level SP: 50-dbx-uc-s12 用。workspace へ割り当て済みで、metastore admin または CREATE STORAGE CREDENTIAL / CREATE EXTERNAL LOCATION 等の必要な Unity Catalog 権限を付与

22.6 は次の方向がよいです。
・対象 workspace に SP を割り当てる
・必要に応じて 同一 SP に対して 追加の OAuth secret を生成する
・既存 secret を再利用する運用でも可

レビュー結果としては、大枠OK、ただし 22.3 と 22.6 の表現は修正推奨です。
