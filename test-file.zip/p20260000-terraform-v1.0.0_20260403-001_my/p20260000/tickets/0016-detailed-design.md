
ChatGPTから次の指摘がありました
内容に確認し、指摘が正しければ修正をお願いします

### ChatGPT指摘事項

1. 20.7「メタストア作成」の順序説明が、公式ドキュメントと少しズレています。
Databricks の公式では、メタストア作成時にワークスペースをアタッチする流れが案内されており、Create metastore and attach a workspace という手順になっています。したがって、設計書の「WS 作成前にメタストアを作成する必要がある」という断定は、少し言い切りすぎです。実務上は「明示的に作成・割当したいので先に作る設計」なら問題ありませんが、文言は「必要がある」ではなく「自動作成を避け、構成を明示管理するため先行作成する方針」に直す方が安全です。

3. 20.7.2 / 22.3 の権限説明に不整合があります。
22.3 では Workspace-level SP の Databricks 権限が Workspace admin + メタストア owner となっていますが、20.7.2 では「SP は account-level / workspace-level で同一 SP を共用」と書かれています。つまり現在の設計は、2SP構成ではなく1SP共用構成です。ここはどちらかに統一した方がよいです。今の本文だと、過去の 2SP 案と 1SP 共用案が混ざっています。

4. 22.3 の Workspace-level SP 権限を Account admin と書いている点は、設計意図の説明不足です。
公式には、Account admin は metastore 作成や metastore admin 割当が可能で、metastore admin は metastore 上の CREATE STORAGE CREDENTIAL や CREATE EXTERNAL LOCATION などを持ちます。一方、Workspace admin は通常のワークスペース管理権限であり、Unity Catalog のメタストア権限とは別です。したがって、Workspace 側で使う SP に Account admin を持たせるのは成立はするが強すぎるため、本文に「今回の実装簡素化のため同一 SP を共用し、Account admin を保持させる」のか、「理想は metastore admin + workspace admin に寄せる」のかを明示した方がよいです。

5. 20.7.4 のメタストア権限付与は概ね正しいですが、表現を少し補強した方がよいです。
CREATE STORAGE CREDENTIAL と CREATE EXTERNAL LOCATION は metastore 上の権限です。また、storage credential を使って external location を作るには、メタストア権限だけでなく、対象 storage credential 側の利用権限も必要です。ここは以前より改善されていますが、表に「external location 作成には metastore 権限 + storage credential 利用権限の両方が必要」と明記するとさらに誤読が減ります。

8. 5章の構築順序と 20.7 の説明は、今の Terraform 実装方針に合わせて少しだけ明文化した方がよいです。
今の文章だと「20. メタストア作成 → 21. ワークスペース作成 → 22. 割当」と見えますが、20.7 では workspace_id が必要な databricks_metastore_assignment を同一 apply 内の依存で後段実行すると説明しています。ここは、5章でも「同一 stack 内で Terraform dependency により順次作成」と1行入れると、読み手が迷いません。

