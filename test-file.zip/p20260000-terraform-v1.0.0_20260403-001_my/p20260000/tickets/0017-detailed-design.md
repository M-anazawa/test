
ChatGPTから次の指摘がありました
内容に確認し、指摘が正しければ修正をお願いします

### ChatGPT指摘事項

1. 20.7 の「WS 作成前にメタストアを先行作成する方針」は、今の Databricks の自動有効化仕様と少し緊張関係があります。
Databricks では、2023-11-08 以降に作成される workspace は Unity Catalog が自動有効化されるケースがあり、アカウントやリージョン状況によっては metastore の自動プロビジョニングや自動割当の挙動があります。したがって、今の文面は「必須」ではなく、“自動作成・自動割当への依存を避け、構成を明示管理するため先行作成を採用する” と書くのがより正確です。

2. 20.5 の databricks_mws_storage_configurations に role_arn を持たせる記述は、採用する実装方式を明記した方が安全です。
手動 AWS 構成で Unity Catalog 対応 workspace を作る公式手順では、storage configuration 作成時に role_arn を指定する流れがあります。なので、設計書の記載自体は不自然ではありません。
ただ、本文のままだと 「ルートストレージアクセスに cross-account role ではなく UC ストレージロールを使う」 と読めます。一方で、workspace 作成系の AWS 認証全体では cross-account credentials も別途使っています。ここは、
“workspace storage configuration 用の S3 アクセスロールとして role_storage を指定する設計”
と一段明示した方が誤解が減ります。

