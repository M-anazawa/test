
ChatGPTから次の6つ指摘がありました
内容に確認し、指摘が正しければ追記・修正をお願いします

1) 「STS/Kinesis VPCEはpriend-snに集約」なのに、ドキュメント内で“要件参照がオプション1/2で混線”している
あなたの15.6の説明は良いのですが、前段（15.4/15.5）が オプション1の読み方を前提にしている読者だと混乱します。
Databricks公式は以下のように書き分けています。
Option 1（推奨）：STS/Kinesis は 全workspace subnetsに作成し、workspace SGにアタッチ
Option 2（厳格エアギャップ）：AWS endpoints subnet（あなたの priend 相当）に作成
あなたは Option 1（NFW→RNAT→IGW あり）を採用しつつ、STS/Kinesisは “集中配置（AWS endpoints subnet相当）”にしているので、**設計としては「Option 1＋集中エンドポイント構成」**です。

修正案（文章の明確化）
15.6の冒頭を次のように明記するのが安全です：
「本構成は Option 1（NAT/IGWあり）を採用する。ただし STS/Kinesis は集中エンドポイント構成として 

AWS endpoints subnet（priend）に集約する」
これでレビュー時の突っ込みが減ります。

2) 15.6 検証手順の「KinesisのDNS名」が誤り
あなたの検証手順で：
nslookup kinesis.ap-northeast-1.amazonaws.com
となっていますが、あなた自身のVPCEサービス名は com.amazonaws.ap-northeast-1.kinesis-streams です（15.5）。
この場合、検証対象のFQDNは kinesis-streams.ap-northeast-1.amazonaws.com 側に寄せるのが整合します（DatabricksのPrivateLink手順でも “kinesis-streams” を使っています）。

修正案
手順 3 を nslookup kinesis-streams.ap-northeast-1.amazonaws.com に変更

3) SG設計：3306 を「UCなので不要」と断定しているのは危険（表現を弱める）
あなたのNOTE：
Unity Catalogを使用しておりビルトインHive Metastoreへの接続は不要のため、TCP/3306は設定しません。
しかし Databricksの customer-managed VPC 要件には 3306 が要件として載っており、用途は “メタストア関連（レガシーHMS等）”の文脈で語られます。
UC運用でも環境や機能によって「3306不要」と言い切れないケースが出るため、設計書としては “不要と判断した根拠＋影響範囲＋代替策” の形で書く方が安全です。

修正案（おすすめの書き方）

「本構成ではUnity Catalogを使用し、DBFS mounts等でHMS/3306が必要となる機能は使用しない前提のため、3306は閉じる。将来DBFS mountsやレガシー機能を使う場合は3306を許可する」

こう書けば監査・将来拡張でも破綻しにくいです。

4) sg-002（VPCE用SG）のアウトバウンド「全許可」は残してOKだが、書き方を整える
Databricksは「エンドポイントSGに送信規則は不要」と明記しています。
あなたの注記は良いのですが、表の“全許可”と、注記の“削除を検討”が少しチグハグです。

修正案
「初期はAWSデフォルト（全許可）を維持。監査要件に応じて削除」

5) STS/Kinesis VPCE を priend-sn に置くなら「RTはlocalだけでOK」だが、検証観点をもう1つ追加すると良い
priend-sn のRTが local だけ、というのは Databricksの「エンドポイント用サブネットはローカルルートのみでよい」説明と一致しておりOKです。
ただし集中構成の場合、実際にハマるのは「DNSはVPCEのIPを返すが、SGで詰まる」なので、検証に
curl -v https://kinesis-streams.ap-northeast-1.amazonaws.com/
または “簡単なSDK call”（ListStreams等）
を足すと、実運用で助かります。

6) 追加で1点だけ（Regional NATの記述）
RNATの説明は概ねOKですが、AWS公式では「作成するとAWSがRNAT用ルートテーブルを自動作成し、IGWへの経路が事前設定される」ことが明記されています。
設計書のNOTEにこの文言を入れておくと、後工程で「public subnetが無いのにどうやってIGWへ？」の質問が減ります。

