
ストレージ構成用IAMロールの信頼ポリシー設定について
ChatGPTから次の提案がありました
内容に確認し、提案が正しければ「公式どおりの2段階更新」に修正をお願いします
必要に応じて「develop.md」への手順の反映もお願いします

### ChatGPT提案
Terraformでの2段階更新の具体例は、いちばん確実なのは 2回 apply する方式です。
Databricks公式は、AWS IAM ロールを最初は 仮の trust policy（placeholder external ID） で作成し、その後 storage credential の external ID を使って trust policy を更新し、self-assuming にする手順を案内しています。さらに、Databricks は self-assuming でない IAM ロールをブロックします。
以下は、あなたの構成に寄せた 実装しやすい Terraform 例です。

実装方針
1回目 apply
・IAM role を placeholder external ID (0000) で作成
・databricks_storage_credential を作成
2回目 apply
・storage credential で得た actual external ID を tfvars などに入れる
・IAM role の trust policy を 最終版 に更新
    ・UCMasterRole
    ・self-assume
    ・actual external ID
これは Databricks公式の流れと整合しています。

例1: 変数定義
04-variables.tf
variable "account_id" {
  type = string
}

variable "databricks_account_id" {
  type = string
}

variable "databricks_unity_catalog_role_arn" {
  type = string
}

variable "storage_role_name" {
  type = string
}

variable "storage_credential_name" {
  type = string
}

# 1回目 apply では "0000"
# 2回目 apply では Databricks 側で作成された actual external ID を入れる
variable "storage_credential_external_id" {
  type    = string
  default = "0000"
}

# false = 1回目 apply（仮trust）
# true  = 2回目 apply（self-assuming + actual external id）
variable "enable_self_assume" {
  type    = bool
  default = false
}

例2: trust policy を段階的に切り替える
19-iam-storage.tf
locals {
  storage_role_arn = "arn:aws:iam::${var.account_id}:role/${var.storage_role_name}"

  storage_trust_policy = {
    Version = "2012-10-17"
    Statement = concat(
      [
        {
          Sid    = "UCMasterRoleAssumeRole"
          Effect = "Allow"
          Principal = {
            AWS = var.databricks_unity_catalog_role_arn
          }
          Action = "sts:AssumeRole"
          Condition = {
            StringEquals = {
              "sts:ExternalId" = var.storage_credential_external_id
            }
          }
        }
      ],
      var.enable_self_assume ? [
        {
          Sid    = "SelfAssumeRole"
          Effect = "Allow"
          Principal = {
            AWS = local.storage_role_arn
          }
          Action = "sts:AssumeRole"
          Condition = {
            StringEquals = {
              "sts:ExternalId" = var.storage_credential_external_id
            }
          }
        }
      ] : []
    )
  }
}

resource "aws_iam_role" "storage" {
  name               = var.storage_role_name
  assume_role_policy = jsonencode(local.storage_trust_policy)
}

resource "aws_iam_role_policy" "storage_s3" {
  name = "${var.storage_role_name}-policy"
  role = aws_iam_role.storage.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "s3:GetObject",
          "s3:PutObject",
          "s3:DeleteObject"
        ]
        Resource = "arn:aws:s3:::p20250022-de01-s12-bucket-data-001/unity-catalog/*"
      },
      {
        Effect = "Allow"
        Action = [
          "s3:ListBucket",
          "s3:GetBucketLocation"
        ]
        Resource = "arn:aws:s3:::p20250022-de01-s12-bucket-data-001"
      }
    ]
  })
}

例3: Databricks storage credential 作成
30-storage-credential.tf
resource "databricks_storage_credential" "storage" {
  name = var.storage_credential_name

  aws_iam_role {
    role_arn = aws_iam_role.storage.arn
  }

  comment = "Unity Catalog storage credential for S3"
}
Databricks公式では、storage credential 作成後に 表示された trust policy / external ID を使って IAM trust policy を更新します。

1回目 apply の tfvars 例
dev.dbx-uc-s12.tfvars
account_id                       = "139139346694"
databricks_account_id            = "c7324012-9ae2-4541-a75d-3f0a0d213d4a"
databricks_unity_catalog_role_arn = "arn:aws:iam::414351767826:role/unity-catalog-prod-UCMasterRole-14S5ZJVKOTYTL"

storage_role_name        = "p20250022-de01-s12-role-storage-001"
storage_credential_name  = "p20250022-de01-s12-storagecred-001"

storage_credential_external_id = "0000"
enable_self_assume             = false

1回目 apply 後にやること
1. Databricks で作成された storage credential を確認
2. external ID を取得
3. 2回目 apply 用に tfvars を更新
Databricks公式は、この external ID を trust policy に反映し、さらに self-assuming に更新するよう案内しています。

2回目 apply の tfvars 例
account_id                       = "139139346694"
databricks_account_id            = "c7324012-9ae2-4541-a75d-3f0a0d213d4a"
databricks_unity_catalog_role_arn = "arn:aws:iam::414351767826:role/unity-catalog-prod-UCMasterRole-14S5ZJVKOTYTL"

storage_role_name        = "p20250022-de01-s12-role-storage-001"
storage_credential_name  = "p20250022-de01-s12-storagecred-001"

storage_credential_external_id = "実際の_external_id"
enable_self_assume             = true

この方式の最終 trust policy イメージ
2回目 apply 後は、最終的に次のような形になります。
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "UCMasterRoleAssumeRole",
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::414351767826:role/unity-catalog-prod-UCMasterRole-14S5ZJVKOTYTL"
      },
      "Action": "sts:AssumeRole",
      "Condition": {
        "StringEquals": {
          "sts:ExternalId": "実際の_external_id"
        }
      }
    },
    {
      "Sid": "SelfAssumeRole",
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::139139346694:role/p20250022-de01-s12-role-storage-001"
      },
      "Action": "sts:AssumeRole",
      "Condition": {
        "StringEquals": {
          "sts:ExternalId": "実際の_external_id"
        }
      }
    }
  ]
}
これは Databricks公式の最終形と同じ考え方です。

運用しやすくするコツ
コツ1
enable_self_assume をフラグにしておくと、
1回目 apply / 2回目 apply の切り替えが分かりやすいです。

コツ2
storage_credential_external_id を tfvars 管理にすると、
後から見ても “いま仮IDか、本番IDか” が分かります。

コツ3
あなたの repo なら、これを 50-dbx-uc-s12 stack で管理するのが自然です。

注意
Databricks公式は、最終的に Validate Configuration で自己 Assume Role を含む設定確認を推奨しています。
2回目 apply 後は、Databricks 側で validation を実施する運用にしておくのが安全です。
