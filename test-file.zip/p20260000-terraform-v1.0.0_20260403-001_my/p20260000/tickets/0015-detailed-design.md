
ChatGPTから次の指摘がありました
内容に確認し、指摘が正しければ修正をお願いします

### ChatGPT指摘事項

2. 20.7 メタストア作成 の owner / 権限設計がまだ少し危ういです

設計書では同一SPを account / workspace で共用し、メタストア owner にして bootstrap する思想に寄せていますが、Databricks公式では metastore admin は workspace admin と別物で、workspace admin だけでは足りない権限がある と明記されています。さらに、外部ロケーション作成には metastore と storage credential の両方に CREATE EXTERNAL LOCATION が必要です。したがって、22.3 と 20.7.4 では「Workspace API を叩く主体」と「Unity Catalog 上の権限主体」を分けて明文化した方がよいです。今のままだと、実装者が「workspace admin だから十分」と誤解する余地があります。


