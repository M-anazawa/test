
ChatGPTから次の指摘がありました
内容に確認し、指摘が正しければ修正をお願いします

### ChatGPT指摘事項

重要な不備・不整合

1. 構築順序とメタストア割り当ての順番が矛盾しています

   5. 構築順序 では Phase 3 に
   20. Databricksにメタストア作成・割り当て
   が入っていますが、20.7.1 メタストア割り当て では workspace_id が必要です。
   一方、ワークスペース作成は Phase 4 の 22 です。
   つまり、現状の手順ではメタストア割り当てを先に実行できません。
   修正方針は次のどちらかです。
   ・Phase 3 では メタストア作成のみ
   ・Phase 4 で ワークスペース作成後にメタストア割り当て
   この形が最も自然です。

2. メタストア owner の考え方が文書内で揺れています

    20.7 メタストア作成 では
    ・owner = Workspace-level SP（Application ID）
    となっていますが、20.7.2 では
    ・メタストア作成・割当は account-level SP 管理
    と書かれています。
    さらに 22.3 では
    ・Account-level SP はメタストア関連のアカウント操作
    ・Workspace-level SP は Storage Credential / External Location / 権限付与
    になっています。
    このため、owner を誰にするかの設計意図が不明確です。
    おすすめは次のどちらかに統一です。
    案A: owner も account-level SP に統一
    案B: owner は専用の管理グループにする
    今の記述のままでは、実装担当が迷います。

3. グループ名の表記が不一致です

    20.7.3 では実際のグループ名が
    ・p20250022-de01-s12-users_group-001
    ・p20250022-de01-s12-users_group-002
    となっている一方、20.7.4 メタストア権限付与 では
    ・lykeion_users
    ・terumo_users
    という別名で書かれています。
    このままだと、Terraform の principal 名で迷うので、どちらかに統一した方がよいです。
    設計書としては、
    ・表示名
    ・Terraform 上の実名
    ・grants で使う principal 名
    を揃えるのが安全です。

4. 20.7.4 の権限付与主体が少し危ういです

    20.7.4 では metastore grants を 50-dbx-workspace-s12 側で実施する前提ですが、
    その前提として
    ・メタストアが workspace に割り当て済み
    ・Workspace-level SP がその workspace に入っている
    ・その SP 自身に metastore に対する十分な権限がある
    が必要です。
    つまり、初回の grants 付与のブートストラップを誰が行うかを一言入れた方がよいです。
    例えば次の補足があると明確です。
    ・初回メタストア owner / 初期 grants は account-level SP で実施
    ・以後の workspace 配下オブジェクト管理を workspace-level SP に委譲

中程度の改善ポイント

5. 「Workspace root storage はワークスペース単位」と「bucket-data-001 を共有」の関係を明記した方がよいです

    設計思想としては問題ありません。
    ただ、本文だけ読むと
    ・root storage はワークスペース単位で分離
    ・data バケットは 1 セキュリティレベル 1 バケット
    なので、一瞬ぶれます。
    実際には
    ・バケットは共有
    ・prefix は workspace 単位で分離
    という意味なので、それを 2.3 か 17章に一文入れると誤読が減ります。

6. UC managed storage location の実装位置をもう少し明示した方がよいです

    現状は
    ・metastore-level storage は未使用
    ・catalog または schema レベルで managed storage location を設定
    という方針は書けています。
    ただ、現時点の構築ゴールがどこまでかを明確にした方がよいです。
    たとえば次のどちらかを明記するとよいです。
    ・今回は metastore 作成と assignment まで。catalog/schema 作成は別設計
    ・今回は s12 用 catalog 作成と managed location 設定まで含む
    今の文面だと、managed storage location の本実装が今回範囲か将来範囲かが少し曖昧です。

軽微な改善ポイント

8. 4章の見出しは今のままで問題ありません

    ユーザー要望どおり resource list はまとまっていて見やすいです。
    このままで大丈夫です。

9. 22.3 の Workspace-level SP 権限はもう一段だけ具体化するとよいです

今は
・Workspace admin + Unity Catalog 必要権限
ですが、実装者向けには
・metastore に対する CREATE STORAGE CREDENTIAL
・metastore に対する CREATE EXTERNAL LOCATION
・対象 storage credential に対する CREATE EXTERNAL LOCATION 利用権限
のように、必要条件を一行添えるとさらに親切です。
