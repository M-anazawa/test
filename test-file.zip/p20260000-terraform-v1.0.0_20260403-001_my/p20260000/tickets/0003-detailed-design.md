
1. **p20250022-de01-s12-sg-001**のアウトバウンドにTCP 2443も追加してください

2. **p20250022-de01-s12-sg-002**のインバウンドにTCP 2443も追加してください

3. ストレージロール（UC S3アクセス用）に次のポリシーも追加した方が良いかと思いますが、再度確認し必要があれば追加してください
ドキュメント：https://docs.databricks.com/aws/en/admin/workspace/create-uc-workspace#step-3-create-an-iam-policy-to-grant-read-and-write-access

**ポリシー: p20250022-de01-s12-policy-storage-002**
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "ManagedFileEventsSetupStatement",
      "Effect": "Allow",
      "Action": [
        "s3:GetBucketNotification",
        "s3:PutBucketNotification",
        "sns:ListSubscriptionsByTopic",
        "sns:GetTopicAttributes",
        "sns:SetTopicAttributes",
        "sns:CreateTopic",
        "sns:TagResource",
        "sns:Publish",
        "sns:Subscribe",
        "sqs:CreateQueue",
        "sqs:DeleteMessage",
        "sqs:ReceiveMessage",
        "sqs:SendMessage",
        "sqs:GetQueueUrl",
        "sqs:GetQueueAttributes",
        "sqs:SetQueueAttributes",
        "sqs:TagQueue",
        "sqs:ChangeMessageVisibility",
        "sqs:PurgeQueue"
      ],
      "Resource": ["arn:aws:s3:::<BUCKET>", "arn:aws:sqs:*:*:*", "arn:aws:sns:*:*:*"]
    },
    {
      "Sid": "ManagedFileEventsListStatement",
      "Effect": "Allow",
      "Action": ["sqs:ListQueues", "sqs:ListQueueTags", "sns:ListTopics"],
      "Resource": "*"
    },
    {
      "Sid": "ManagedFileEventsTeardownStatement",
      "Effect": "Allow",
      "Action": ["sns:Unsubscribe", "sns:DeleteTopic", "sqs:DeleteQueue"],
      "Resource": ["arn:aws:sqs:*:*:*", "arn:aws:sns:*:*:*"]
    }
  ]
}

4. 監査ログ設計 (s00)の信頼ポリシーとIAMポリシーの内容がドキュメントと異なると思われるため、もう一度確認してください
ドキュメント：https://docs.databricks.com/aws/en/admin/account-settings-e2/audit-aws-credentials

5. WS(Notebook)から「p20250022-de01-s12-bucket-input-001」と「p20250022-de01-s12-bucket-output-001」にアクセスするための設定が漏れていないか確認してください

