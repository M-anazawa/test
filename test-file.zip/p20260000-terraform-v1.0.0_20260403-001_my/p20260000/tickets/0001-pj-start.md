これから次の内容で設計を開始してください
まずはアーキ図をmdファイルで作成してください
p20260000配下に設計書用フォルダを作成し、全ての設計書をそこに保存してください
プロジェクトを進めていくなかで問題点が発生した場合は、自動で改善されるようにしてください

# 既存ドキュメント
- リポジトリ構成は `docs/repository.md` を参照
- Terraform 実装方針は `docs/coding-rules.md` を参照

# 前提条件
- フロントエンド（UI）はパブリックアクセス
- バックエンド（Control Plane ↔ Compute Plane）はAWS PrivateLink 接続
- セカンダリリージョン（DR）は使用しない

# 構成
-----------------------------------------
ユーザー
↕　Public
コントロールプレーン
↕　PrivateLink
コンピュートプレーン:Customer-managed VPC
-----------------------------------------

## VPC
VPC CIDR : 10.0.0.0/16

## IGW

## Regional NAT

## Network Firewall

## Subnet
WS用サブネット AZ:1a : 10.0.0.0/20
WS用サブネット AZ:1c : 10.0.16.0/20
WS用サブネット AZ:1d : 10.0.32.0/20
エンドポイント用サブネット AZ:1a : 10.0.240.0/24
エンドポイント用サブネット AZ:1c : 10.0.241.0/24
エンドポイント用サブネット AZ:1d : 10.0.242.0/24
Network Firewall用サブネット AZ:1a : 10.0.243.0/28
Network Firewall用サブネット AZ:1c : 10.0.243.16/28
Network Firewall用サブネット AZ:1d : 10.0.243.32/28

## VPCE
S3用(Gateway)
WS用(Interface)
SCC用(Interface)
STS用(Interface)
Kinesis用(Interface)

## SG
WS用
Network Firewallエンドポイント用
VPCエンドポイント用（Network Firewallエンドポイント以外）

## S3
Unity Catalog用(SSE-S3)
Input用(SSE-S3)
Output用(SSE-S3)

## IAMロール/ポリシー
資格情報構成用
ストレージ構成用

# フロー

## WS操作
WS利用者(顧客)
↓ public
WS

## データ入力-1
WS利用者(顧客):terraform管理外S3アクセス用IAMユーザ
↓ public
Input用S3

## データ入力-2
インターネット上のクラウド等のリソース
↓ public(IGW,FW,NAT経由)
Notebook

## データ出力
WS利用者(顧客):terraform管理外S3アクセス用IAMユーザ
↑ public
Output用S3

## Notebook
Input用S3
↓
Notebook処理
↓
Output用S3
