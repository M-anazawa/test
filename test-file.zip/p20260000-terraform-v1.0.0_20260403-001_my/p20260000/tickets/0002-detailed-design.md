今度は詳細設計書をmdファイルで作成してください
ゴールはWSを作成し、ユーザを追加するまでです。ただしユーザ追加はterraform管理外
設計する上で私からの情報提供が必要なものがあれば教えてください

# 考慮事項
- root storage/UC managed tables用S3は 1VPC に1つ作成し、複数WS/カタログで共有します
- 今回はセキュルティレベル:s12のVPCのみ構築します
- 将来的にはセキュルティレベルの異なるVPCが幾つか増える可能性があります 
- まずは1つのWSを作成しますが、将来的には増える可能性があります
- システムテーブル監査ログ（Assets Audit）のS3への保存設定を行うこと（Audit log delivery）保存期間２年
- システムテーブル監査ログ用リソースはセキュルティレベル:s00
- VPC/サブネット/SG/FW/VPCE/IGW/NAT/S3/IAMロール/ポリシーはセキュルティレベル毎に準備する
- us-west-2のSTSエンドポイントアクティブ化
- ネットワークACLでは制御しない

# リソース名（dev用）
※不足しているものがあれば教えてください

- VPC
    p20250022-de01-s12-vpc-001

- サブネット
    p20250022-de01-s12-vpc-001-priws-sn-1a-001
    p20250022-de01-s12-vpc-001-priws-sn-1c-001
    p20250022-de01-s12-vpc-001-priws-sn-1d-001

    p20250022-de01-s12-vpc-001-priend-sn-1a-001
    p20250022-de01-s12-vpc-001-priend-sn-1c-001
    p20250022-de01-s12-vpc-001-priend-sn-1d-001

    p20250022-de01-s12-vpc-001-prifw-sn-1a-001
    p20250022-de01-s12-vpc-001-prifw-sn-1c-001
    p20250022-de01-s12-vpc-001-prifw-sn-1d-001

- リージョナルNAT
    p20250022-de01-s12-vpc-001-rnat

- VPCエンドポイント
    p20250022-de01-s12-vpce-001から順番に付与

- セキュリティグループ
    p20250022-de01-s12-sg-001から順番に付与

- IAMロール
    p20250022-de01-s12-role-crossaccount-001
    p20250022-de01-s00-role-auditlogs-001(監査ログ用)

- IAMポリシー
    p20250022-de01-s12-policy-crossaccount-001
    p20250022-de01-s00-policy-auditlogs-001(監査ログ用)

- S3
    p20250022-de01-s12-bucket-data-001(root storage/UC managed table用)
    p20250022-de01-s12-bucket-input-001
    p20250022-de01-s12-bucket-output-001
    p20250022-de01-s00-bucket-auditlogs-001(監査ログ用)

- Databricks ワークスペース名
    p20250022-de01-s12-ws-001

- Databricks PrivateLinkオブジェクト名
    p20250022-de01-s12-vpce-001から順番に付与

- Databricks ネットワークオブジェクト名
    p20250022-de01-s12-vpc-001-priws-sn-001

- Databricks プライベートアクセスオブジェクト名
    p20250022-de01-s12-privateaccess-001

- Databricks 資格情報名
    p20250022-de01-s12-credentialconf-001
    p20250022-de01-s00-credentialconf-001(監査ログ用)

- Databricks ストレージ名
    p20250022-de01-s12-storageconf-001から順番に付与
    p20250022-de01-s00-storageconf-001(監査ログ用)

# ChatGPT指摘事項
次はChatGPTにようるアーキ図レビューの際の指摘事項です
次の指摘事項を確認し、ChatGPTの指摘が正しければ詳細設計に含めてください

1) Private DNS / DNS設計が未記載（PrivateLinkでは必須級）
VPCE（Workspace/SCC）を置いただけでは足りず、名前解決（Private DNS / Route 53 Resolver等） の設計が必要です。
→ パラメータシートに最低限入れる：
VPCの enableDnsSupport / enableDnsHostnames
VPCEで Private DNSを有効にするか
独自DNSがある場合の解決方式（Route 53 Resolver inbound/outbound など）
（この観点自体は DatabricksのPrivateLink“概念”側で重要点として扱われます）

2) NACL要件（0.0.0.0/0 allow）が書かれていない
Databricksは NACLに 0.0.0.0/0 をallowに入れることを要求します（衝撃ポイント）。
その代わり、実際の統制は Egress FW/Proxy でURL許可に寄せる、というのが公式の書き方です。
→ s12なら「Network Firewallで統制」があるので方針は良いですが、NACL要件と統制方針をセットで明記してください。

3) 兼用自体は可能だが「パス設計」がないとUCで衝突します
Unity Catalogの managed storage は 外部テーブル/外部ボリュームとパスがオーバーラップ不可です。
このため「同一バケット兼用」はOKでも、prefix（ディレクトリ）を明確に分離しないと後でエラーになります。
→ 例（方針案）
root storage（workspace default）: s3://bucket/root/<ws-id or ws-name>/
UC managed storage: s3://bucket/uc-managed/（Databricksが __unitystorage/... を作る前提）
external location（Input/Output等）: s3://bucket/external/input/ .../output/
禁止：external location を s3://bucket/ のように上位に置く（root/managedと衝突）

4) “顧客IAMユーザがVPCを経由せずS3へPublicアクセス”は統制観点で要注意
技術的には可能ですが、s12前提だと
どのIP/条件で許可するのか
MFA必須にするのか
bucket policyで aws:SourceIp / aws:MultiFactorAuthPresent / 監査ログ
など 統制設計が必須です。
→ ここは「Terraform管理外」と書かれている分、設計書に“運用統制”を追記しないとレビューで落ちやすいです。

5)  ルーティングの責務が図から読み取れない
いまは「Notebook → NFW → RNAT → IGW」と流れは描けていますが、詳細設計に入る前提として どのルートテーブルで何を向けるかの“責務分界”がまだ薄いです。
最低限、詳細設計で必ず出すべきルート（例）
WS用サブネットのRT：0.0.0.0/0 → Network Firewall endpoint
Firewall用サブネットのRT：0.0.0.0/0 → Regional NAT Gateway
S3はGWエンドポイント向き（既にOK）
このあたりは次フェーズ（詳細設計）で、あなたが挙げた「DNS/NACL」等と一緒にチェックします。




