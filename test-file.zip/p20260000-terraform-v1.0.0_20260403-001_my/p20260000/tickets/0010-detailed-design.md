
Terraform 用のサービスプリンシパル認証設定について
ChatGPTから次の提案がありました
内容に確認し、提案が正しければ詳細設計書への反映をお願いします

# 追加要件
- secretsmanager作成は、10-aws-main-s12に含める。
- ただしシークレットのキー/値はAWSマネジメントコンソールで設定する内容にしてください

# ChatGPT提案
公式ドキュメントベースで、Databricks 側の作成から AWS Secrets Manager への格納、Terraform での参照まで一連の流れを整理します。workspace レベルと account レベルで使い分けがあるので、その点も含めてまとめます。

Databricks on AWS で Terraform 用のサービスプリンシパル認証を組むなら、実務上は次の流れがわかりやすいです。
    1. Databricks でサービスプリンシパルを作成
    2. 必要なら対象 workspace に割り当て
    3. OAuth secret を生成
    4. Client ID / Secret を AWS Secrets Manager に保存
    5. Terraform 実行時に Secrets Manager から取り出して環境変数へ渡す

Databricks 公式では、自動化ツールでの認証は OAuth を推奨しており、Terraform では DATABRICKS_CLIENT_ID / DATABRICKS_CLIENT_SECRET / DATABRICKS_HOST を使う形が案内されています。account-level 操作では DATABRICKS_ACCOUNT_ID も必要です。

https://docs.databricks.com/aws/en/dev-tools/terraform/automate-uc

1. Databricks でサービスプリンシパルを作成
Account Console で作成
   1. Databricks Account Console に account admin でログイン
   2. User management
   3. Service principals タブ
   4. Add service principal
   5. 名前を入力して作成

Databricks 公式では、account admin または workspace admin がサービスプリンシパルを追加できます。
https://docs.databricks.com/aws/en/admin/users-groups/manage-service-principals

2. 対象 workspace に割り当てる
Terraform で workspace-level の設定を行うなら、そのサービスプリンシパルを対象 workspace に割り当てます。

Account Console から割り当て
   1. Workspaces
   2. 対象 workspace を開く
   3. Permissions
   4. Add permissions
   5. 作成した service principal を選択
   6. workspace User または必要に応じて Admin を付与して保存

Databricks 公式でも、workspace に入れるには明示的な割り当てが必要です。
https://docs.databricks.com/aws/en/admin/users-groups/manage-service-principals

補足
・account-level API を叩く Terraform なら、DATABRICKS_HOST=https://accounts.cloud.databricks.com と DATABRICKS_ACCOUNT_ID が必要です。
・workspace-level API なら、DATABRICKS_HOST は workspace URL を使います。

https://docs.databricks.com/aws/en/dev-tools/auth/oauth-m2m

3. OAuth secret を生成する
   1. Databricks 右上のユーザー名
   2. Settings
   3. Identity and access
   4. Service principals の Manage
   5. 対象 service principal を選択
   6. Secrets タブ
   7. Generate secret
   8. 有効期限を設定して生成

Databricks 公式では、OAuth secret は 最大 730 日、1 つのサービスプリンシパルに 最大 5 個まで持てます。また、secret は表示時の 1 回しか見られず、表示される client ID はその service principal の application ID です。

4. AWS Secrets Manager に保存する
Secrets Manager は OAuth token や各種認証情報を保存する用途に使えます。AWS 公式でも secret は認証情報や OAuth token などを保存するものと説明しています。
https://docs.aws.amazon.com/cli/latest/reference/secretsmanager/create-secret.html

保存する内容の例
1 つの secret に JSON でまとめるのが管理しやすいです。
{
  "client_id": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
  "client_secret": "xxxxxxxxxxxxxxxxxxxxxxxx",
  "host": "https://dbc-xxxxxxxx-xxxx.cloud.databricks.com",
  "account_id": "1234567890123456"
}

5. Terraform 実行時に Secrets Manager から取り出す
Terraform provider の Databricks 認証は、公式には環境変数または .databrickscfg で渡せます。環境変数は次です。

workspace-level
export DATABRICKS_HOST="https://dbc-xxxxxxxx-xxxx.cloud.databricks.com"
export DATABRICKS_CLIENT_ID="<client-id>"
export DATABRICKS_CLIENT_SECRET="<client-secret>"

account-level
export DATABRICKS_HOST="https://accounts.cloud.databricks.com"
export DATABRICKS_ACCOUNT_ID="<account-id>"
export DATABRICKS_CLIENT_ID="<client-id>"
export DATABRICKS_CLIENT_SECRET="<client-secret>"

Databricks 公式では、account-level では account_id が必要で、workspace-level では不要です。

Secrets Manager から取り出して export する例
get-secret-value で SecretString を取得できます。

PowerShell 例
$secretJson = aws secretsmanager get-secret-value `
  --secret-id databricks/terraform/account-admin `
  --query SecretString `
  --output text

$secret = $secretJson | ConvertFrom-Json

$env:DATABRICKS_HOST          = $secret.host
$env:DATABRICKS_ACCOUNT_ID    = $secret.account_id
$env:DATABRICKS_CLIENT_ID     = $secret.client_id
$env:DATABRICKS_CLIENT_SECRET = $secret.client_secret

terraform init
terraform plan
terraform apply

6. Terraform 側の基本形
provider 側は環境変数を使うなら最小で済みます。
terraform {
  required_providers {
    databricks = {
      source = "databricks/databricks"
    }
  }
}

provider "databricks" {}

Databricks Terraform provider は host を含む認証値を環境変数から受け取れます。

7. 典型的な使い分け
workspace-level のみ触る場合
Secrets Manager に入れる値:
・host = workspace URL
・client_id
・client_secret

account-level も触る場合
Secrets Manager に入れる値:
・host = https://accounts.cloud.databricks.com
・account_id
・client_id
・client_secret

両方触る場合
secret を 2 つに分けると事故が減ります。
・databricks/terraform/account-admin
・databricks/terraform/workspace-1-admin

8. 運用上の注意
・DATABRICKS_HOST に /api は付けません。Databricks 公式のトラブルシュートでも注意されています。
・DATABRICKS_CLIENT_ID は Application ID、DATABRICKS_CLIENT_SECRET は OAuth secret です。
・401 Unauthorized の典型原因は client ID/secret の誤りや secret 期限切れです。
・403 Forbidden の典型原因は workspace 未割り当てや権限不足です。
・compute や SQL warehouse を使う処理では、その service principal に対象リソース権限も必要です。

おすすめ構成
あなたの用途が Terraform による Databricks 構築なら、まずは次が無難です。
・account 用 SP を 1 つ作る
・workspace 用 SP を WS毎 に作る
・それぞれ別 Secret に保存
・実行スクリプトで aws secretsmanager get-secret-value → 環境変数 export → terraform plan/apply

この形だと、account-level と workspace-level の誤操作を分けやすいです。