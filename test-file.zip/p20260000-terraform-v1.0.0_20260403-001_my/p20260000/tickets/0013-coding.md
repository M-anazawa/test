

# 1. 次の２つのユーザーグループを作成する

グループ名：terumo_users　※グループ名はtfvarsで管理
ロール：アカウント管理者

グループ名：lykeion_users　※グループ名はtfvarsで管理
ロール：アカウント管理者

# 2. SPの運用変更

SPをアカウントレベルとワークスペースレベル共通にする
ただし、secrets_managerは、現在の方針のままアカウントレベルとワークスペースレベルで分離する

# 3. 次の権限を付与する

メタストア：SPにだけ CREATE EXTERNAL LOCATION、CREATE STORAGE CREDENTIAL付与
Storage Credential: lykeion_usersにだけ CREATE EXTERNAL LOCATION
external location: lykeion_usersとterumo_usersにBROWSE, CREATE EXTERNAL TABLE, CREATE EXTERNAL VOLUME を付与

# 4. metastore-grantの実装スタック

metastore-grantは50-dbx-workspace-s12スタックに実装する






