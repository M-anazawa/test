
ChatGPTから次の５つ指摘がありました
内容に確認し、指摘が正しければ追記・修正をお願いします
3) はUC使用のため、3306は不要の旨を追記してくだい

# ChatGPT指摘事項

1) STS/Kinesis の Interface VPCE を「エンドポイント用サブネット」に置いている点
    いまのまま（エンドポイント用サブネット）で行くなら
    「動作上はOK」を設計として成立させるために、設計書に 1段追記してください。
    本構成は“集中エンドポイント構成”として運用する
    成立条件があります（ここが揃わないと「置いたのに繋がらない」が起きます）：
    成立条件
    1. Private DNS 有効化（sts.<region>.amazonaws.com / kinesis-streams.<region>.amazonaws.com を VPCE に解決させる）
    2. 各AZにVPCEを作る（呼び出し元AZに対応するENIが無いと、名前解決や経路が想定外になりやすい）
    3. VPCE側SGで、呼び出し元（sg-001）から TCP/443 を許可
    4. NACL/ルーティングでサブネット間を邪魔しない（あなたはNACL全許可なのでここは満たしやすい）
    検証手順を追加（各AZのクラスターから）
    nslookup sts.ap-northeast-1.amazonaws.com が VPCE のプライベートIPを返すこと
    curl https://sts.ap-northeast-1.amazonaws.com/ が疎通できること
    Kinesisも同様
    # 関連ドキュメント
    https://docs.databricks.com/aws/ja/security/network/classic/privatelink#%E3%82%B9%E3%83%86%E3%83%83%E3%83%97-5-%E4%BB%96%E3%81%AE-aws-%E3%82%B5%E3%83%BC%E3%83%93%E3%82%B9%E3%81%AE-vpc-%E3%82%A8%E3%83%B3%E3%83%89%E3%83%9D%E3%82%A4%E3%83%B3%E3%83%88%E3%82%92%E8%BF%BD%E5%8A%A0%E3%81%99%E3%82%8B

2) S3 Gateway VPCE の関連付けRTが「全ルートテーブル（WS/FW）」になっている
    設計書 15.1 で S3 GW VPCE を 全RT（WS/FW）に関連付けとしています。
    Databricks公式では、S3 Gateway endpoint は workspace subnets に紐づくRTにだけアタッチすればよく、endpoint用サブネット側RTには不要という趣旨で明確に書かれています。
    修正案（推奨）
    S3 GW VPCE の route table association は WS用RTのみ（priws の 3つ）にする
    FW用RT / VPCE用RT からは外す

3) SGの“必要ポート”がDatabricks公式の最小要件とズレ（特に 3306 が抜けている）
    あなたの SG設計では、sg-001 → sg-002 間のポート（443/2443/6666/8443/8444/8445-8451）を通す設計になっていますが、3306 が出てきません。
    Databricksの customer-managed VPC のセキュリティグループ要件として、443 / 3306 / 6666（PrivateLink時） / 2443（Compliance profile時） が明記されています。
    修正案（推奨）
    sg-001 の egress（または FW 許可）に TCP/3306 を追加（どこに向けるかは“制御単位”次第）
    もし「UCのみでHMS不要」などで 3306 を意図的に閉じるなら、その前提と影響範囲を設計書に明記（レビュー観点として“閉じる理由”が必要）

4) VPCE用SG（sg-002）のアウトバウンド「全許可」は不要（削ってもよい）
    Databricks公式：PrivateLink endpoint SG は inbound だけで足り、outbound は不要とされています。
    修正案（推奨）
    sg-002 の outbound は「デフォルト許可」のままでも動きますが、統制を強めるなら outbound ルール自体を無くす（AWSの既定 allow all の扱いと整合させるか、最小にする） という方向に整理
    ※ここは“設計の美しさ/監査向け”の話で、致命傷ではないです。

5) NACLを「ALL traffic 許可」にしている点（要件満たすが強すぎる）
    Databricksは NACL に 0.0.0.0/0 を allow list に入れる要件を明記しています（Egress統制はFW/Proxy推奨）。
    一方であなたのNACLは イン/アウトとも “全トラフィック・全プロトコル・全ポート” です。
    現状評価：要件面ではOK（FWで統制する方針とも整合）
    改善案（任意）：監査観点を意識するなら、少なくとも「なぜNACLは全許可なのか（Databricks要件＋統制はNFW）」をもう一段明確に書く
