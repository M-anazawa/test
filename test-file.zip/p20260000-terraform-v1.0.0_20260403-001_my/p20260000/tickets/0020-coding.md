
# Claude Code 実装指示

以下の内容で、Databricks on AWS の Terraform 実装を修正してください。
目的は、Databricks classic network configuration 画面に表示されている次の警告を解消することです。

> Warning: Egress rules in the Security Group sg-01a0ca7b94f3f014e are not configured correctly.

## 修正方針

Databricks 公式ドキュメント（最新）に完全準拠してください。

### 1. 対象

* workspace security group: `p20250022-de03-s12-sg-001`
* VPC endpoint security group: `p20250022-de03-s12-sg-002`

### 2. workspace security group (`sg-001`) の **egress** を修正

Databricks 公式要件に合わせて、`sg-001` の outbound に以下を追加・維持してください。

#### 必須

* self 宛

  * TCP `0-65535`
  * UDP `0-65535`

* `0.0.0.0/0` 宛

  * TCP `443`
  * TCP `3306`
  * TCP `6666`
  * TCP `8443`
  * TCP `8444`
  * TCP `8445-8451`

#### 条件付き

* TCP `53`
* UDP `53`

※ DNS 53 は Databricks 公式上は「custom DNS を使う場合」に必要です。
現在の設計が AmazonProvidedDNS 前提なら、53 は必須扱いではありません。
ただし Databricks のバリデーションとの整合を優先する場合は、`0.0.0.0/0` 宛に TCP/UDP 53 を追加する実装案もコメントで残してください。

### 3. workspace security group (`sg-001`) の **ingress**

現状どおり以下を維持してください。

* self 宛

  * TCP `0-65535`
  * UDP `0-65535`

### 4. VPC endpoint security group (`sg-002`) の **ingress**

現状どおり、`sg-001` を source にして以下を許可してください。

* TCP `443`
* TCP `6666`
* TCP `2443`
* TCP `8443`
* TCP `8444`
* TCP `8445-8451`

### 5. VPC endpoint security group (`sg-002`) の **egress**

Databricks 公式では endpoint SG の outbound は不要です。
そのため、`sg-002` の egress は次のいずれかで整理してください。

#### 推奨

* AWS デフォルトの all egress を残す

#### 代替

* 明示的に必要最小限へ絞る場合は、その理由をコメントで残す

## 実装要件

1. Terraform の該当 SG 定義を修正する
2. 既存の命名規則は変更しない
3. 既存の `sg-001 -> sg-002` の参照関係は壊さない
4. 変更差分が分かるように、修正対象ファイルごとに diff 形式で提示する
5. あわせて README または設計コメントとして、次の理由を簡潔に追記する

### コメント追記内容

* Databricks workspace SG は、実通信経路が PrivateLink/VPCE 経由であっても、Databricks 公式の VPC validation 要件として `0.0.0.0/0` 宛必要ポートの egress を求められる
* PrivateLink 利用時は TCP 6666 が必須
* endpoint SG は inbound ルール中心でよく、outbound は不要

## 期待する成果物

次を返してください。

1. 修正後 Terraform コード
2. 変更点の要約
3. `terraform plan` で想定される差分の説明
4. 修正後に確認すべき Databricks / AWS の確認ポイント

## 注意

* Databricks 公式要件から外れる独自最適化は入れない
* 「VPCE 宛だけ許可すれば十分」などの独自解釈は採用しない
* 必ず Databricks 公式ドキュメント準拠で実装する
