@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0ops.ps1" %*
endlocal
