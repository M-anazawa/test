# ==================================================
# 40-dbx-account-s00 用 環境固有設定
# ==================================================

# Databricks Account ID（環境毎に異なる）
databricks_account_id = "c7324012-9ae2-4541-a75d-3f0a0d213d4a"

# Credentials（20-aws-common-s00 apply 後に取得して記入）
auditlogs_role_arn = "arn:aws:iam::139139346694:role/p20250022-de04-s00-role-auditlogs-001"  # 20-aws-common-s00 output iam_auditlogs_role_arn

# メタストア owner（共通 SP）
sp_application_id = "705f1dd2-2da4-4745-af19-56026b964bd0"  # SP の Application ID（Client ID）
