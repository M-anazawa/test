# ==================================================
# 30-dbx-account-s12 用 環境固有設定
# ==================================================

# Databricks Account ID（環境毎に異なる）
databricks_account_id = "c7324012-9ae2-4541-a75d-3f0a0d213d4a"

# AWS VPC Endpoint IDs（10-aws-main-s12 apply 後に取得して記入）
ws_vpce_id  = "vpce-03550e5c2613f0ca8"  # vpce-002 の AWS VPC Endpoint ID
scc_vpce_id = "vpce-02c30b5948cafd955"  # vpce-003 の AWS VPC Endpoint ID

# Network Object（10-aws-main-s12 apply 後に取得して記入）
vpc_id = "vpc-02184217525853434"  # 10-aws-main-s12 output vpc_id
ws_subnet_ids = [              # 10-aws-main-s12 output subnet_ids の priws-1a/1c/1d-001
  "subnet-032f41d640783c4e3",
  "subnet-083c561476fa26f2b",
  "subnet-0e3f681847143a6b4",
]
sg_id = "sg-069a763b95220ac92"    # 10-aws-main-s12 output sg_ids の sg_001

# Credentials（10-aws-main-s12 apply 後に取得して記入）
crossaccount_role_arn = "arn:aws:iam::139139346694:role/p20250022-de04-s12-role-crossaccount-001"  # 10-aws-main-s12 output iam_crossaccount_role_arn

# Storage Configuration（10-aws-main-s12 apply 後に取得して記入）
iam_storage_role_arn = "arn:aws:iam::139139346694:role/p20250022-de04-s12-role-extloc-storage-001"  # 10-aws-main-s12 output iam_storage_role_arn

# メタストア割り当て用（40-dbx-account-s00 apply 後に取得して記入）
metastore_id = "c754918a-67e7-430a-9495-30657fa135da"  # 40-dbx-account-s00 output metastore_id

# サービスプリンシパル（グループ管理用）
sp_application_id = "705f1dd2-2da4-4745-af19-56026b964bd0"  # SP の Application ID（Client ID）
