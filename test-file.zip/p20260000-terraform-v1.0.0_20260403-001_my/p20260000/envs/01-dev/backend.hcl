bucket       = "p20250022-de04-s12-bucket-tfstate-001"
region       = "ap-northeast-1"
encrypt      = true
use_lockfile = true

