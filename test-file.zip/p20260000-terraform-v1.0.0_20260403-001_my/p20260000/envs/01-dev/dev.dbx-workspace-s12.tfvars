# 50-dbx-workspace-s12 用（WS-level UC運用層）

# Storage Credential 用 IAMロールARN（10-aws-main-s12 output から取得）
storage_role_arn       = "arn:aws:iam::139139346694:role/p20250022-de04-s12-role-extloc-storage-001"
extloc_input_role_arn  = "arn:aws:iam::139139346694:role/p20250022-de04-s12-role-extloc-input-001"
extloc_output_role_arn = "arn:aws:iam::139139346694:role/p20250022-de04-s12-role-extloc-output-001"

# メタストア権限付与用（40-dbx-account-s00 output から取得）
metastore_id      = "c754918a-67e7-430a-9495-30657fa135da"
sp_application_id = "705f1dd2-2da4-4745-af19-56026b964bd0"
