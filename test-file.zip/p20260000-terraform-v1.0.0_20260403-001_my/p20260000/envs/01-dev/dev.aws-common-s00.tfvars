# ==================================================
# 20-aws-common-s00 用 環境固有設定
# ==================================================
# 環境共通の値は 04-variables.tf の default で管理。
# 環境固有の上書きが必要な場合のみ本ファイルに記載する。

# Databricks Account ID（環境毎に異なる）
databricks_account_id = "c7324012-9ae2-4541-a75d-3f0a0d213d4a"

# Databricks 提供の固定値（全環境共通）
# ※ 監査ログ配信用 IAM ロール ARN。環境（dev/stg/prd）を問わず同じ値を使用する
databricks_audit_log_delivery_role_arn = "arn:aws:iam::414351767826:role/SaasUsageDeliveryRole-prod-IAMRole-3PLHICCRR1TK"
