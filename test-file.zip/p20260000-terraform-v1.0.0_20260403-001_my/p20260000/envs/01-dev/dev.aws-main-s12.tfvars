# ==================================================
# 10-aws-main-s12 用 環境固有設定
# ==================================================
# 環境共通の値は 04-variables.tf の default で管理。
# 環境固有の上書きが必要な場合のみ本ファイルに記載する。

# Databricks Account ID（環境毎に異なる）
databricks_account_id = "c7324012-9ae2-4541-a75d-3f0a0d213d4a"

# Databricks 提供の固定値（全環境共通）
# ※ Databricks Control Plane の AWS アカウント ID・IAM ロール ARN
#    環境（dev/stg/prd）を問わず同じ値を使用する
databricks_aws_account_id         = "414351767826"
databricks_unity_catalog_role_arn = "arn:aws:iam::414351767826:role/unity-catalog-prod-UCMasterRole-14S5ZJVKOTYTL"

# ストレージ構成用 IAM ロール（2段階 apply）
# ※ 1回目 apply: Databricks Account ID + false（IAM ロール作成）
# ※ 2回目 apply: true に変更（self-assume 有効化。WS 作成前に必要）
# ※ Step 11 で SC の External ID に更新する
storage_credential_external_id = "c7324012-9ae2-4541-a75d-3f0a0d213d4a"
enable_self_assume             = true

# ExtLoc Input 用 IAM ロール（2段階 apply）
# ※ 初回は "0000" + false。SC 作成後に実際の External ID + true に変更する（Step 11）
extloc_input_credential_external_id = "c7324012-9ae2-4541-a75d-3f0a0d213d4a"
enable_extloc_input_self_assume     = true

# ExtLoc Output 用 IAM ロール（2段階 apply）
# ※ 初回は "0000" + false。SC 作成後に実際の External ID + true に変更する（Step 11）
extloc_output_credential_external_id = "c7324012-9ae2-4541-a75d-3f0a0d213d4a"
enable_extloc_output_self_assume     = true
