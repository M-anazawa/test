




20-aws-common-s00
02-locals.tf
  # ==============================================
  # Secrets Manager（Databricks SP認証情報）
  # ==============================================
  secret_names = {
    dbx_sp_account = "${local.prefix}-secret-dbx-sp-account-001"
    dbx_sp_ws      = "${local.prefix}-secret-dbx-sp-ws-001"


ops.ps1
# ==================================================
# Databricks 認証（Secrets Manager から自動取得）
# ==================================================
function Set-DatabricksAuth([string]$StackName) {
  if ($StackName -like "dbx-account-*") {
    $secretId = "${accountCode}-s00-secret-dbx-sp-account-001"
  } elseif ($StackName -like "dbx-workspace-*") {
    $secretId = "${accountCode}-s00-secret-dbx-sp-ws-001"
  } else {
    return  # AWS スタックは Databricks 認証不要
  }


dbxcli.ps1
# ==================================================
# Secret ID 決定
# ==================================================
if ($Level -eq "account") {
  $secretId = "${accountCode}-s00-secret-dbx-sp-account-001"
} elseif ($Level -match "^ws-\d+$") {
  $secretId = "${accountCode}-s00-secret-dbx-sp-${Level}"
} else {
  throw "Invalid Level '$Level'. Use 'account' or 'ws-NNN' (e.g. ws-001, ws-002)."
}



# 命名規則

VPC
	(AWSアカウント識別子)-sXX-vpc-XXX
    p20250022-de01-s12-vpc-001

サブネット
	(VPC名)-(用途)-sn-(AZ)-XXX
    p20250022-de01-s12-vpc-001-priapp-sn-1c-001"

リージョナルNAT
	(VPC名)-rnat
    p20250022-de01-s12-vpc-001-rnat

VPCエンドポイント
	(AWSアカウント識別子)-sXX-vpce-XXX
    p20250022-de01-s12-vpce-001

セキュリティグループ
	(AWSアカウント識別子)-sXX-sg-XXX
    p20250022-de01-s12-sg-001

IAMロール
	(AWSアカウント識別子)-sXX-role-(用途)-XXX
    p20250022-de01-s12-role-vpcflowlog-001

IAMポリシー
	(AWSアカウント識別子)-sXX-policy-(用途)-XXX
    p20250022-de01-s12-policy-ecsdef-001

S3
	(AWSアカウント識別子)-sXX-bucket-(用途)-XXX
    p20250022-de01-s12-bucket-data-001



Databricks ワークスペース名
	(AWSアカウント識別子)-sXX-ws-XXX
    p20250022-de01-s12-ws-001

Databricks PrivateLinkオブジェクト名
	VPCエンドポイント名
    p20250022-de01-s12-vpce-001

Databricks ネットワークオブジェクト名
	サブネット名からAZを取り除いた名前
    p20250022-de01-s12-vpc-001-priws-sn-001

Databricks プライベートアクセスオブジェクト名
	(AWSアカウント識別子)-sXX-privateaccess-XXX
    p20250022-de01-s12-privateaccess-001

Databricks 資格情報名
	(AWSアカウント識別子)-sXX-credentialconf-XXX
    p20250022-de01-s12-credentialconf-001

Databricks ストレージ名
	(AWSアカウント識別子)-sXX-storageconf-XXX
    p20250022-de01-s12-storageconf-001


# 構成
-----------------------------------------
ユーザー
↕　Public
コントロールプレーン
↕　PrivateLink
コンピュートプレーン:Customer-managed VPC
-----------------------------------------

## VPC
VPC CIDR : 10.0.0.0/16

## IGW

## Regional NAT

## Network Firewall

## Subnet
WS用サブネット AZ:1a : 10.0.0.0/20
WS用サブネット AZ:1c : 10.0.16.0/20
WS用サブネット AZ:1d : 10.0.32.0/20
エンドポイント用サブネット AZ:1a : 10.0.240.0/24
エンドポイント用サブネット AZ:1c : 10.0.241.0/24
エンドポイント用サブネット AZ:1d : 10.0.242.0/24
Network Firewall用サブネット AZ:1a : 10.0.243.0/28
Network Firewall用サブネット AZ:1c : 10.0.243.16/28
Network Firewall用サブネット AZ:1d : 10.0.243.32/28

## VPCE
S3用(Gateway)
WS用(Interface)
SCC用(Interface)
STS用(Interface)
Kinesis用(Interface)

## SG
WS用
Network Firewallエンドポイント用
VPCエンドポイント用（Network Firewallエンドポイント以外）

## S3
Unity Catalog用(SSE-S3)
Input用(SSE-S3)
Output用(SSE-S3)

## IAMロール/ポリシー
資格情報構成用
ストレージ構成用

# フロー

## WS操作
WS利用者(顧客)
↓ public
WS

## データ入力-1
WS利用者(顧客):terraform管理外S3アクセス用IAMユーザ
↓ public
Input用S3

## データ入力-2
インターネット上のクラウド等のリソース
↓ public(IGW,FW,NAT経由)
Notebook

## データ出力
WS利用者(顧客):terraform管理外S3アクセス用IAMユーザ
↑ public
Output用S3

## Notebook
Input用S3
↓
Notebook処理
↓
Output用S3

# 工程

VPC作成(IGW, Regional NAT, Subnet, NACL含む)
SG作成
VPCE作成
Network Firewall作成
S3バケット作成　※root storageとUCは共通S3で同一VPC内の全WSで共通
IAMロール/ポリシー作成
us-west-2のSTSエンドポイントアクティブ化確認

DatabricksにPrivateLinkオブジェクト登録
Databricksにネットワークオブジェクト登録
Databricksにプライベートアクセス設定オブジェクト登録
Databricksに資格情報登録
Databricksにストレージ構成登録
Databricksワークスペース作成
WSのユーザ追加は手動

## 追加要件
別スタックを作成し、Security Codeの異なるVPCを容易に増減できること
各スタックのVPCにサブネット、SG、FW、VPCE、IGW、NAT及び、S3、IAMロール/ポリシーを容易に増減できること









# ワークスペース作成

## 手動AWS設定でワークスペースを作成 : コントロール-コンピュート間PrivateLinkアクセス

### 命名規則

名前：p20260000-de01-s12-role-vpcflowlog-001
名前：p20260000-de01-s12-policy-ecsdef-001
名前：p20260000-de01-s12-bucket-data-001

1. VPC作成
https://docs.databricks.com/aws/ja/security/network/classic/customer-managed-vpc#vpc-%E3%81%AE%E8%A6%81%E4%BB%B6

- パブリックサブネット３つ
- ワークスペース用プライベートサブネット３つ
- エンドポイント用サブネット３つ
- IGW１つ
- リージョナルNAT１つ
- RT
- ネットワークACL１つ

### 注意事項
- ワークスペースごとに一意のサブネットとセキュリティ グループを使用することをお勧めします
- ノードごとに2つのIPアドレス(1つは管理トラフィック用、もう1つは Apache Sparkアプリケーション用)を割り当てます。 各サブネットのインスタンスの合計数は、使用可能な IP アドレスの数の半分に等しくなります
- 各ワークスペース サブネットには /17 から /26までのネットマスクが必要です
- サブネットは、NATゲートウェイやインターネットゲートウェイ、またはその他の同様のカスタマーマネージドアプライアンスインフラストラクチャを使用して、パブリックネットワークへのアウトバウンドアクセスが可能であることが必要です
- NAT ゲートウェイは、クワッドゼロ(0.0.0.0/0) トラフィックをインターネットゲートウェイ またはその他の顧客管理アプライアンスインフラストラクチャにルーティングする独自のサブネットに設定する必要があります。
- AWS PrivateLinkを有効にする場合は、VPCでDNSホスト名とDNS解決が有効になっている必要があります
- NAT/IGWを無くす場合は、RTの見直しが必要になる

### Databricks推奨の命名規則
- VPCの名前にワークスペースの名前を入力します。リージョンを含めることをお勧めしています
https://docs.databricks.com/aws/ja/security/network/classic/customer-managed-vpc#vpc-%E3%82%92%E4%BD%9C%E6%88%90%E3%81%99%E3%82%8B

### VPC
名前：p20260000-de01-s12-vpc-001
10.0.0.0/16
DNSホスト名を有効化
DNS解決を有効化
VPC暗号化コントロール：モニタリングモード
テナンシー：デフォルト
IPv6 CIDR ブロックなし

### パブリックサブネット
名前：p20260000-de01-s12-vpc-001-pub-sn-1a-001
10.0.0.0/20

名前：p20260000-de01-s12-vpc-001-pub-sn-1c-001
10.0.16.0/20

名前：p20260000-de01-s12-vpc-001-pub-sn-1d-001
10.0.32.0/20

### ワークスペース用プライベートサブネット
名前：p20260000-de01-s12-vpc-001-priws-sn-1a-001
10.0.128.0/20

名前：p20260000-de01-s12-vpc-001-priws-sn-1c-001
10.0.144.0/20

名前：p20260000-de01-s12-vpc-001-priws-sn-1d-001
10.0.160.0/20

### エンドポイント用サブネット
名前：p20260000-de01-s12-vpc-001-priend-sn-1a-001
10.0.176.0/20

名前：p20260000-de01-s12-vpc-001-priend-sn-1c-001
10.0.192.0/20

名前：p20260000-de01-s12-vpc-001-priend-sn-1d-001
10.0.208.0/20

### RT
名前：p20260000-de01-s12-vpc-001-pub-sn-001-rt
[ルート]
0.0.0.0/0 igw
10.0.0.0/16 local

名前：p20260000-de01-s12-vpc-001-priws-sn-1a-001-rt
[ルート]
pl-61a54008 S3ゲートウェイVPCE
0.0.0.0/0 NAT
10.0.0.0/16 local

名前：p20260000-de01-s12-vpc-001-priws-sn-1c-001-rt
[ルート]
pl-61a54008 S3ゲートウェイVPCE
0.0.0.0/0 NAT
10.0.0.0/16 local

名前：p20260000-de01-s12-vpc-001-priws-sn-1d-001-rt
[ルート]
pl-61a54008 S3ゲートウェイVPCE
0.0.0.0/0 NAT
10.0.0.0/16 local

名前：p20260000-de01-s12-vpc-001-priend-sn-1a-001-rt
[ルート]
pl-61a54008 S3ゲートウェイVPCE
0.0.0.0/0 NAT
10.0.0.0/16 local

名前：p20260000-de01-s12-vpc-001-priend-sn-1c-001-rt
[ルート]
pl-61a54008 S3ゲートウェイVPCE
0.0.0.0/0 NAT
10.0.0.0/16 local

名前：p20260000-de01-s12-vpc-001-priend-sn-1d-001-rt
[ルート]
pl-61a54008 S3ゲートウェイVPCE
0.0.0.0/0 NAT
10.0.0.0/16 local

### IGW
名前：p20260000-de01-s12-vpc-001-igw

### リージョナルNAT
名前：p20260000-de01-s12-vpc-001-rnat

### S3ゲートウェイVPCE
名前：p20260000-de01-s12-vpce-001

### ネットワークACL
[インバウンドルール]
100 すべてのトラフィック すべて すべて 0.0.0.0/0 Allow
*   すべてのトラフィック すべて すべて 0.0.0.0/0 Deny

[アウトバウンドルール]
100 すべてのトラフィック すべて すべて 0.0.0.0/0 Allow
*   すべてのトラフィック すべて すべて 0.0.0.0/0 Deny

2. SG作成
https://docs.databricks.com/aws/ja/security/network/classic/customer-managed-vpc#%E3%82%BB%E3%82%AD%E3%83%A5%E3%83%AA%E3%83%86%E3%82%A3%E3%82%B0%E3%83%AB%E3%83%BC%E3%83%97

https://docs.databricks.com/aws/ja/security/network/classic/privatelink#%E3%82%BB%E3%82%AD%E3%83%A5%E3%83%AA%E3%83%86%E3%82%A3%E3%82%B0%E3%83%AB%E3%83%BC%E3%83%97%E3%82%92%E4%BD%9C%E6%88%90%E3%81%99%E3%82%8B

https://docs.databricks.com/aws/ja/security/network/classic/privatelink-concepts

### ワークスペース用SG
    名前：p20260000-de01-s12-sg-001
    VPC:p20260000-de01-s12-vpc-001
    Ingress（インバウンド）： 
        - 同一SGからのTCP全ポート許可(Sparkノード間通信用)
        - 同一SGからのUDP全ポート許可(Sparkノード間通信用)

    Egress（アウトバウンド）：
        - 同一SGからのTCP全ポート許可(Sparkノード間通信用)
        - 同一SGからのUDP全ポート許可(Sparkノード間通信用)
        - 次のポートで PrivateLinkエンドポイント用SG への TCP アクセスを許可します：
            - TCP 443：Databricksインフラストラクチャ
            - TCP 6666: セキュリティで保護されたクラスター接続用。 これは、 PrivateLink を使用する場合にのみ必要です。
            - TCP 2443: FIPS 暗号化をサポートします。 コンプライアンス セキュリティ プロファイルを有効にする場合にのみ必要です。
            - TCP 8443: DatabricksコンピュートプレーンからDatabricksコントロールプレーンAPIへの内部呼び出し用。
            - TCP 8444: Unity Catalogのログ記録とDatabricksへのリネージデータストリーミング用。
            - TCP 8445-8451: 将来的な拡張性。
        - 次のポートで 0.0.0.0/0 への TCP アクセスを許可します：(AWS Network firewallを配置する場合は向き先をFWに変更する)
            - TCP 443：クラウドデータソース、ライブラリリポジトリ用

### PrivateLinkエンドポイント用SG(クラスターからVPCE通信用)
    名前：p20260000-de01-s12-sg-002
    VPC:p20260000-de01-s12-vpc-001
    Ingress（インバウンド）： 
        送信元：ワークスペースSG
        許可：
            TCP 443
            TCP 6666
            TCP 2443
            TCP 8443/8444/8445-8451

    Egress（アウトバウンド）：
        ALL allow

3. ワークスペース用,SCCリレー用PrivateLink(VPCE)作成
https://docs.databricks.com/aws/ja/security/network/classic/customer-managed-vpc#aws-privatelink-%E3%81%AE%E3%82%B5%E3%83%9D%E3%83%BC%E3%83%88

https://docs.databricks.com/aws/ja/security/network/classic/privatelink

https://docs.databricks.com/aws/ja/security/network/classic/privatelink-concepts

https://docs.databricks.com/aws/ja/resources/ip-domain-region#privatelink

- ワークスペースVPCエンドポイント (ワークスペースとの間のトラフィックを保護。REST API呼び出しを処理)
- SCCリレーVPCエンドポイント (コンピュートプレーンとコントロールプレーン間のセキュアクラスター接続 (SCC) 用)

### Databricks推奨の命名規則
- リージョンと workspaceという単語を組み込んで、ワークスペース VPC エンドポイントに databricks-us-west-2-workspace-vpceなどのエンドポイントに名前を付けます
https://docs.databricks.com/aws/ja/security/network/classic/privatelink#%E3%83%AF%E3%83%BC%E3%82%AF%E3%82%B9%E3%83%9A%E3%83%BC%E3%82%B9-vpc-%E3%82%A8%E3%83%B3%E3%83%89%E3%83%9D%E3%82%A4%E3%83%B3%E3%83%88%E3%82%92%E4%BD%9C%E6%88%90%E3%81%99%E3%82%8B

- エンドポイント名にリージョンと scc という単語を含めることをお勧めします (例: databricks-us-west-2-scc-vpce)
https://docs.databricks.com/aws/ja/security/network/classic/privatelink#scc%E3%83%AA%E3%83%AC%E3%83%BCvpc%E3%82%A8%E3%83%B3%E3%83%89%E3%83%9D%E3%82%A4%E3%83%B3%E3%83%88%E3%82%92%E4%BD%9C%E6%88%90%E3%81%99%E3%82%8B

### 注意事項

- DatabricksアカウントがEnterprise価格プランである必要があります
- 顧客管理VPC使用する必要があります
- 同じ顧客管理VPCを使用する複数のワークスペース間で共有できます
- ネットマスクが少なくとも/25である VPC の IPv4 CIDR ブロックを選択します

### ワークスペース用VPCE
名前：p20260000-de01-s12-vpce-002
タイプ：NLB と GWLB を使用するエンドポイントサービス
サービス名：com.amazonaws.vpce.ap-northeast-1.vpce-svc-02691fd610d24fd64
VPC:p20260000-de01-s12-vpc-001
サブネット:p20260000-de01-s12-vpc-001-priend-sn-1a-001,p20260000-de01-s12-vpc-001-priend-sn-1c-001,p20260000-de01-s12-vpc-001-priend-sn-1d-001
SG:p20260000-de01-s12-sg-002
プライベートDNS名を有効化:オン

### SCCリレー用VPCE
名前：p20260000-de01-s12-vpce-003
タイプ：NLB と GWLB を使用するエンドポイントサービス
サービス名：com.amazonaws.vpce.ap-northeast-1.vpce-svc-02aa633bda3edbec0
VPC:p20260000-de01-s12-vpc-001
サブネット:p20260000-de01-s12-vpc-001-priend-sn-1a-001,p20260000-de01-s12-vpc-001-priend-sn-1c-001,p20260000-de01-s12-vpc-001-priend-sn-1d-001
SG:p20260000-de01-s12-sg-002
プライベートDNS名を有効化:オン

4. 他のAWSサービスのVPCE追加
https://docs.databricks.com/aws/ja/security/network/classic/privatelink#%E3%82%B9%E3%83%86%E3%83%83%E3%83%97-5-%E4%BB%96%E3%81%AE-aws-%E3%82%B5%E3%83%BC%E3%83%93%E3%82%B9%E3%81%AE-vpc-%E3%82%A8%E3%83%B3%E3%83%89%E3%83%9D%E3%82%A4%E3%83%B3%E3%83%88%E3%82%92%E8%BF%BD%E5%8A%A0%E3%81%99%E3%82%8B

- S3(Private DNS有効)：VPC作成時に作成済み
- STS(Private DNS有効)
- Kinesis(Private DNS有効)

下記は必要に応じて追加(クラスターが何を使うかで決まる)
- ECR(Private DNS有効)
- CloudWatch Logs(Private DNS有効)
- KMS(Private DNS有効)
- Secret Manager(Private DNS有効)
- DynamoDB(Private DNS有効)

### Databricks推奨の命名規則
- 次の設定で STS VPC インターフェイス エンドポイントを作成します。命名規則: sts-<region>-vpce (例: sts-us-west-2-vpce )
https://docs.databricks.com/aws/ja/security/network/classic/privatelink#%E3%82%AA%E3%83%97%E3%82%B7%E3%83%A7%E3%83%B32-%E5%8E%B3%E6%A0%BC%E3%81%AA%E3%82%A8%E3%82%A2%E3%82%AE%E3%83%A3%E3%83%83%E3%83%97%E5%B1%95%E9%96%8B

- 次の設定で Kinesis VPC インターフェイスエンドポイントを作成します。命名規則: kinesis-<region>-vpce (例: kinesis-us-west-2-vpce )
https://docs.databricks.com/aws/ja/security/network/classic/privatelink#%E3%82%AA%E3%83%97%E3%82%B7%E3%83%A7%E3%83%B32-%E5%8E%B3%E6%A0%BC%E3%81%AA%E3%82%A8%E3%82%A2%E3%82%AE%E3%83%A3%E3%83%83%E3%83%97%E5%B1%95%E9%96%8B

### STS用VPCE
名前：p20260000-de01-s12-vpce-004
タイプ:AWS のサービス
サービス名：com.amazonaws.ap-northeast-1.sts
VPC:p20260000-de01-s12-vpc-001
サブネット:p20260000-de01-s12-vpc-001-priend-sn-1a-001,p20260000-de01-s12-vpc-001-priend-sn-1c-001,p20260000-de01-s12-vpc-001-priend-sn-1d-001
SG:p20260000-de01-s12-sg-002
プライベートDNS名を有効化:オン

### Kinesis用VPCE
名前：p20260000-de01-s12-vpce-005
タイプ:AWS のサービス
サービス名：com.amazonaws.ap-northeast-1.kinesis-streams
VPC:p20260000-de01-s12-vpc-001
サブネット:p20260000-de01-s12-vpc-001-priend-sn-1a-001,p20260000-de01-s12-vpc-001-priend-sn-1c-001,p20260000-de01-s12-vpc-001-priend-sn-1d-001
SG:p20260000-de01-s12-sg-002
プライベートDNS名を有効化:オン

5. DatabricksにPrivateLinkオブジェクト登録
https://docs.databricks.com/aws/ja/security/network/classic/privatelink#%E3%82%B9%E3%83%86%E3%83%83%E3%83%97-3-privatelink-%E3%82%AA%E3%83%96%E3%82%B8%E3%82%A7%E3%82%AF%E3%83%88%E3%82%92%E7%99%BB%E9%8C%B2%E3%81%99%E3%82%8B

https://docs.databricks.com/aws/ja/security/network/classic/vpc-endpoints

- ワークスペースVPCエンドポイント
- SCCリレーVPCエンドポイント

### Databricks推奨の命名規則
- この特定のVPCエンドポイントのリージョンと宛先を含めることを推奨しています。例えば、これがDatabricksコントロールプレーンのセキュアクラスター接続リレーへのバックエンドPrivateLink接続用のVPCエンドポイントである場合、SCCの場合は「VPCE us-west-2 for SCC」のような名前を付けることができます。
https://docs.databricks.com/aws/ja/security/network/classic/vpc-endpoints#vpc-%E3%82%A8%E3%83%B3%E3%83%89%E3%83%9D%E3%82%A4%E3%83%B3%E3%83%88%E3%82%92%E7%99%BB%E9%8C%B2%E3%81%99%E3%82%8B

### 注意事項
- リージョンフィールドとワークスペースのリージョンが、登録するAWS VPCエンドポイントのリージョンと一致していること

### ワークスペース用VPCE
VPCエンドポイント名：p20260000-de01-s12-vpce-002
リージョン：ap-northeast-1
AWS VPCエンドポイントID：vpce-03596f8f6d15a323e

### SCCリレー用VPCE
VPCエンドポイント名：p20260000-de01-s12-vpce-003
リージョン：ap-northeast-1
AWS VPCエンドポイントID：vpce-0642fe9ff0fa3bbef

6. Databricksにネットワークオブジェクト登録
https://docs.databricks.com/aws/ja/security/network/classic/customer-managed-vpc#databricks%E3%81%ABvpc%E3%82%92%E7%99%BB%E9%8C%B2%E3%81%99%E3%82%8B

https://docs.databricks.com/aws/ja/security/network/classic/privatelink#%E3%82%B9%E3%83%86%E3%83%83%E3%83%97-3-privatelink-%E3%82%AA%E3%83%96%E3%82%B8%E3%82%A7%E3%82%AF%E3%83%88%E3%82%92%E7%99%BB%E9%8C%B2%E3%81%99%E3%82%8B

### ネットワーク登録
ネットワーク設定名：p20260000-de01-s12-vpc-001
VPC ID：vpc-082e68c8fd57b0edb
サブネットID：subnet-082313c286b59164f(p20260000-de01-s12-vpc-001-priws-sn-1a-001)
サブネットID：subnet-0e100bc79a204f9b7(p20260000-de01-s12-vpc-001-priws-sn-1c-001)
サブネットID：subnet-0ba88846d4c7808a7(p20260000-de01-s12-vpc-001-priws-sn-1d-001)
セキュリティグループID：sg-0b7f522889ee66340(p20260000-de01-s12-sg-001)
バックエンドプライベート接続 セキュアなクラスター接続を中継するためのVPCエンドポイント：p20260000-de01-s12-vpce-003
バックエンドプライベート接続 REST API用のVPCエンドポイント：p20260000-de01-s12-vpce-002

7. Databricksにプライベートアクセス設定オブジェクト登録
https://docs.databricks.com/aws/ja/security/network/classic/privatelink#%E3%82%B9%E3%83%86%E3%83%83%E3%83%97-3-privatelink-%E3%82%AA%E3%83%96%E3%82%B8%E3%82%A7%E3%82%AF%E3%83%88%E3%82%92%E7%99%BB%E9%8C%B2%E3%81%99%E3%82%8B

https://docs.databricks.com/aws/ja/security/network/classic/private-access-settings

### プライベートアクセス設定オブジェクト
プライベートアクセス設定名：p20260000-de01-s12-privateaccess-001
リージョン：ap-northeast-1
パブリックアクセス：True
プライベートアクセスレベル：アカウント - Databricksアカウントに登録されているVPCエンドポイントに接続を制限します。

8. クロスアカウントIAMロールを作成(資格情報構成用)
https://docs.databricks.com/aws/ja/admin/workspace/create-uc-workspace?language=Databricks-managed%C2%A0VPC#%E8%B3%87%E6%A0%BC%E6%83%85%E5%A0%B1%E6%A7%8B%E6%88%90%E3%82%92%E4%BD%9C%E6%88%90%E3%81%99%E3%82%8B

https://docs.databricks.com/aws/ja/admin/account-settings/#%E3%82%A2%E3%82%AB%E3%82%A6%E3%83%B3%E3%83%88-id-%E3%82%92%E7%A2%BA%E8%AA%8D%E3%81%99%E3%82%8B

### IAMロール
ロール名：p20260000-de01-s12-role-crossaccount-001
信頼ポリシー
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": "sts:AssumeRole",
            "Principal": {
                "AWS": "414351767826"
            },
            "Condition": {
                "StringEquals": {
                    "sts:ExternalId": "c7324012-9ae2-4541-a75d-3f0a0d213d4a"
                }
            }
        }
    ]
}

9. アクセスポリシー作成(資格情報構成用):Customer-managed VPC with custom restrictions
- Databricks-managed VPC : DatabricksがAWSアカウント内で作成および構成する単一のVPC
- Customer-managed VPC with default restrictions : 顧客管理VPCと呼ばれる機能を使用して、自分のVPCでDatabricksで ワークスペースを作成
- Customer-managed VPC with custom restrictions : アカウントID、VPC ID、AWSリージョン、およびセキュリティグループのカスタム制限を使用して、独自のVPCにDatabricksワークスペースを作成

https://docs.databricks.com/aws/ja/admin/workspace/create-uc-workspace#%E3%82%B9%E3%83%86%E3%83%83%E3%83%97-2-%E3%82%A2%E3%82%AF%E3%82%BB%E3%82%B9%E3%83%9D%E3%83%AA%E3%82%B7%E3%83%BC%E3%82%92%E4%BD%9C%E6%88%90%E3%81%99%E3%82%8B

https://docs.databricks.com/aws/ja/admin/cloud-configurations/aws/permissions#iam%E9%A1%A7%E5%AE%A2%E7%AE%A1%E7%90%86-%E3%81%AE-%E6%A8%A9%E9%99%90vpc

### IAMポリシー
ポリシー名：p20260000-de01-s12-policy-crossaccount-001
ポリシー
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "NonResourceBasedPermissions",
            "Effect": "Allow",
            "Action": [
                "ec2:AssignPrivateIpAddresses",
                "ec2:CancelSpotInstanceRequests",
                "ec2:DescribeAvailabilityZones",
                "ec2:DescribeIamInstanceProfileAssociations",
                "ec2:DescribeInstanceStatus",
                "ec2:DescribeInstances",
                "ec2:DescribeInternetGateways",
                "ec2:DescribeNatGateways",
                "ec2:DescribeNetworkAcls",
                "ec2:DescribePrefixLists",
                "ec2:DescribeReservedInstancesOfferings",
                "ec2:DescribeRouteTables",
                "ec2:DescribeSecurityGroups",
                "ec2:DescribeSpotInstanceRequests",
                "ec2:DescribeSpotPriceHistory",
                "ec2:DescribeSubnets",
                "ec2:DescribeVolumes",
                "ec2:DescribeVpcAttribute",
                "ec2:DescribeVpcs",
                "ec2:CreateTags",
                "ec2:DeleteTags",
                "ec2:GetSpotPlacementScores",
                "ec2:RequestSpotInstances",
                "ec2:DescribeFleetHistory",
                "ec2:ModifyFleet",
                "ec2:DeleteFleets",
                "ec2:DescribeFleetInstances",
                "ec2:DescribeFleets",
                "ec2:CreateFleet",
                "ec2:DeleteLaunchTemplate",
                "ec2:GetLaunchTemplateData",
                "ec2:CreateLaunchTemplate",
                "ec2:DescribeLaunchTemplates",
                "ec2:DescribeLaunchTemplateVersions",
                "ec2:ModifyLaunchTemplate",
                "ec2:DeleteLaunchTemplateVersions",
                "ec2:CreateLaunchTemplateVersion"
            ],
            "Resource": [
                "*"
            ]
        },
        {
            "Sid": "InstancePoolsSupport",
            "Effect": "Allow",
            "Action": [
                "ec2:AssociateIamInstanceProfile",
                "ec2:DisassociateIamInstanceProfile",
                "ec2:ReplaceIamInstanceProfileAssociation"
            ],
            "Resource": "arn:aws:ec2:ap-northeast-1:139139346694:instance/*",
            "Condition": {
                "StringEquals": {
                    "ec2:ResourceTag/Vendor": "Databricks"
                }
            }
        },
        {
            "Sid": "AllowEc2RunInstancePerTag",
            "Effect": "Allow",
            "Action": "ec2:RunInstances",
            "Resource": [
                "arn:aws:ec2:ap-northeast-1:139139346694:volume/*",
                "arn:aws:ec2:ap-northeast-1:139139346694:instance/*"
            ],
            "Condition": {
                "StringEquals": {
                    "aws:RequestTag/Vendor": "Databricks"
                }
            }
        },
        {
            "Sid": "AllowEc2RunInstanceImagePerTag",
            "Effect": "Allow",
            "Action": "ec2:RunInstances",
            "Resource": [
                "arn:aws:ec2:ap-northeast-1:139139346694:image/*"
            ],
            "Condition": {
                "StringEquals": {
                    "aws:ResourceTag/Vendor": "Databricks"
                }
            }
        },
        {
            "Sid": "AllowEc2RunInstancePerVPCid",
            "Effect": "Allow",
            "Action": "ec2:RunInstances",
            "Resource": [
                "arn:aws:ec2:ap-northeast-1:139139346694:network-interface/*",
                "arn:aws:ec2:ap-northeast-1:139139346694:subnet/*",
                "arn:aws:ec2:ap-northeast-1:139139346694:security-group/*"
            ],
            "Condition": {
                "StringEquals": {
                    "ec2:vpc": "arn:aws:ec2:ap-northeast-1:139139346694:vpc/vpc-082e68c8fd57b0edb"
                }
            }
        },
        {
            "Sid": "AllowEc2RunInstanceOtherResources",
            "Effect": "Allow",
            "Action": "ec2:RunInstances",
            "NotResource": [
                "arn:aws:ec2:ap-northeast-1:139139346694:image/*",
                "arn:aws:ec2:ap-northeast-1:139139346694:network-interface/*",
                "arn:aws:ec2:ap-northeast-1:139139346694:subnet/*",
                "arn:aws:ec2:ap-northeast-1:139139346694:security-group/*",
                "arn:aws:ec2:ap-northeast-1:139139346694:volume/*",
                "arn:aws:ec2:ap-northeast-1:139139346694:instance/*"
            ]
        },
        {
            "Sid": "EC2TerminateInstancesTag",
            "Effect": "Allow",
            "Action": [
                "ec2:TerminateInstances"
            ],
            "Resource": [
                "arn:aws:ec2:ap-northeast-1:139139346694:instance/*"
            ],
            "Condition": {
                "StringEquals": {
                    "ec2:ResourceTag/Vendor": "Databricks"
                }
            }
        },
        {
            "Sid": "EC2AttachDetachVolumeTag",
            "Effect": "Allow",
            "Action": [
                "ec2:AttachVolume",
                "ec2:DetachVolume"
            ],
            "Resource": [
                "arn:aws:ec2:ap-northeast-1:139139346694:instance/*",
                "arn:aws:ec2:ap-northeast-1:139139346694:volume/*"
            ],
            "Condition": {
                "StringEquals": {
                    "ec2:ResourceTag/Vendor": "Databricks"
                }
            }
        },
        {
            "Sid": "EC2CreateVolumeByTag",
            "Effect": "Allow",
            "Action": [
                "ec2:CreateVolume"
            ],
            "Resource": [
                "arn:aws:ec2:ap-northeast-1:139139346694:volume/*"
            ],
            "Condition": {
                "StringEquals": {
                    "aws:RequestTag/Vendor": "Databricks"
                }
            }
        },
        {
            "Sid": "EC2DeleteVolumeByTag",
            "Effect": "Allow",
            "Action": [
                "ec2:DeleteVolume"
            ],
            "Resource": [
                "arn:aws:ec2:ap-northeast-1:139139346694:volume/*"
            ],
            "Condition": {
                "StringEquals": {
                    "ec2:ResourceTag/Vendor": "Databricks"
                }
            }
        },
        {
            "Effect": "Allow",
            "Action": [
                "iam:CreateServiceLinkedRole",
                "iam:PutRolePolicy"
            ],
            "Resource": "arn:aws:iam::*:role/aws-service-role/spot.amazonaws.com/AWSServiceRoleForEC2Spot",
            "Condition": {
                "StringLike": {
                    "iam:AWSServiceName": "spot.amazonaws.com"
                }
            }
        },
        {
            "Sid": "VpcNonresourceSpecificActions",
            "Effect": "Allow",
            "Action": [
                "ec2:AuthorizeSecurityGroupEgress",
                "ec2:AuthorizeSecurityGroupIngress",
                "ec2:RevokeSecurityGroupEgress",
                "ec2:RevokeSecurityGroupIngress"
            ],
            "Resource": "arn:aws:ec2:ap-northeast-1:139139346694:security-group/sg-0b7f522889ee66340",
            "Condition": {
                "StringEquals": {
                    "ec2:vpc": "arn:aws:ec2:ap-northeast-1:139139346694:vpc/vpc-082e68c8fd57b0edb"
                }
            }
        }
    ]
}

10. Databricksに資格情報登録
https://docs.databricks.com/aws/ja/admin/workspace/create-uc-workspace?language=Customer-managed%C2%A0VPC%C2%A0with%C2%A0custom%C2%A0restrictions#%E3%82%B9%E3%83%86%E3%83%83%E3%83%97-3-%E8%B3%87%E6%A0%BC%E6%83%85%E5%A0%B1%E3%81%AE%E8%A8%AD%E5%AE%9A%E3%82%92%E4%BD%9C%E6%88%90%E3%81%99%E3%82%8B

### 資格情報設定
資格情報の設定名：p20260000-de01-s12-credentialconf-001
ロールARN：arn:aws:iam::139139346694:role/p20260000-de01-s12-role-crossaccount-001

11. S3バケット作成(ストレージ構成用)
https://docs.databricks.com/aws/ja/admin/workspace/create-uc-workspace?language=Customer-managed%C2%A0VPC%C2%A0with%C2%A0custom%C2%A0restrictions#%E3%82%B9%E3%83%86%E3%83%83%E3%83%97-1-s3-%E3%83%90%E3%82%B1%E3%83%83%E3%83%88%E3%82%92%E4%BD%9C%E6%88%90%E3%81%99%E3%82%8B

### 参考
- DBFS と Unity Catalog のベスト プラクティス
https://docs.databricks.com/aws/ja/dbfs/unity-catalog

- Unity Catalog メタストア
https://docs.databricks.com/aws/ja/data-governance/unity-catalog/create-metastore

- 高度な構成
https://docs.databricks.com/aws/ja/admin/workspace/create-uc-workspace?language=Customer-managed%C2%A0VPC%C2%A0with%C2%A0custom%C2%A0restrictions#%E9%AB%98%E5%BA%A6%E3%81%AA%E6%A7%8B%E6%88%90

### S3バケット
バケット名：p20260000-de01-s12-bucket-test-001
リージョン：ap-northeast-1
暗号化タイプ：SSE-S3
バケットキー：無効
バケットポリシー：
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "Grant Databricks Access",
            "Effect": "Allow",
            "Principal": {
                "AWS": "arn:aws:iam::414351767826:root"
            },
            "Action": [
                "s3:GetObject",
                "s3:GetObjectVersion",
                "s3:PutObject",
                "s3:DeleteObject",
                "s3:ListBucket",
                "s3:GetBucketLocation"
            ],
            "Resource": [
                "arn:aws:s3:::p20260000-de01-s12-bucket-test-001/*",
                "arn:aws:s3:::p20260000-de01-s12-bucket-test-001"
            ],
            "Condition": {
                "StringEquals": {
                    "aws:PrincipalTag/DatabricksAccountId": "c7324012-9ae2-4541-a75d-3f0a0d213d4a"
                }
            }
        },
        {
            "Sid": "Prevent DBFS from accessing Unity Catalog metastore",
            "Effect": "Deny",
            "Principal": {
                "AWS": "arn:aws:iam::414351767826:root"
            },
            "Action": "s3:*",
            "Resource": "arn:aws:s3:::p20260000-de01-s12-bucket-test-001/unity-catalog/*"
        }
    ]
}

12. IAMロール作成(ストレージ構成用)
https://docs.databricks.com/aws/ja/admin/workspace/create-uc-workspace?language=Customer-managed%C2%A0VPC%C2%A0with%C2%A0custom%C2%A0restrictions#%E3%82%B9%E3%83%86%E3%83%83%E3%83%97-2-%E3%82%AB%E3%82%B9%E3%82%BF%E3%83%A0%E4%BF%A1%E9%A0%BC%E3%83%9D%E3%83%AA%E3%82%B7%E3%83%BC%E3%82%92%E4%BD%BF%E7%94%A8%E3%81%97%E3%81%A6-iam%E3%83%AD%E3%83%BC%E3%83%AB%E3%82%92%E4%BD%9C%E6%88%90%E3%81%99%E3%82%8B

### IAMロール
ロール名：p20260000-de01-s12-role-s3-001
信頼ポリシー
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Principal": {
                "AWS": [
                    "arn:aws:iam::414351767826:role/unity-catalog-prod-UCMasterRole-14S5ZJVKOTYTL",
                    "arn:aws:iam::139139346694:role/p20260000-de01-s12-role-s3-001"
                ]
            },
            "Action": "sts:AssumeRole",
            "Condition": {
                "StringEquals": {
                    "sts:ExternalId": "c7324012-9ae2-4541-a75d-3f0a0d213d4a"
                }
            }
        }
    ]
}

13. IAMポリシーを作成(ストレージ構成用)

### IAMポリシー
ポリシー名：p20260000-de01-s12-policy-s3-001
ポリシー
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetObject",
                "s3:PutObject",
                "s3:DeleteObject"
            ],
            "Resource": "arn:aws:s3:::p20260000-de01-s12-bucket-test-001/unity-catalog/*"
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:ListBucket",
                "s3:GetBucketLocation"
            ],
            "Resource": "arn:aws:s3:::p20260000-de01-s12-bucket-test-001"
        },
        {
            "Action": [
                "sts:AssumeRole"
            ],
            "Resource": [
                "arn:aws:iam::139139346694:role/p20260000-de01-s12-role-s3-001"
            ],
            "Effect": "Allow"
        }
    ]
}

ポリシー名：p20260000-de01-s12-policy-s3-002
ポリシー
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "ManagedFileEventsSetupStatement",
            "Effect": "Allow",
            "Action": [
                "s3:GetBucketNotification",
                "s3:PutBucketNotification",
                "sns:ListSubscriptionsByTopic",
                "sns:GetTopicAttributes",
                "sns:SetTopicAttributes",
                "sns:CreateTopic",
                "sns:TagResource",
                "sns:Publish",
                "sns:Subscribe",
                "sqs:CreateQueue",
                "sqs:DeleteMessage",
                "sqs:ReceiveMessage",
                "sqs:SendMessage",
                "sqs:GetQueueUrl",
                "sqs:GetQueueAttributes",
                "sqs:SetQueueAttributes",
                "sqs:TagQueue",
                "sqs:ChangeMessageVisibility",
                "sqs:PurgeQueue"
            ],
            "Resource": [
                "arn:aws:s3:::p20260000-de01-s12-bucket-test-001",
                "arn:aws:sqs:*:*:*",
                "arn:aws:sns:*:*:*"
            ]
        },
        {
            "Sid": "ManagedFileEventsListStatement",
            "Effect": "Allow",
            "Action": [
                "sqs:ListQueues",
                "sqs:ListQueueTags",
                "sns:ListTopics"
            ],
            "Resource": "*"
        },
        {
            "Sid": "ManagedFileEventsTeardownStatement",
            "Effect": "Allow",
            "Action": [
                "sns:Unsubscribe",
                "sns:DeleteTopic",
                "sqs:DeleteQueue"
            ],
            "Resource": [
                "arn:aws:sqs:*:*:*",
                "arn:aws:sns:*:*:*"
            ]
        }
    ]
}

14. Databricksにストレージ構成登録
https://docs.databricks.com/aws/ja/admin/workspace/create-uc-workspace?language=Customer-managed%C2%A0VPC%C2%A0with%C2%A0custom%C2%A0restrictions#%E3%82%B9%E3%83%86%E3%83%83%E3%83%97-4-%E3%82%B9%E3%83%88%E3%83%AC%E3%83%BC%E3%82%B8%E6%A7%8B%E6%88%90%E3%82%92%E4%BD%9C%E6%88%90%E3%81%99%E3%82%8B

### クラウドストレージ設定
ストレージ設定名：s3-test-001
バケット名：p20260000-de01-s12-bucket-test-001
IAMロールARN：arn:aws:iam::139139346694:role/p20260000-de01-s12-role-s3-001

15. us-west-2のSTSエンドポイントアクティブ化確認
https://docs.databricks.com/aws/ja/admin/workspace/create-uc-workspace?language=Databricks-managed%C2%A0VPC#%E5%BF%85%E8%A6%81%E6%9D%A1%E4%BB%B6

https://docs.aws.amazon.com/ja_jp/IAM/latest/UserGuide/id_credentials_temp_enable-regions.html#sts-regions-activate-deactivate

16. Databricksワークスペース作成
https://docs.databricks.com/aws/ja/admin/workspace/create-uc-workspace?language=Databricks-managed%C2%A0VPC#%E6%89%8B%E5%8B%95%E3%81%AEaws%E6%A7%8B%E6%88%90%E3%82%92%E4%BD%BF%E7%94%A8%E3%81%97%E3%81%A6databricks%E3%83%AF%E3%83%BC%E3%82%AF%E3%82%B9%E3%83%9A%E3%83%BC%E3%82%B9%E3%82%92%E4%BD%9C%E6%88%90%E3%81%99%E3%82%8B

https://docs.databricks.com/aws/ja/security/network/classic/privatelink#%E6%89%8B%E9%A0%86-4-privatelink-%E3%82%AA%E3%83%96%E3%82%B8%E3%82%A7%E3%82%AF%E3%83%88%E3%82%92%E4%BD%BF%E7%94%A8%E3%81%97%E3%81%A6%E3%83%AF%E3%83%BC%E3%82%AF%E3%82%B9%E3%83%9A%E3%83%BC%E3%82%B9%E3%82%92%E4%BD%9C%E6%88%90%E3%81%BE%E3%81%9F%E3%81%AF%E6%9B%B4%E6%96%B0%E3%81%99%E3%82%8B

### ワークスペース作成
ワークスペース名：p20260000-de01-s12-ws-001
リージョン：ap-northeast-1
クラウド資格情報：p20260000-de01-s12-credentialconf-001
クラウド ストレージ：s3-test-001
ネットワーク構成：p20260000-de01-s12-vpc-001
プライベートリンク：p20260000-de01-s12-privateaccess-001

### 注意事項
ワークスペースを作成すると、そのステータスがRUNNINGに変わり、関連する VPC ネットワークの更新がすぐに適用されます。
ただし、クラスターを作成または使用する前に、ステータスがRUNNINGと表示されてからさらに 20 分待ってください。
この時間より前にクラスターを作成または使用しようとすると、起動失敗、エラー、またはその他の予期しない動作が発生する可能性があります。

17. クラスタ起動テスト
https://docs.databricks.com/aws/ja/compute/cluster-config-best-practices

https://docs.databricks.com/aws/ja/compute/standard-limitations

https://docs.databricks.com/aws/ja/compute/simple-form

### Notebook作成

#### Python
spark.range(10).display()

#### SQL
SELECT 1

#### カタログとスキーマを作る
%sql
-- 1) カタログ作成
CREATE CATALOG IF NOT EXISTS uc_test
MANAGED LOCATION 's3://p20260000-de01-s12-bucket-test-001/unity-catalog/7474651933770269';

-- 2) スキーマ作成
CREATE SCHEMA IF NOT EXISTS uc_test.sandbox;

-- 3) 使う場所を指定
USE CATALOG uc_test;
USE SCHEMA sandbox;

#### managed table を作って SELECT
%sql
-- managed table（UC管理の保存先に格納される）
CREATE TABLE IF NOT EXISTS t_min (
  id INT,
  note STRING
);

INSERT INTO t_min VALUES (1, 'ok'), (2, 'hello');

SELECT * FROM t_min ORDER BY id;

18. 同一VPC内に2つ目のワークスペース作成

### ワークスペース用プライベートサブネット
名前：p20260000-de01-s12-vpc-001-priws-sn-1a-002
10.0.224.0/21

名前：p20260000-de01-s12-vpc-001-priws-sn-1c-002
10.0.232.0/21

名前：p20260000-de01-s12-vpc-001-priws-sn-1d-002
10.0.240.0/21

### RT
Name：p20260000-de01-s12-vpc-001-priws-sn-1a-002-rt
[ルート]
pl-61a54008 vpce-0c101d559d999ec68
0.0.0.0/0 nat-1a64901ccc345c8ce
10.0.0.0/16 local

Name：p20260000-de01-s12-vpc-001-priws-sn-1c-002-rt
[ルート]
pl-61a54008 vpce-0c101d559d999ec68
0.0.0.0/0 nat-1a64901ccc345c8ce
10.0.0.0/16 local

Name：p20260000-de01-s12-vpc-001-priws-sn-1d-002-rt
[ルート]
pl-61a54008 vpce-0c101d559d999ec68
0.0.0.0/0 nat-1a64901ccc345c8ce
10.0.0.0/16 local

### ワークスペース用SG
    名前：p20260000-de01-s12-sg-003
    VPC:p20260000-de01-s12-vpc-001
    Ingress（インバウンド）： 
        - 同一SGからのTCP全ポート許可(Sparkノード間通信用)
        - 同一SGからのUDP全ポート許可(Sparkノード間通信用)

    Egress（アウトバウンド）：
        - 同一SGからのTCP全ポート許可(Sparkノード間通信用)
        - 同一SGからのUDP全ポート許可(Sparkノード間通信用)
        - 次のポートで PrivateLinkエンドポイント用SG への TCP アクセスを許可します：
            - TCP 443：Databricksインフラストラクチャ
            - TCP 6666: セキュリティで保護されたクラスター接続用。 これは、 PrivateLink を使用する場合にのみ必要です。
            - TCP 2443: FIPS 暗号化をサポートします。 コンプライアンス セキュリティ プロファイルを有効にする場合にのみ必要です。
            - TCP 8443: DatabricksコンピュートプレーンからDatabricksコントロールプレーンAPIへの内部呼び出し用。
            - TCP 8444: Unity Catalogのログ記録とDatabricksへのリネージデータストリーミング用。
            - TCP 8445-8451: 将来的な拡張性。
        - 次のポートで 0.0.0.0/0 への TCP アクセスを許可します：(AWS Network firewallを配置する場合は向き先をFWに変更する)
            - TCP 443：クラウドデータソース、ライブラリリポジトリ用

### Databricksにネットワークオブジェクト登録
ネットワーク設定名：p20260000-de01-s12-vpc-001-priws-sn-002
VPC ID：vpc-082e68c8fd57b0edb
サブネットID：subnet-082313c286b59164f(p20260000-de01-s12-vpc-001-priws-sn-1a-002)
サブネットID：subnet-0e100bc79a204f9b7(p20260000-de01-s12-vpc-001-priws-sn-1c-002)
サブネットID：subnet-0ba88846d4c7808a7(p20260000-de01-s12-vpc-001-priws-sn-1d-002)
セキュリティグループID：sg-0b7f522889ee66340(p20260000-de01-s12-sg-002)
バックエンドプライベート接続 セキュアなクラスター接続を中継するためのVPCエンドポイント：p20260000-de01-s12-vpce-003
バックエンドプライベート接続 REST API用のVPCエンドポイント：p20260000-de01-s12-vpce-002

### Databricksワークスペース作成
ワークスペース名：p20260000-de01-s12-ws-002
リージョン：ap-northeast-1
クラウド資格情報：p20260000-de01-s12-credentialconf-001
クラウド ストレージ：s3-test-001
ネットワーク構成：p20260000-de01-s12-vpc-001-priws-sn-002
プライベートリンク：p20260000-de01-s12-privateaccess-001

### クラスタ起動テスト

#### Notebook作成

##### Python
spark.range(10).display()

##### SQL
SELECT 1

##### カタログとスキーマを作る
%sql
-- 1) カタログ作成
CREATE CATALOG IF NOT EXISTS uc_test_2
MANAGED LOCATION 's3://p20260000-de01-s12-bucket-test-001/unity-catalog/7474656285345256';

-- 2) スキーマ作成
CREATE SCHEMA IF NOT EXISTS uc_test_2.sandbox;

-- 3) 使う場所を指定
USE CATALOG uc_test_2;
USE SCHEMA sandbox;

##### managed table を作って SELECT
%sql
-- managed table（UC管理の保存先に格納される）
CREATE TABLE IF NOT EXISTS t_min (
  id INT,
  note STRING
);

INSERT INTO t_min VALUES (1, 'ok'), (2, 'hello');

SELECT * FROM t_min ORDER BY id;













# AWS Network Firewall配置
必要に応じて「AWS Network Firewall」をNATの手前に配置する
　許可：OSSレポジトリ/Git/外部API等のFQDN
　拒否：それ以外

# 確認事項

命名規則
同じ顧客管理VPCを全てのワークスペース間で共有する？
サブネットマスク設計

Unity Catalog
https://docs.databricks.com/aws/ja/data-governance/unity-catalog/get-started

Hive metastore
https://docs.databricks.com/aws/ja/database-objects/hive-metastore

インスタンスプロファイルを使用したS3へのアクセス
https://docs.databricks.com/aws/ja/security/network/classic/customer-managed-vpc#%E3%82%AA%E3%83%97%E3%82%B7%E3%83%A7%E3%83%B3%E3%82%A4%E3%83%B3%E3%82%B9%E3%82%BF%E3%83%B3%E3%82%B9%E3%83%97%E3%83%AD%E3%83%95%E3%82%A1%E3%82%A4%E3%83%AB%E3%82%92%E4%BD%BF%E7%94%A8%E3%81%97%E3%81%9Fs3%E3%81%B8%E3%81%AE%E3%82%A2%E3%82%AF%E3%82%BB%E3%82%B9

S3 バケットへのアクセスを制限
https://docs.databricks.com/aws/ja/security/network/classic/customer-managed-vpc#%E3%82%AA%E3%83%97%E3%82%B7%E3%83%A7%E3%83%B3s3-%E3%83%90%E3%82%B1%E3%83%83%E3%83%88%E3%81%B8%E3%81%AE%E3%82%A2%E3%82%AF%E3%82%BB%E3%82%B9%E3%82%92%E5%88%B6%E9%99%90%E3%81%99%E3%82%8B

fleetインスタンス向けのポリシー

コンプライアンス セキュリティ プロファイル
https://docs.databricks.com/aws/ja/admin/workspace/create-uc-workspace?language=Customer-managed%C2%A0VPC%C2%A0with%C2%A0custom%C2%A0restrictions#%E9%AB%98%E5%BA%A6%E3%81%AA%E6%A7%8B%E6%88%90
https://docs.databricks.com/aws/ja/security/privacy/enhanced-security-compliance


S3のストレージ認証情報と外部ロケーションを作成
https://docs.databricks.com/aws/ja/connect/unity-catalog/cloud-storage/s3/s3-external-location-manual#%E3%82%B9%E3%83%86%E3%83%83%E3%83%97-1-create-an-iam%E3%83%AD%E3%83%BC%E3%83%AB

Unity Catalog で管理されたストレージの場所を指定する
https://docs.databricks.com/aws/ja/connect/unity-catalog/cloud-storage/managed-storage


Unity Catalogメタストア、カタログ、スキーマ、テーブル/ビュー
外部ロケーション
メタストアのS3バケットパス設定


・１リージョンにつき１つのUCメタストアのみ設定可能
・同一リージョンのワークスペースは１つのUCメタストアを共有する
・UCメタストア配下の各カタログ毎に別のマネージドストレージロケーションを用意するのが推奨

UCメタストア用S3もリージョン単位？
１つのUCメタストア ＝ １つのS3では無い？
ワークスペース毎のS3分離は可能？



