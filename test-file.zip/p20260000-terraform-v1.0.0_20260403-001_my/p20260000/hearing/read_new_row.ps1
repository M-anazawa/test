$hearingDir = 'C:\Users\Administrator\Desktop\anazawa\PJ\Sphere\terumo\hearing'
$xlsxFile = Get-ChildItem $hearingDir -Filter '*.xlsx' | Select-Object -First 1
Write-Host "File: $($xlsxFile.Name)  Size: $($xlsxFile.Length) bytes"

$tempZip = "$hearingDir\nr_chk.zip"
$nrDir   = "$hearingDir\nr_tmp"
Copy-Item $xlsxFile.FullName $tempZip -Force
if (Test-Path $nrDir) { Remove-Item $nrDir -Recurse -Force }
Expand-Archive -Path $tempZip -DestinationPath $nrDir -Force
Remove-Item $tempZip

# Load shared strings
$ssRaw = [System.IO.File]::ReadAllText("$nrDir\xl\sharedStrings.xml", [System.Text.Encoding]::UTF8)
$siMatches = [regex]::Matches($ssRaw, '<si>(.*?)</si>', [System.Text.RegularExpressions.RegexOptions]::Singleline)
Write-Host "SharedStrings total: $($siMatches.Count)"

function Get-SSText($idx) {
    $i = [int]$idx
    if ($i -lt $siMatches.Count) {
        $texts = [regex]::Matches($siMatches[$i].Groups[1].Value, '<t[^>]*>([^<]*)</t>')
        return ($texts | ForEach-Object { $_.Groups[1].Value }) -join ''
    }
    return "###OUT_OF_RANGE($i)###"
}

# Load sheet2
$s2 = [System.IO.File]::ReadAllText("$nrDir\xl\worksheets\sheet2.xml", [System.Text.Encoding]::UTF8)

# Dimension
$dim = [regex]::Match($s2, 'ref="(A1:[^"]+)"')
Write-Host "Dimension: $($dim.Groups[1].Value)"

# Show all rows with full cell data
Write-Host "`n=== All rows - full content ==="
$rows = [regex]::Matches($s2, '<row r="(\d+)"[^>]*>(.*?)</row>', [System.Text.RegularExpressions.RegexOptions]::Singleline)
foreach ($row in $rows) {
    $rNum = $row.Groups[1].Value
    $rInt = [int]$rNum
    # Extract cells with values using a simpler approach
    $cellMatches = [regex]::Matches($row.Groups[2].Value, '<c r="([A-Z]+' + $rNum + ')"[^/]*?><v>(\d+)</v></c>')
    if ($cellMatches.Count -eq 0) { continue }
    Write-Host "  [Row $rNum]"
    foreach ($cell in $cellMatches) {
        $colRef = $cell.Groups[1].Value
        $ssIdx  = $cell.Groups[2].Value
        $txt    = Get-SSText([int]$ssIdx)
        $display = if ($txt.Length -gt 60) { $txt.Substring(0,60) + '…' } else { $txt }
        Write-Host "    $colRef = $display"
    }
}

Remove-Item $nrDir -Recurse -Force
