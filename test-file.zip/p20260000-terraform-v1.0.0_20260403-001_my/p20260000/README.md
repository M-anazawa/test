﻿# README.md
# INDEX

## 設計書

- アーキテクチャ設計書は `designs/アーキテクチャ設計書(*.**).md` を参照

- 詳細設計書は `designs/詳細設計書(*.**).md` を参照

## 各種ドキュメント

- Terraformリポジトリ構成は `docs/Terraformリポジトリ構成(*.**).md` を参照

- Terraformコーディングルールは `docs/Terraform実装方針(*.**).md` を参照

- リソースデプロイ方法は `docs/実装手順書(*.**).md` を参照

- WS動作確認方法は `docs/WS動作確認手順書(*.**).md` を参照

- ワークスペース利用方法は `docs/ワークスペース利用ガイド(*.**).md` を参照

- GitHub運用方法は `docs/GitHub運用手順書(*.**).md` を参照（将来作成予定）

- Terraform未経験用チュートリアルは `tutorials/` を参照
