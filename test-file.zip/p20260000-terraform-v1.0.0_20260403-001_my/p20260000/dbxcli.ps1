# ==================================================
# Databricks CLI ラッパー
# ==================================================
# Secrets Manager から認証情報を取得し、Databricks CLI を実行する
#
# Usage:
#   .\dbxcli.ps1 -Env dev -Level account -- account log-delivery list
#   .\dbxcli.ps1 -Env dev -Level account -- account credentials list
#   .\dbxcli.ps1 -Env dev -Level account -- account workspaces list
#   .\dbxcli.ps1 -Env dev -Level ws-001  -- clusters list
# ==================================================

param(
  [Parameter(Mandatory=$false)]
  [ValidateSet("dev","stg","prd")]
  [string]$Env = "dev",

  [Parameter(Mandatory=$false)]
  [string]$Level = "account",

  [Parameter(ValueFromRemainingArguments=$true)]
  [string[]]$DatabricksArgs
)

$ErrorActionPreference = "Stop"

# ==================================================
# 環境設定（ops.ps1 と同じロジック）
# ==================================================
switch ($Env) {
  "dev" {
    $envDir = Join-Path $PSScriptRoot "envs\01-dev"
    $tfvarsPrefix = "dev"
  }
  "stg" {
    $envDir = Join-Path $PSScriptRoot "envs\02-stg"
    $tfvarsPrefix = "stg"
  }
  "prd" {
    $envDir = Join-Path $PSScriptRoot "envs\03-prd"
    $tfvarsPrefix = "prd"
  }
}

$tfvarsCommon = Join-Path $envDir "$tfvarsPrefix.common.tfvars"
$tfvarsOps    = Join-Path $envDir "$tfvarsPrefix.ops.tfvars"

if (!(Test-Path $tfvarsCommon)) { throw "$tfvarsPrefix.common.tfvars not found: $tfvarsCommon" }
if (!(Test-Path $tfvarsOps))    { throw "$tfvarsPrefix.ops.tfvars not found: $tfvarsOps" }

# ==================================================
# ユーティリティ（ops.ps1 と同じ）
# ==================================================
function Get-TfvarsValue([string]$Key, [string[]]$Paths, [string]$Default = $null) {
  $pattern = "^\s*$([regex]::Escape($Key))\s*=\s*(.+?)\s*$"
  foreach ($path in $Paths) {
    $line = (Get-Content $path | Where-Object { $_ -match $pattern } | Select-Object -First 1)
    if ($line) {
      $v = ([regex]::Match($line, $pattern)).Groups[1].Value
      $v = ($v -split "\s+#",2)[0].Trim()
      $v = $v.Trim('"')
      return $v
    }
  }
  if ($null -ne $Default) { return $Default }
  throw "Key not found in tfvars: $Key"
}

# ==================================================
# AWS プロファイル設定
# ==================================================
$awsProfile  = Get-TfvarsValue "aws_profile" @($tfvarsOps)
$accountCode = Get-TfvarsValue "account_code" @($tfvarsCommon)

$env:AWS_PROFILE = $awsProfile

# ==================================================
# Secret ID 決定
# ==================================================
if ($Level -eq "account") {
  $secretId = "${accountCode}-s00-secret-dbx-sp-account-001"
} elseif ($Level -match "^ws-\d+$") {
  $secretId = "${accountCode}-s00-secret-dbx-sp-${Level}"
} else {
  throw "Invalid Level '$Level'. Use 'account' or 'ws-NNN' (e.g. ws-001, ws-002)."
}

# ==================================================
# Secrets Manager から認証情報を取得
# ==================================================
Write-Host "[dbxcli] Env=$Env, Level=$Level" -ForegroundColor Cyan
Write-Host "[dbxcli] Fetching credentials from: $secretId" -ForegroundColor Cyan

$secretJson = aws secretsmanager get-secret-value `
  --secret-id $secretId `
  --query SecretString `
  --output text 2>&1

if ($LASTEXITCODE -ne 0) {
  throw "Failed to retrieve secret '$secretId'.`nEnsure the secret exists and contains valid credentials.`n$secretJson"
}

$secret = $secretJson | ConvertFrom-Json

# ==================================================
# Databricks 環境変数を設定
# ==================================================
$env:DATABRICKS_HOST          = $secret.host
$env:DATABRICKS_CLIENT_ID     = $secret.client_id
$env:DATABRICKS_CLIENT_SECRET = $secret.client_secret

if ($secret.account_id) {
  $env:DATABRICKS_ACCOUNT_ID = $secret.account_id
} else {
  Remove-Item Env:\DATABRICKS_ACCOUNT_ID -ErrorAction SilentlyContinue
}

Write-Host "[dbxcli] Auth configured (host=$($secret.host))" -ForegroundColor Cyan

# ==================================================
# Databricks CLI 実行
# ==================================================
if ($DatabricksArgs.Count -eq 0) {
  Write-Host "[dbxcli] No command specified. Examples:" -ForegroundColor Yellow
  Write-Host "  .\dbxcli.ps1 -Env dev -Level account -- account log-delivery list" -ForegroundColor Yellow
  Write-Host "  .\dbxcli.ps1 -Env dev -Level account -- account credentials list" -ForegroundColor Yellow
  Write-Host "  .\dbxcli.ps1 -Env dev -Level account -- account workspaces list" -ForegroundColor Yellow
  Write-Host "  .\dbxcli.ps1 -Env dev -Level ws-001  -- clusters list" -ForegroundColor Yellow
  exit 0
}

# "--" separator を除去
$args2run = $DatabricksArgs | Where-Object { $_ -ne "--" }

Write-Host "[dbxcli] Running: databricks $($args2run -join ' ')" -ForegroundColor Cyan
& databricks @args2run
exit $LASTEXITCODE
