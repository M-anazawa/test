# Databricks on AWS 構築プロジェクト — オーケストレーター定義

## プロジェクト概要

Databricks on AWS（BYOC + PrivateLink）のインフラ構築プロジェクト。
フェーズ1（ヒヤリング）→ フェーズ2（設計）→ フェーズ3（Terraform）を順に進める。

## 確定済み前提条件（変更不可）

| 項目 | 内容 |
|------|------|
| AWSアカウント | 弊社管理の**新規**アWSアカウント |
| フロントエンド（UI） | **パブリックアクセス**（インターネット経由） |
| バックエンド | Control Plane ↔ Compute Plane 間は **AWS PrivateLink** |
| IaC ツール | **Terraform**（Databricks Provider + AWS Provider） |
| Databricks エディション | **Premium 以上**（PrivateLink・Unity Catalog 必須のため） |

---

## エージェント組織図

```
┌─────────────────────────────────────────────────────────────────┐
│           Claude Code（オーケストレーター／PM）                  │
│  役割: タスク分解・エージェント起動・品質ゲート管理・最終統合    │
└──────────────┬──────────────────────────────────────────────────┘
               │  Agent tool で起動
    ┌──────────┼───────────────────────┐
    ▼          ▼                       ▼
┌─────────┐ ┌──────────────────┐ ┌──────────────────────────────┐
│Creator  │ │ Doc Reviewer     │ │ ChatGPT（GPT-5.2）            │
│Agents   │ │ Agent（Claude）  │ │ mcp__chatgpt-bridge 経由     │
│         │ │                  │ │                              │
│・hearing│ │公式Docs取得      │ │・セカンドオピニオン           │
│・design │ │↕ 成果物と比較    │ │・代替案・ベストプラクティス   │
│・tf-gen │ │漏れ/誤り報告     │ │・リスク指摘                  │
└─────────┘ └──────────────────┘ └──────────────────────────────┘
```

---

## エージェント一覧と責務

### 1. Creator Agents（生成担当）

| エージェント | プロンプトファイル | 主な成果物 |
|---|---|---|
| HearingAgent | `.claude/agents/hearing-agent.md` | Excel ヒヤリングシート |
| ArchitectAgent | `.claude/agents/architect-agent.md` | 設計書（MD + 図）|
| TerraformAgent | `.claude/agents/terraform-agent.md` | HCL コード一式 |

### 2. Doc Reviewer Agent（検証担当）

| エージェント | プロンプトファイル | 検証対象 |
|---|---|---|
| DocReviewerAgent | `.claude/agents/doc-reviewer-agent.md` | 全成果物 × 公式Docs |

### 3. ChatGPT（GPT-5.2）統合

| フェーズ | ChatGPT の役割 | 使用モデル |
|---|---|---|
| ヒヤリング後 | 質問漏れ・観点の追加提案 | gpt-5.2 |
| 設計レビュー | アーキテクチャのセカンドオピニオン・代替案 | gpt-5.2 |
| Terraform レビュー | コード品質・セキュリティ観点のレビュー | gpt-5.2 |

---

## 品質ゲートフロー（全フェーズ共通）

```
[Step 1] Creator Agent が成果物を生成
            ↓
[Step 2] DocReviewerAgent を起動
         - 公式Docs を WebFetch で取得
         - 成果物との差分・漏れ・誤りを検出
         - reviews/{phase}/doc-review-{YYYYMMDD}.md に保存
            ↓
[Step 3] ChatGPT（GPT-5.2）にセカンドレビューを依頼
         - 成果物 + Doc Review 結果を送信
         - reviews/{phase}/chatgpt-review-{YYYYMMDD}.md に保存
            ↓
[Step 4] オーケストレーター（Claude）が両レビューを統合
         - 重大な指摘 → Creator Agent にフィードバックして再生成
         - 軽微な指摘 → ユーザーに選択肢を提示
            ↓
[Step 5] ユーザー承認後に次フェーズへ進む
```

**重要**: ユーザー承認なしに次フェーズへ進んではならない。

---

## オーケストレーターの行動規則

### タスク実行時
1. 必ず `.claude/agents/` 配下の該当プロンプトファイルを Read してから Agent tool でサブエージェントを起動する
2. Creator と Doc Reviewer は直列実行（CreatorAgent の成果物が揃ってから Reviewer を起動）
3. Doc Reviewer と ChatGPT レビューは並列実行可能
4. 全成果物は `outputs/` ではなく各フェーズのディレクトリ（`hearing/`, `design/`, `terraform/`）に保存する

### ChatGPT 呼び出し時
```
mcp__chatgpt-bridge__ask_chatgpt を使用し、以下を渡す：
- 成果物の全文または要約
- Doc Reviewer の指摘事項
- レビューして欲しい観点（フェーズにより異なる）
```

### レビュー結果の記録
- 全レビュー結果は `reviews/{phase}/` に保存
- ファイル名: `{doc-review|chatgpt-review}-YYYYMMDD-HHmm.md`

---

## フェーズ別 参照ドキュメント

### Phase 1: ヒヤリング
- [Databricks on AWS ドキュメント](https://docs.databricks.com/aws/en/)
- [Supported Regions](https://docs.databricks.com/aws/en/resources/supported-regions.html)
- [Customer-Managed VPC](https://docs.databricks.com/aws/en/security/network/classic/customer-managed-vpc.html)
- [PrivateLink](https://docs.databricks.com/aws/en/security/network/classic/privatelink.html)

### Phase 2: 設計
- [Network Architecture](https://docs.databricks.com/aws/en/security/network/index.html)
- [Unity Catalog](https://docs.databricks.com/aws/en/data-governance/unity-catalog/index.html)
- [Security Best Practices](https://docs.databricks.com/aws/en/security/security-overview.html)
- [AWS PrivateLink for Databricks](https://docs.databricks.com/aws/en/security/network/classic/privatelink.html)

### Phase 3: Terraform
- [Databricks Terraform Provider](https://registry.terraform.io/providers/databricks/databricks/latest/docs)
- [AWS Terraform Provider](https://registry.terraform.io/providers/hashicorp/aws/latest/docs)
- [Databricks Terraform GitHub](https://github.com/databricks/terraform-provider-databricks)

---

## ディレクトリ構造

```
databricks-aws/
├── CLAUDE.md                        # 本ファイル（オーケストレーター定義）
├── .claude/
│   └── agents/
│       ├── hearing-agent.md         # ヒヤリングシート生成エージェント
│       ├── architect-agent.md       # アーキテクチャ設計エージェント
│       ├── terraform-agent.md       # Terraform コード生成エージェント
│       └── doc-reviewer-agent.md    # 公式Docs照合レビュアー
├── hearing/                         # Phase 1 成果物
├── design/                          # Phase 2 成果物
│   └── diagrams/
├── terraform/                       # Phase 3 成果物
│   ├── modules/
│   └── environments/
│       ├── dev/
│       └── prod/
├── reviews/                         # 全フェーズのレビュー記録
│   ├── hearing/
│   ├── design/
│   └── terraform/
└── docs/
    └── official-refs/               # 公式ドキュメントのスナップショット
```

---

## 現在のフェーズステータス

| フェーズ | 状態 | 備考 |
|---|---|---|
| Phase 0: 前提確定 | ✅ 完了 | CLAUDE.md に記録済み |
| Phase 1: ヒヤリングシート | 🔄 進行中 | 設計必須版 作成済み、追加版は後日 |
| Phase 2: アーキテクチャ設計 | ⏳ 未開始 | Phase 1 完了後 |
| Phase 3: Terraform コード化 | ⏳ 未開始 | Phase 2 完了後 |
