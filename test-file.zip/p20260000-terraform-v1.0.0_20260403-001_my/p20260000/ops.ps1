param(
  [Parameter(Mandatory=$true)]
  [ValidateSet(
    "aws-main-s12-init",      "aws-main-s12-plan",      "aws-main-s12-apply",      "aws-main-s12-destroy",      "aws-main-s12-output",
    "aws-common-s00-init",      "aws-common-s00-plan",      "aws-common-s00-apply",      "aws-common-s00-destroy",      "aws-common-s00-output",
    "dbx-account-s12-init",   "dbx-account-s12-plan",   "dbx-account-s12-apply",   "dbx-account-s12-destroy",   "dbx-account-s12-output",
    "dbx-account-s00-init",   "dbx-account-s00-plan",   "dbx-account-s00-apply",   "dbx-account-s00-destroy",   "dbx-account-s00-output",
    "dbx-workspace-s12-init", "dbx-workspace-s12-plan", "dbx-workspace-s12-apply", "dbx-workspace-s12-destroy", "dbx-workspace-s12-output"
  )]
  [string]$Task,
  [Parameter(Mandatory=$false)]
  [ValidateSet("dev","stg","prd")]
  [string]$Env = "dev",
  [Parameter(Mandatory=$false)]
  [string[]]$Target
)

$ErrorActionPreference = "Stop"

# ==================================================
# 環境設定
# ==================================================
switch ($Env) {
  "dev" {
    $envDir = Join-Path $PSScriptRoot "envs\01-dev"
    $tfvarsPrefix = "dev"
  }
  "stg" {
    $envDir = Join-Path $PSScriptRoot "envs\02-stg"
    $tfvarsPrefix = "stg"
  }
  "prd" {
    $envDir = Join-Path $PSScriptRoot "envs\03-prd"
    $tfvarsPrefix = "prd"
  }
}

$backendConfig = Join-Path $envDir "backend.hcl"
$tfvarsCommon  = Join-Path $envDir "$tfvarsPrefix.common.tfvars"
$tfvarsOps     = Join-Path $envDir "$tfvarsPrefix.ops.tfvars"

if (!(Test-Path $backendConfig)) { throw "backend.hcl not found: $backendConfig" }
if (!(Test-Path $tfvarsCommon))  { throw "$tfvarsPrefix.common.tfvars not found: $tfvarsCommon" }
if (!(Test-Path $tfvarsOps))     { throw "$tfvarsPrefix.ops.tfvars not found: $tfvarsOps" }

# ==================================================
# スタック定義
# ==================================================
$Stacks = @{
  "aws-main-s12"    = @{ Dir = "stacks\10-aws-main-s12";    Key = "10-aws-main-s12/terraform.tfstate";    Tfvars = "$tfvarsPrefix.aws-main-s12.tfvars" }
  "aws-common-s00"    = @{ Dir = "stacks\20-aws-common-s00";    Key = "20-aws-common-s00/terraform.tfstate";    Tfvars = "$tfvarsPrefix.aws-common-s00.tfvars" }
  "dbx-account-s12" = @{ Dir = "stacks\30-dbx-account-s12"; Key = "30-dbx-account-s12/terraform.tfstate"; Tfvars = "$tfvarsPrefix.dbx-account-s12.tfvars" }
  "dbx-account-s00" = @{ Dir = "stacks\40-dbx-account-s00"; Key = "40-dbx-account-s00/terraform.tfstate"; Tfvars = "$tfvarsPrefix.dbx-account-s00.tfvars" }
  "dbx-workspace-s12" = @{ Dir = "stacks\50-dbx-workspace-s12"; Key = "50-dbx-workspace-s12/terraform.tfstate"; Tfvars = "$tfvarsPrefix.dbx-workspace-s12.tfvars" }
}

# ==================================================
# ユーティリティ
# ==================================================
function Get-TfvarsValue([string]$Key, [string[]]$Paths, [string]$Default = $null) {
  $pattern = "^\s*$([regex]::Escape($Key))\s*=\s*(.+?)\s*$"
  foreach ($path in $Paths) {
    $line = (Get-Content $path | Where-Object { $_ -match $pattern } | Select-Object -First 1)
    if ($line) {
      $v = ([regex]::Match($line, $pattern)).Groups[1].Value
      $v = ($v -split "\s+#",2)[0].Trim()
      $v = $v.Trim('"')
      return $v
    }
  }
  if ($null -ne $Default) { return $Default }
  throw "Key not found in tfvars: $Key"
}

$awsProfile = Get-TfvarsValue "aws_profile" @($tfvarsOps)
$region     = Get-TfvarsValue "region" @($tfvarsCommon) "ap-northeast-1"

$env:AWS_PROFILE = $awsProfile
$env:AWS_REGION  = $region

$accountCode = Get-TfvarsValue "account_code" @($tfvarsCommon)

$TerraformCmd = (Get-Command terraform -ErrorAction Stop).Source

# ==================================================
# Databricks 認証（Secrets Manager から自動取得）
# ==================================================
function Set-DatabricksAuth([string]$StackName) {
  if ($StackName -like "dbx-account-*") {
    $secretId = "${accountCode}-s00-secret-dbx-sp-account-001"
  } elseif ($StackName -like "dbx-workspace-*") {
    $secretId = "${accountCode}-s00-secret-dbx-sp-ws-001"
  } else {
    return  # AWS スタックは Databricks 認証不要
  }

  Write-Host "[ops] Fetching Databricks credentials from: $secretId" -ForegroundColor Cyan
  $secretJson = aws secretsmanager get-secret-value `
    --secret-id $secretId `
    --query SecretString `
    --output text 2>&1

  if ($LASTEXITCODE -ne 0) {
    throw "Failed to retrieve secret '$secretId'.`nEnsure the secret exists and contains valid credentials.`n$secretJson"
  }

  $secret = $secretJson | ConvertFrom-Json

  $env:DATABRICKS_HOST          = $secret.host
  $env:DATABRICKS_CLIENT_ID     = $secret.client_id
  $env:DATABRICKS_CLIENT_SECRET = $secret.client_secret

  if ($secret.account_id) {
    $env:DATABRICKS_ACCOUNT_ID = $secret.account_id
  } else {
    Remove-Item Env:\DATABRICKS_ACCOUNT_ID -ErrorAction SilentlyContinue
  }

  Write-Host "[ops] Databricks auth configured (host=$($secret.host))" -ForegroundColor Cyan
}

function Run-Terraform([string]$WorkDir, [string[]]$TfArgs) {
  if (!(Test-Path $WorkDir)) { throw "Directory not found: $WorkDir" }
  Push-Location $WorkDir
  try {
    & $TerraformCmd @TfArgs
    if ($LASTEXITCODE -ne 0) {
      throw "terraform failed ($LASTEXITCODE): $TerraformCmd $($TfArgs -join ' ')"
    }
  } finally {
    Pop-Location
  }
}

# ==================================================
# タスク解析・実行
# ==================================================
# Task = "aws-main-s12-plan" → StackName = "aws-main-s12", Action = "plan"
$lastDash   = $Task.LastIndexOf("-")
$stackName  = $Task.Substring(0, $lastDash)
$action     = $Task.Substring($lastDash + 1)
$stackCfg   = $Stacks[$stackName]

$workDir       = Join-Path $PSScriptRoot $stackCfg.Dir
$stateKey      = $stackCfg.Key
$tfvarsStack   = Join-Path $envDir $stackCfg.Tfvars
$tfvarsArgs    = @("-var-file=$tfvarsCommon", "-var-file=$tfvarsStack")
$targetArgs    = @()
if ($Target) {
  foreach ($t in $Target) { $targetArgs += "-target=$t" }
}

# Databricks スタックの場合、Secrets Manager から認証情報を自動取得
Set-DatabricksAuth $stackName

switch ($action) {
  "init" {
    Run-Terraform $workDir @(
      "init",
      "-migrate-state",
      "-backend-config=$backendConfig",
      "-backend-config=key=$stateKey"
    )
  }
  "plan" {
    if (!(Test-Path $tfvarsStack)) { throw "tfvars not found: $tfvarsStack" }
    Run-Terraform $workDir (@("plan") + $tfvarsArgs + $targetArgs)
  }
  "apply" {
    if (!(Test-Path $tfvarsStack)) { throw "tfvars not found: $tfvarsStack" }
    Run-Terraform $workDir (@("apply") + $tfvarsArgs + $targetArgs)
  }
  "destroy" {
    if (!(Test-Path $tfvarsStack)) { throw "tfvars not found: $tfvarsStack" }
    Run-Terraform $workDir (@("destroy") + $tfvarsArgs + $targetArgs)
  }
  "output" {
    Run-Terraform $workDir @("output")
  }
}
