# docs/Terraform実装方針(*.**).md
# Terraform 実装方針

このドキュメントは Terraform 実装の判断基準です。  
設計・実装・レビュー時に迷った場合は、**必ず本書に従う**こと。

---

## 1. 目的

- 命名規則・構成方針・環境差分の扱いを固定し、実装のブレを防ぐ
- レビュー基準を明確化し、手戻りを減らす
- dev/stg/prd を作る前提でも、差分を最小にして運用を簡単にする

---

## 2. 用語

- **account_code**: AWSアカウント識別子（例: `p20250022-de01`）
- **security_code**: セキュリティ用途識別子（例: `s00`, `s12`）
- **purpose**: 用途識別子（例: `pub`, `priapp`, `data`, `vpcflowlog` など）
- **resource_id**: リソース識別子（例: `vpc`, `sg`, `vpce`, `cmk`）
- **number**: 3桁番号（例: `001`）

---

## 3. 命名規則

- 命名規則（文字列の組み立て）は **スタック側で実装**する
- 命名は **各スタックの `02-locals.tf` に集約**し、他ファイルでの直書きは避ける
- ただし、一部の **purpose** と **number** は `04-variables.tf` で管理する

### 3.1 命名フォーマット

- 基本プレフィックス:  
  `(account_code)-(security_code)`

#### AWS リソース

- VPC:  
  `(account_code)-(security_code)-vpc-(3桁number)`  
  例: `p20250022-de01-s12-vpc-001`

- サブネット:  
  `(VPC名)-(用途)-sn-(AZ)-(3桁number)`  
  例: `p20250022-de01-s12-vpc-001-pub-sn-1a-001`  
  例: `p20250022-de01-s12-vpc-001-priws-sn-1c-001`

- ルートテーブル（パブリック）:  
  `(サブネット名からAZを取り除いた名前)-rt`  
  例: `p20250022-de01-s12-vpc-001-pub-sn-001-rt`

- ルートテーブル（プライベート）:  
  `(サブネット名)-rt`  
  例: `p20250022-de01-s12-vpc-001-priapp-sn-1a-001-rt`

- インターネットゲートウェイ:  
  `(VPC名)-igw`  
  例: `p20250022-de01-s12-vpc-001-igw`

- Regional NAT Gateway:  
  `(VPC名)-rnat`  
  例: `p20250022-de01-s12-vpc-001-rnat`

- Network Firewall:  
  `(account_code)-(security_code)-nfw-(3桁number)`  
  例: `p20250022-de01-s12-nfw-001`

- Network Firewall ポリシー:  
  `(account_code)-(security_code)-nfwpolicy-(3桁number)`  
  例: `p20250022-de01-s12-nfwpolicy-001`

- Network Firewall ルールグループ:  
  `(account_code)-(security_code)-nfwrulegroup-(3桁number)`  
  例: `p20250022-de01-s12-nfwrulegroup-001`

- セキュリティグループ:  
  `(account_code)-(security_code)-sg-(3桁number)`  
  例: `p20250022-de01-s12-sg-001`

- VPCエンドポイント:  
  `(account_code)-(security_code)-vpce-(3桁number)`  
  例: `p20250022-de01-s12-vpce-001`

- VPCフローログ:  
  `(VPC名)-flowlog-(3桁number)`  
  例: `p20250022-de01-s12-vpc-001-flowlog-001`

- IAMロール:  
  `(account_code)-(security_code)-role-(用途)-(3桁number)`  
  例: `p20250022-de01-s12-role-crossaccount-001`  
  例: `p20250022-de01-s12-role-extloc-storage-001`  
  例: `p20250022-de01-s12-role-extloc-input-001`

- IAMポリシー:  
  `(account_code)-(security_code)-policy-(用途)-(3桁number)`  
  例: `p20250022-de01-s12-policy-crossaccount-001`  
  例: `p20250022-de01-s12-policy-extloc-storage-001`

- S3:  
  `(account_code)-(security_code)-bucket-(用途)-(3桁number)`  
  例: `p20250022-de01-s12-bucket-data-001`  
  例: `p20250022-de01-s00-bucket-auditlogs-001`

- Secrets Manager:  
  `(account_code)-(security_code)-secret-(用途)-(3桁number)`  
  例: `p20250022-de01-s00-secret-dbx-sp-account-001`  
  例: `p20250022-de01-s00-secret-dbx-sp-ws-001`

#### Databricks リソース

- PrivateLinkオブジェクト名:  
  `VPCエンドポイント名`  
  例: `p20250022-de01-s12-vpce-002`

- ネットワークオブジェクト名:  
  `サブネット名からAZを取り除いた名前`  
  例: `p20250022-de01-s12-vpc-001-priws-sn-001`

- プライベートアクセス設定名:  
  `(account_code)-(security_code)-privateaccess-(3桁number)`  
  例: `p20250022-de01-s12-privateaccess-001`

- 資格情報設定名:  
  `(account_code)-(security_code)-credentialconf-(3桁number)`  
  例: `p20250022-de01-s12-credentialconf-001`

- ストレージ構成名:  
  `(account_code)-(security_code)-storageconf-(3桁number)`  
  例: `p20250022-de01-s12-storageconf-001`

- ワークスペース名:  
  `(account_code)-(security_code)-ws-(3桁number)`  
  例: `p20250022-de01-s12-ws-001`

- メタストア名:  
  `(account_code)-(security_code)-metastore-(3桁number)`  
  例: `p20250022-de01-s00-metastore-001`  
  ※ メタストアは全セキュリティレベル共有のため `s00` を使用する

- Audit log delivery設定名:  
  `(account_code)-(security_code)-logdelivery-(用途)-(3桁number)`  
  例: `p20250022-de01-s00-logdelivery-auditlogs-001`

- Storage Credential名:  
  `(account_code)-(security_code)-storagecred-(用途)-(3桁number)`  
  例: `p20250022-de01-s12-storagecred-extloc-storage-001`  
  例: `p20250022-de01-s12-storagecred-extloc-input-001`

- External Location名:  
  `(account_code)-(security_code)-extloc-(用途)-(3桁number)`  
  例: `p20250022-de01-s12-extloc-storage-001`  
  例: `p20250022-de01-s12-extloc-input-001`

- ユーザーグループ名:  
  `(account_code)-(security_code)-users_group-(3桁number)`  
  例: `p20250022-de01-s12-users_group-001`

- 上記以外（汎用）:  
  `(account_code)-(security_code)-(resource_id)-(3桁number)`

> NOTE: 「(3桁の番号)」「(用途)」「(リソース識別子)」は将来カスタマイズ可能とする。  
> ただしプロジェクト内では命名の揺れを出さない。

### 3.3 AWS name属性 / tags.Name の固定

- **AWSリソースの name 属性** は命名規則を遵守する
- name 属性が無い／固定できないリソースは tags.Name で固定する

---

## 4. モジュール設計方針

### 4.1 前提（方針）

- 各モジュールは **命名規則に縛られない汎用性の高い実装**とする
- モジュールは「名前を組み立てない」。必要な場合でも **外部から name / tags を受け取る**だけにする
- ただし、**ロググループ名はモジュール側での名前の組み立てを必要に応じて許可**する

### 4.2 モジュールに求める性質

- 入力はシンプル（必要最小限）
- 出力は実務で使うものだけ（過剰にしない）
- 可読性重視（魔法のような抽象化は避ける）
- `Name` タグの値は原則スタック側が決める
- `README.md` の作成は必須（記載の仕方は各モジュールで極力統一する）

---

## 5. スタック方針

### 5.1 スタックの役割

- スタックは **同一プロジェクト内の共通設定**（構成・依存関係・データ参照）を担う
- 環境差分（dev/stg/prd）は原則 **tfvars に寄せる**

### 5.2 セキュリティレベルによるスタック分離

- スタックは **セキュリティレベル（security_code）毎に分離**する
- 同一レイヤーでも `s00` と `s12` のリソースは別スタックとする
- スタック命名: `(番号)-(provider)-(用途)-(security_code)`

| スタック | security_code | 用途 |
|---------|---------------|------|
| 10-aws-main-s12 | s12 | AWS基盤リソース（VPC/SG/S3/IAM等） |
| 20-aws-common-s00 | s00 | s00共通AWSリソース（S3/IAM/Secrets Manager） |
| 30-dbx-account-s12 | s12 | Databricksアカウントレベル設定（NW/WS/グループ/メタストア割当） |
| 40-dbx-account-s00 | s00 | Databricksアカウントレベル設定（メタストア/監査ログ/資格情報/ストレージ構成） |
| 50-dbx-workspace-s12 | s12 | Databricks Workspace設定 / UC運用（SC/EL/権限/Entitlements） |

> NOTE: 同一 security_code 内でもレイヤー（AWS / Databricks Account / Databricks UC）が異なる場合はスタックを分ける。

---

## 6. 環境差分の管理（tfvars 方針）

### 6.1 方針

- 環境差分(dev/stg/prd)は **tfvars に寄せる**
- スタック毎に **tfvars を分ける**
- 複数スタック共通設定は ***.common.tfvars で管理する**

### 6.2 番号（number）の管理方針

#### 原則
- **環境によって番号（number）が変わらないリソース**は、番号（number）を **各スタックの `02-locals.tf` または `04-variables.tf` で管理**する

#### 例外（tfvars 管理）
- **環境によって番号（number）が異なる可能性があるリソース**のみ、番号（number）を **tfvars で管理**する  

#### 運用ルール
- tfvars に番号を置いた場合でも、**スタック側は最終的に `02-locals.tf` に集約して参照**する  

---

## 7. security_code 運用方針

- security_code は用途で変える（現状: `s00` または `s12`）

### 7.1 `s00`（システム管理共通）

- `s00` は **全セキュリティレベル共通のシステム管理リソース**として使用する
- 用途:
  - 監査ログ（S3/IAM/Databricks log delivery）
  - Secrets Manager（Databricks SP 認証情報）
  - メタストア（全セキュリティレベル共有、1リージョン1メタストア）
  - Databricks 資格情報・ストレージ構成（監査ログ用）

### 7.2 `s12`（Bronze Level）

- DBXのセキュリティレベル：Bronzeのリソースは `s12` を使用する

---

## 8. ドキュメントの管理

### 8.1 方針

- 運用・手順・ルール類のドキュメントは `docs/` 内で管理する
- 設計ドキュメント（詳細設計書、アーキテクチャ設計、工程表等）は `designs/` 内で管理する

---

## 9. リポジトリ（ディレクトリ）の構成

### 9.1 方針

- `docs/Terraformリポジトリ構成(*.**).md` 内で管理する

---

## 10. 例外 禁止事項

### 10.1 禁止事項

- 命名を各 `.tf` に散らして実装すること（`02-locals.tf` に集約する）
- name 属性や tags.Name の値を「その場しのぎ」で変えること
- `security_code` の意味を曖昧にして増やすこと
- **番号（number）を `.tf` に直書きすること**（必ず locals 経由）

### 10.2 例外

- AWS仕様により name 属性が固定できない、または provider 都合で固定が難しい場合
  - その場合も tags.Name は可能な限り固定する
- **特定リソースに強く紐づく data の場合**に限り、**同一リソース用 tf ファイルへの分散を許可**する
  - 可読性が明確に向上する場合のみ

---
