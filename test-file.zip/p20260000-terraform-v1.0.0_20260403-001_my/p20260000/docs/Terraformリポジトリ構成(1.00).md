# docs/Terraformリポジトリ構成(*.**).md

---

## 1. 概要

- 本リポジトリは Terraform の構成管理を目的とする
- 環境は dev / stg / prd に分けて管理する
- modules は再利用可能な Terraform モジュール、stacks は環境ごとの適用単位

---

## 2. リポジトリ構成

p20260000/
  designs/
    アーキテクチャ設計書(*.**).md                   # アーキテクチャ設計
    詳細設計書(*.**).md                             # 詳細設計書
    01-スケジュール-初期構築・コーディング(*.**).md  # スケジュール
  docs/
    コーディングルール(*.**).md                     # コーディングルール
    Terraformリポジトリ構成(*.**).md                # リポジトリ構成（本ファイル）
    実装手順書(*.**).md                             # リソースデプロイ手順
    GitHub運用手順書(*.**).md                       # GitHub 運用
    WS動作確認手順書(*.**).md                       # 動作確認手順書
    ワークスペース利用ガイド(*.**).md                # WS利用者向けガイド
  envs/
    01-dev/
      backend.hcl                  # state/lock
      dev.common.tfvars            # dev 共通
      dev.aws-main-s12.tfvars      # 10-aws-main-s12 用
      dev.aws-common-s00.tfvars    # 20-aws-common-s00 用
      dev.dbx-account-s12.tfvars   # 30-dbx-account-s12 用
      dev.dbx-account-s00.tfvars   # 40-dbx-account-s00 用
      dev.dbx-workspace-s12.tfvars # 50-dbx-workspace-s12 用
      dev.ops.tfvars               # ops 用
    02-stg/
    03-prd/
  modules/
    iam_policy/
      main.tf
      outputs.tf
      README.md
      variables.tf
    iam_role/
      main.tf
      outputs.tf
      README.md
      variables.tf
    kms/
      main.tf
      outputs.tf
      README.md
      variables.tf
    nat_gateway/
      main.tf
      outputs.tf
      README.md
      variables.tf
    network_firewall/
      main.tf
      outputs.tf
      README.md
      variables.tf
    s3/
      main.tf
      outputs.tf
      README.md
      variables.tf
    secrets_manager/
      main.tf
      outputs.tf
      README.md
      variables.tf
    security_groups/
      main.tf
      outputs.tf
      README.md
      variables.tf
    vpc/
      main.tf
      outputs.tf
      README.md
      variables.tf
    vpc_endpoints/
      main.tf
      outputs.tf
      README.md
      variables.tf
  stacks/
    10-aws-main-s12/
      00-versions.tf
      01-provider.tf
      02-locals.tf
      03-data.tf
      04-variables.tf
      05-guard.tf
      06-backend.tf
      11-vpc.tf
      12-nat-gateway.tf
      13-route-tables.tf
      14-security-groups.tf
      15-network-firewall.tf
      16-vpc-endpoints.tf
      17-s3.tf
      18-iam-crossaccount.tf
      19-iam-storage.tf
      20-iam-extloc-input.tf
      21-iam-extloc-output.tf
      99-outputs.tf
    20-aws-common-s00/
      00-versions.tf
      01-provider.tf
      02-locals.tf
      03-data.tf
      04-variables.tf
      05-guard.tf
      06-backend.tf
      11-s3.tf
      12-iam-auditlogs.tf
      13-secrets-manager.tf
      99-outputs.tf
    30-dbx-account-s12/
      00-versions.tf
      01-provider.tf
      02-locals.tf
      03-data.tf
      04-variables.tf
      05-guard.tf
      06-backend.tf
      11-privatelink.tf
      12-network.tf
      13-private-access.tf
      14-credentials.tf
      15-storage.tf
      16-workspace.tf
      17-metastore.tf
      18-groups.tf
      99-outputs.tf
    40-dbx-account-s00/
      00-versions.tf
      01-provider.tf
      02-locals.tf
      03-data.tf
      04-variables.tf
      05-guard.tf
      06-backend.tf
      11-credentials.tf
      12-storage.tf
      13-log-delivery.tf
      14-metastore.tf
      99-outputs.tf
    50-dbx-workspace-s12/
      00-versions.tf
      01-provider.tf
      02-locals.tf
      03-data.tf
      04-variables.tf
      05-guard.tf
      06-backend.tf
      11-workspace-conf.tf
      12-metastore-grants.tf
      13-storage-credential.tf
      14-external-location.tf
      15-storage-credential-grants.tf
      16-external-location-grants.tf
      17-entitlements.tf
      99-outputs.tf
  tutorials/                   # Terraformチュートリアル
    01-CreateS3LocalBackend.md
    02-CreateVpcBackendS3.md
  .gitignore
  dbxcli.ps1                   # Databricks CLI ラッパースクリプト (Windows)
  ops.ps1                      # デプロイ補助スクリプト (Windows)
  README.md
  tfops.cmd                    # デプロイ補助スクリプト (Windows)

---

## 3. ディレクトリの役割

### 3.1 designs/
- アーキテクチャ設計、詳細設計書、工程表

### 3.2 docs/
- 運用・ルール類のドキュメント、デプロイ手順、テスト手順、利用ガイド

### 3.3 envs/
- 環境別 tfvars を管理
- backend は `backend.hcl` で管理

### 3.4 modules/
- 再利用可能な Terraform モジュール

### 3.5 stacks/
- stack 毎の適用単位 (リソース単位)

---

## 4. stack ファイル構成

- `00-versions.tf`: Terraform / provider のバージョン
- `01-provider.tf`: provider 設定
- `02-locals.tf`: locals
- `03-data.tf`: data sources
- `04-variables.tf`: stack inputs
- `05-guard.tf`: ガード (検証)
- `06-backend.tf`: backend
- `11以降-*.tf`: 各リソース
- `99-outputs.tf`: outputs
- **例外**: 特定リソースに強く紐づく data は、可読性が明確に向上する場合のみ同一リソース用 tf に分散可

---

## 5. tfvars 構成

- `envs/01-dev` / `envs/02-stg` / `envs/03-prd` を環境ごとに運用

---
