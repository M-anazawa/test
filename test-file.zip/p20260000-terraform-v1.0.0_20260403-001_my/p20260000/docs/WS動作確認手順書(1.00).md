# WS動作確認手順書

本手順書では以下の動作確認を実施する。

| # | テスト項目 | 概要 |
|---|-----------|------|
| 68 | クラスター起動テスト | All-Purpose クラスターを作成し、正常に起動することを確認する |
| 69 | Notebook実行テスト | Notebookを作成し、クラスターでコードが実行できることを確認する |
| 69b | ネットワーク接続確認 | SCC / コントロールプレーン / S3 / 外部インターネットへの接続を確認する |
| 70 | Input/Output S3アクセステスト | External Location 経由で Input/Output S3 バケットへの読み書きを確認する |
| 70b | S3 バケットリスト表示確認 | dbutils.fs.ls でバケット内のファイル一覧を表示できることを確認する |
| 71 | UC Managed Storage テスト | Catalog の MANAGED LOCATION 設定と managed table の作成・読み書きを確認する |

---

## 前提条件

- Databricks ワークスペースが作成済みであること
- Unity Catalog（メタストア）がワークスペースに割り当て済みであること
- External Location（Input/Output/Storage）が作成済みであること
- テスト実施者のアカウントがワークスペースにアクセスできること

### 環境情報（dev環境）

| 項目 | 値 |
|------|-----|
| ワークスペース名 | p20250022-de01-s12-ws-001 |
| ワークスペースURL | https://<workspace-url>.cloud.databricks.com |
| Input バケット | p20250022-de01-s12-bucket-input-001 |
| Output バケット | p20250022-de01-s12-bucket-output-001 |
| Data バケット | p20250022-de01-s12-bucket-data-001 |
| Input External Location | p20250022-de01-s12-extloc-input-001 |
| Output External Location | p20250022-de01-s12-extloc-output-001 |
| Storage External Location（UC managed storage） | p20250022-de01-s12-extloc-storage-001 |
| Input External Location Credential | p20250022-de01-s12-storagecred-extloc-input-001 |
| Output External Location Credential | p20250022-de01-s12-storagecred-extloc-output-001 |
| Storage External Location Credential（UC managed storage） | p20250022-de01-s12-storagecred-extloc-storage-001 |

---

## #68 クラスター起動テスト

### 68-1. Databricks ワークスペースにログインする

    1. ブラウザで Databricks ワークスペース URL にアクセスする
    2. 認証情報を入力してログインする

### 68-2. All-Purpose クラスターを作成する

    1. 左サイドバー → コンピュート をクリック
    2. 「コンピュートを作成」ボタンをクリック
    3. 以下の設定を行う

    クラスター名: test-cluster-001
    Databricks Runtime: 最新のLTS版（例: 17.3 LTS）
    ノードタイプ: i3.xlarge（または利用可能な最小インスタンス）
    クラスターモード: シングルノード
    アクセスモード: 自動
    
    ※ その他の設定はデフォルトのまま

    4. 「作成」ボタンをクリック

### 68-3. クラスターの起動を確認する

    1. クラスターの状態が「緑色」に変わることを確認する
       ※ 起動には5〜10分程度かかる

    2. 確認項目:
       - 状態が「緑色」になること
       - イベントLogにエラーがないこと
         → クラスター詳細画面 → 「イベントLog」タブで確認

    3. エラーが発生した場合の確認ポイント:
       - セキュリティグループ（sg-001）のインバウンド/アウトバウンドルール
       - VPC Endpoint（vpce-002, vpce-003）の接続状態
       - IAM クロスアカウントロール（role-crossaccount-001）の信頼ポリシー

### 68-4. CLI でクラスターの状態を確認する（任意）

    .\dbxcli.ps1 -Env dev -Level ws-001 -- clusters list

    出力例:
    ID                    Name              State
    0324-003725-ftjnqgb8  test-cluster-001  RUNNING

---

## #69 Notebook実行テスト

### 69-1. Notebook を作成する

    1. 左サイドバー → ワークスペース をクリック
    2. 右上の「作成」→「ノートブック」をクリック
    3. 以下を設定する

    クラスター: test-cluster-001（#68で作成したクラスター）
    ノートブック名: test-notebook-001
    デフォルト言語: Python

### 69-2. 基本的なコード実行テスト

    セル1に以下を入力し、Shift+Enter で実行する:

    ```python
    # Spark 動作確認
    df = spark.range(1, 11)
    df.show()
    ```

    期待される出力:
    +---+
    | id|
    +---+
    |  1|
    |  2|
    |  3|
    |  4|
    |  5|
    |  6|
    |  7|
    |  8|
    |  9|
    | 10|
    +---+

### 69-3. Unity Catalog 接続テスト

    セル2に以下を入力し、実行する:

    ```python
    # Unity Catalog カタログ一覧の確認
    catalogs = spark.sql("SHOW CATALOGS")
    catalogs.show()
    ```

    期待される出力（少なくとも system カタログが表示されること）:
    +-------+
    |catalog|
    +-------+
    |samples|
    | system|
    +-------+

### 69-4. External Location 一覧テスト

    セル3に以下を入力し、実行する:

    ```python
    # External Location の確認
    locations = spark.sql("SHOW EXTERNAL LOCATIONS")
    locations.show(truncate=False)
    ```

    期待される出力:
    - p20250022-de01-s12-extloc-input-001
    - p20250022-de01-s12-extloc-output-001
    - p20250022-de01-s12-extloc-storage-001

    が表示されること

### 69-5. インターネット接続テスト

    セルに以下を入力し、実行する:

    ```python
    import urllib.request
    response = urllib.request.urlopen("https://www.google.com")
    print(f"ステータスコード: {response.status}")
    ```

    期待される出力:
    ステータスコード: 200

    ※ 失敗する場合の確認ポイント:
       - Network Firewall のルールで外部通信（TCP 443）が許可されているか
       - ルートテーブルの 0.0.0.0/0 が Firewall endpoint に向いているか
       - NAT Gateway が正常に動作しているか

### 69-6. VPC Endpoint 疎通テスト（STS）

    セルに以下を入力し、実行する:

    ```python
    import subprocess

    # STS エンドポイントの名前解決確認
    result = subprocess.run(
        ["getent", "hosts", "sts.ap-northeast-1.amazonaws.com"],
        capture_output=True,
        text=True
    )
    print(result.stdout)
    ```

    期待される出力:
    - VPCE のプライベート IP（例: `10.0.240.x / 10.0.241.x / 10.0.242.x`）が返ること
    - パブリック IP ではなく VPC 内アドレスであること

    次のセルに以下を入力し、実行する:

    ```sh
    %sh
    echo "=== DNS ==="
    getent hosts sts.ap-northeast-1.amazonaws.com || true

    echo
    echo "=== TCP 443 ==="
    nc -vz -w 5 sts.ap-northeast-1.amazonaws.com 443 || true

    echo
    echo "=== TLS ==="
    curl -Ivs https://sts.ap-northeast-1.amazonaws.com/ -m 10
    ```

    成功の判断基準:
    - `getent hosts` の結果が **プライベート IP** であること
    - `nc -vz -w 5 ... 443` で **open** となること
    - `curl -Ivs` で **TLS ハンドシェイクが完了**し、HTTP レスポンスが返ること
    - HTTP ステータスは `200` 固定ではなく、`302` などでも **疎通成功** と判断してよい

    > NOTE:
    > - `https://sts.ap-northeast-1.amazonaws.com/` へのアクセスは、実行方法によって `200` ではなく `302` を返す場合があります。
    > - この確認の目的は **STS Interface VPCE 経由で名前解決され、TCP/TLS レベルで到達できること** の確認です。
    > - そのため、`200` 固定ではなく、**DNS がプライベート IP を返すこと / TCP 443 が open であること / TLS セッション確立後に HTTP 応答が返ること** を成功条件とします。

    失敗する場合の確認ポイント:
    - VPC Endpoint（vpce-004: STS）が正常に作成されているか
    - セキュリティグループ（sg-001 / sg-002）で TCP 443 が許可されているか
    - Private DNS が有効になっているか

    ---

### 69-7. VPC Endpoint 疎通テスト（Kinesis Streams）

    セルに以下を入力し、実行する:

    ```python
    # Kinesis Streams エンドポイントの名前解決確認
    result = subprocess.run(["nslookup", "kinesis.ap-northeast-1.amazonaws.com"], capture_output=True, text=True)
    print(result.stdout)
    ```

    期待される出力:
    - VPCE のプライベート IP（10.0.240.x / 10.0.241.x / 10.0.242.x）が返ること

    次のセルに以下を入力し、実行する:

    ```python
    # Kinesis Streams エンドポイントへの疎通確認
    import urllib.request
    try:
        response = urllib.request.urlopen("https://kinesis.ap-northeast-1.amazonaws.com/")
        print(f"ステータスコード: {response.status}")
    except urllib.error.HTTPError as e:
        print(f"ステータスコード: {e.code}（疎通OK）")
    ```

    期待される出力:
    ステータスコード: 404（疎通OK）

    ※ Kinesis はルートパスへの GET リクエストに 404 を返しますが、
       レスポンスが返ること自体が VPCE 経由の疎通成功を意味します。
    ※ 失敗する場合の確認ポイント:
       - VPC Endpoint（vpce-005: Kinesis Streams）が正常に作成されているか
       - セキュリティグループ（sg-002）で TCP 443 が許可されているか
       - プライベート DNS が有効になっているか

### 69-8. 確認項目

    - 全てのセルがエラーなく実行されること
    - Spark ジョブが正常に完了すること
    - Unity Catalog への接続が確認できること

---

## 69b ネットワーク接続確認

    ※ #68 で作成したクラスターが起動済みであること
    ※ #69 で作成した test-notebook-001 を使用する

### 69b-1. SCC（Secure Cluster Connectivity）PrivateLink 接続確認

    SCC（Secure Cluster Connectivity）は、クラスターのコンピュートプレーンから Databricks Control Plane へ接続するためのセキュアトンネルである。  
    SCC 用の PrivateLink では、以下の FQDN を使用する。

    - PrivateLink 用: `tunnel.privatelink.ap-northeast-1.cloud.databricks.com`
    - 参考（公開系）: `tunnel.ap-northeast-1.cloud.databricks.com`

    > NOTE:
    > SCC は通常の Web アプリケーションのように HTTP 200 を返すことを確認する方式には適しません。  
    > `curl` による単純な HTTPS アクセスでは `timeout`、`connection refused`、`HTTP/0.9` などとなる場合があり、  
    > **それだけでは SCC 異常とは判断しません**。  
    > そのため本手順では、**DNS 解決結果** と **クラスター / Notebook の実動作** を主な確認観点とします。

    ### 69b-1-1. SCC PrivateLink 用 FQDN の名前解決確認

    新しいセルに以下を入力して実行する:

    ```sh
    %sh
    getent hosts tunnel.privatelink.ap-northeast-1.cloud.databricks.com
    ```

    成功の判断基準:
    - `10.x.x.x` のような **プライベート IP** が返ること
    - 3AZ 構成の場合、複数のプライベート IP が返ってもよい

    ### 69b-1-2. 参考確認（TCP/TLS 到達確認）

    必要に応じて、新しいセルに以下を入力して実行する:

    ```sh
    %sh
    echo "=== DNS ==="
    getent hosts tunnel.privatelink.ap-northeast-1.cloud.databricks.com || true

    echo
    echo "=== TCP 443 ==="
    nc -vz -w 5 tunnel.privatelink.ap-northeast-1.cloud.databricks.com 443 || true

    echo
    echo "=== TLS ==="
    curl -ivso /dev/null https://tunnel.privatelink.ap-northeast-1.cloud.databricks.com -kL -m10 || true
    ```

    判定方針:
    - DNS が **プライベート IP** を返していれば、Private DNS の設定は正常
    - `nc` / `curl` の結果が `timeout` / `refused` / `HTTP/0.9` であっても、**この結果だけで NG 判定しない**
    - SCC は内部トンネル用途のため、通常の HTTPS サービスのような安定したアプリケーション応答確認には向かない

    ### 69b-1-3. 実運用上の最終判定

    最終的には以下を満たす場合、SCC は **実用上 OK** と判断する:

    - クラスターが正常に起動する
    - Notebook のセル実行が継続して成功する
    - Control Plane 接続確認（69b-2）が成功する
    - Unity Catalog / External Location / S3 アクセステストが成功する

    > NOTE:
    > SCC PrivateLink は Notebook 上からの `curl` 単体では誤判定しやすいため、  
    > **DNS 解決結果 + クラスター実動作** を主判定とする。  
    > したがって、`tunnel.privatelink...` への直接 `curl` がタイムアウトしても、  
    > クラスター起動・Notebook 実行・Control Plane 通信が正常であれば、  
    > **少なくともワークスペース利用上の致命的異常とは判断しない**。

    ### 69b-1-4. 確認項目

    - SCC PrivateLink 用 FQDN がプライベート IP に解決されること
    - クラスターが正常に起動すること
    - Notebook が正常に実行できること
    - 他の Control Plane / UC / S3 テストが成功すること
    
### 69b-2. コントロールプレーン接続確認

    新しいセルに以下を入力して実行する:

    ```sh
    %sh
    curl -ivso /dev/null https://tokyo.cloud.databricks.com -kL -m10
    ```

    成功の判断基準:
    - 接続先 IP がプライベート IP（例: `10.0.x.x`）であること
      → PrivateLink 経由で名前解決されていることを示す
    - TLS 1.3 ハンドシェイクが完了し、証明書の CN が `*.cloud.databricks.com` であること
    - HTTP/2 303（`/login.html` へのリダイレクト）→ HTTP/2 200 が返ること
      → コントロールプレーンへの HTTPS 通信が正常に完了している

### 69b-3. S3 接続確認

    新しいセルに以下を入力して実行する:

    ```sh
    %sh
    curl -ivso /dev/null https://s3.ap-northeast-1.amazonaws.com -kL -m10
    ```

    成功の判断基準:
    - S3 エンドポイントへの TCP 接続・TLS ハンドシェイクが完了すること
    - HTTP 307（`https://aws.amazon.com/s3/` へのリダイレクト）が返ること
      → S3 のルートパスへの GET はリダイレクトを返す仕様のため、307 は正常      
    ※ 接続先 IP はグローバル IP が使用される

### 69b-4. 外部インターネットアクセス確認

    新しいセルに以下を入力して実行する:

    ```sh
    %sh
    curl -ivso /dev/null https://www.google.com/ -kL -m10
    ```

    成功の判断基準:
    - TLS 1.3 ハンドシェイクが完了すること
    - HTTP/2 200 が返ること
      → NAT Gateway + Network Firewall 経由でインターネットへの HTTPS 通信が許可されている
    ※ Network Firewall で外部アクセスを拒否している場合は、タイムアウトまたは接続拒否が正常

### 69b-5. 確認項目

    - SCC エンドポイント（tunnel.privatelink）がプライベート IP で解決され、TLS 接続が確立できること（PrivateLink 経由）
    - コントロールプレーン（tokyo）がプライベート IP で解決され、HTTP 200 が返ること（PrivateLink 経由）
    - S3 エンドポイントへの TLS 接続が成功し、HTTP レスポンスが返ること
    - 外部インターネット（Google）へのアクセスが Network Firewall ポリシー通りに動作すること

---

## #70 Input/Output S3アクセステスト

### 70-1. コンソールから External Location の接続検証を行う

    1. 左サイドバー → カタログ をクリック
    2. 左ペインの「外部ロケーション」をクリック
    3. 「p20250022-de01-s12-extloc-input-001」をクリック
    4. 右上の「接続のテスト」ボタンをクリック
    5. 結果が全て「成功」になることを確認する

    6. 同様に「p20250022-de01-s12-extloc-output-001」の接続テストも実施する
    7. 結果が全て「成功」になることを確認する

    ※ 「接続のテスト」が失敗する場合の確認ポイント:
       - Storage Credential の IAM ロール trust policy に正しい ExternalId が設定されているか
       - IAM ロールに対象 S3 バケットへのアクセス権限があるか
       - self-assume ポリシーが有効か

### 70-2. Input S3 バケットにテストデータをアップロードする

    AWS CLI でテスト用のCSVファイルをアップロードする:

    ```powershell
    # テスト用CSVファイルを作成
    @"
    id,name,value
    1,test-a,100
    2,test-b,200
    3,test-c,300
    "@ | Out-File -Encoding utf8NoBOM -FilePath test-data.csv

    # S3 にアップロード
    aws s3 cp test-data.csv s3://p20250022-de01-s12-bucket-input-001/test/test-data.csv --profile p20250022-de01
    ```

    アップロード確認:
    ```powershell
    aws s3 ls s3://p20250022-de01-s12-bucket-input-001/test/ --profile p20250022-de01
    ```

### 70-3. Notebook から Input S3 の読み取りテストを行う

    #69 で作成した test-notebook-001 を開き、新しいセルに以下を入力して実行する:

    ```python
    # Input S3 バケットからの読み取り
    df_input = spark.read.format("csv") \
        .option("header", "true") \
        .option("inferSchema", "true") \
        .load("s3://p20250022-de01-s12-bucket-input-001/test/test-data.csv")

    df_input.show()
    df_input.printSchema()
    ```

    期待される出力:
    +---+------+-----+
    | id|  name|value|
    +---+------+-----+
    |  1|test-a|  100|
    |  2|test-b|  200|
    |  3|test-c|  300|
    +---+------+-----+

    root
     |-- id: integer (nullable = true)
     |-- name: string (nullable = true)
     |-- value: integer (nullable = true)

### 70-4. Notebook から Output S3 への書き込みテストを行う

    新しいセルに以下を入力して実行する:

    ```python
    # Output S3 バケットへの書き込み（Delta形式）
    df_output = spark.createDataFrame([
        (1, "output-a", 1000),
        (2, "output-b", 2000),
        (3, "output-c", 3000)
    ], ["id", "name", "value"])

    df_output.write.format("delta") \
        .mode("overwrite") \
        .save("s3://p20250022-de01-s12-bucket-output-001/test/output-data")

    print("書き込み完了")
    ```

    期待される出力:
    書き込み完了

### 70-5. Output S3 への書き込み結果を確認する

    新しいセルに以下を入力して実行する:

    ```python
    # 書き込んだデータの読み戻し確認（Delta形式）
    df_verify = spark.read.format("delta") \
        .load("s3://p20250022-de01-s12-bucket-output-001/test/output-data")

    df_verify.show()
    print(f"レコード数: {df_verify.count()}")
    ```

    期待される出力:
    +---+--------+-----+
    | id|    name|value|
    +---+--------+-----+
    |  1|output-a| 1000|
    |  2|output-b| 2000|
    |  3|output-c| 3000|
    +---+--------+-----+

    レコード数: 3

    AWS CLI でも確認する:
    ```powershell
    aws s3 ls s3://p20250022-de01-s12-bucket-output-001/test/output-data/ --profile p20250022-de01
    ```

### 70-6. Input S3 から読み取って Output S3 に書き込む結合テスト

    新しいセルに以下を入力して実行する:

    ```python
    # Input から読み取り（CSV）→ 加工 → Output に書き込み（Delta）
    df_source = spark.read.format("csv") \
        .option("header", "true") \
        .option("inferSchema", "true") \
        .load("s3://p20250022-de01-s12-bucket-input-001/test/test-data.csv")

    # 簡単な加工（value を2倍にする）
    from pyspark.sql.functions import col
    df_transformed = df_source.withColumn("value_doubled", col("value") * 2)

    # Output に書き込み（Delta形式）
    df_transformed.write.format("delta") \
        .mode("overwrite") \
        .save("s3://p20250022-de01-s12-bucket-output-001/test/transformed-data")

    # 結果確認
    df_result = spark.read.format("delta") \
        .load("s3://p20250022-de01-s12-bucket-output-001/test/transformed-data")

    df_result.show()
    ```

    期待される出力:
    +---+------+-----+-------------+
    | id|  name|value|value_doubled|
    +---+------+-----+-------------+
    |  1|test-a|  100|          200|
    |  2|test-b|  200|          400|
    |  3|test-c|  300|          600|
    +---+------+-----+-------------+

---

## 70b S3 バケットリスト表示確認

    ※ #68 で作成したクラスターが起動済みであること
    ※ #69 で作成した test-notebook-001 を使用する

### 70b-1. Input バケットのリスト表示

    新しいセルに以下を入力して実行する:

    ```python
    dbutils.fs.ls("s3a://p20250022-de01-s12-bucket-input-001")
    ```

    期待される出力:
    バケット内のディレクトリが表示されること（空の場合は空リスト）

### 70b-2. Output バケットのリスト表示

    新しいセルに以下を入力して実行する:

    ```python
    dbutils.fs.ls("s3a://p20250022-de01-s12-bucket-output-001")
    ```

    期待される出力:
    バケット内のディレクトリが表示されること（空の場合は空リスト）

### 70b-3. UC managed storage パスのリスト表示

    新しいセルに以下を入力して実行する:

    ```python
    dbutils.fs.ls("s3a://p20250022-de01-s12-bucket-data-001/unity-catalog/")
    ```

    期待される出力:
    unity-catalog 配下のディレクトリが表示されること

### 70b-4. 確認項目

    - Input バケットに対して dbutils.fs.ls でディレクトリ表示ができること
    - Output バケットに対して dbutils.fs.ls でディレクトリ表示ができること
    - Data バケットの unity-catalog/ 配下に対して dbutils.fs.ls でディレクトリ表示ができること

---

## 71 UC Managed Storage テスト

    ※ #68 で作成したクラスターが起動済みであること
    ※ #69 で作成した test-notebook-001 を使用する

### 71-1. Catalog を作成し MANAGED LOCATION を設定する

    test-notebook-001 を開き、新しいセルに以下を入力して実行する:

    ```sql
    CREATE CATALOG IF NOT EXISTS test_catalog
    MANAGED LOCATION 's3://p20250022-de01-s12-bucket-data-001/unity-catalog/test_catalog/';
    ```

    期待される出力:
    OK（エラーなく完了すること）

    ※ エラーになる場合の確認ポイント:
       - Storage Credential（storagecred-extloc-storage-001）が作成済みか
       - role-extloc-storage-001 の trust policy に正しい ExternalId が設定されているか
       - メタストアに対する CREATE_STORAGE_CREDENTIAL 権限があるか

### 71-2. Schema を作成する

    新しいセルに以下を入力して実行する:

    ```sql
    CREATE SCHEMA IF NOT EXISTS test_catalog.test_schema;
    ```

    期待される出力:
    OK

### 71-3. Managed Table を作成する

    新しいセルに以下を入力して実行する:

    ```python
    # テスト用 managed table の作成
    df = spark.createDataFrame([
        (1, "managed-a", 100),
        (2, "managed-b", 200),
        (3, "managed-c", 300)
    ], ["id", "name", "value"])

    df.write.format("delta") \
        .mode("overwrite") \
        .saveAsTable("test_catalog.test_schema.test_table")

    print("managed table 作成完了")
    ```

    期待される出力:
    managed table 作成完了

### 71-4. Managed Table の読み取りを確認する

    新しいセルに以下を入力して実行する:

    ```python
    # managed table からの読み取り確認
    df_read = spark.table("test_catalog.test_schema.test_table")
    df_read.show()
    print(f"レコード数: {df_read.count()}")
    ```

    期待される出力:
    +---+---------+-----+
    | id|     name|value|
    +---+---------+-----+
    |  1|managed-a|  100|
    |  2|managed-b|  200|
    |  3|managed-c|  300|
    +---+---------+-----+

    レコード数: 3

### 71-5. Managed Table の保存先を確認する

    新しいセルに以下を入力して実行する:

    ```sql
    %sql
    DESCRIBE DETAIL test_catalog.test_schema.test_table;
    ```

    期待される出力:
    location 列の値が s3://p20250022-de01-s12-bucket-data-001/unity-catalog/test_catalog/ 配下であること

### 71-6. テスト用 Catalog / Schema / Table を削除する

    新しいセルに以下を入力して実行する:

    ```sql
    DROP TABLE IF EXISTS test_catalog.test_schema.test_table;
    DROP SCHEMA IF EXISTS test_catalog.test_schema CASCADE;
    DROP CATALOG IF EXISTS test_catalog CASCADE;
    ```

    期待される出力:
    OK（エラーなく完了すること）

### 71-7. 確認項目

    - Catalog に MANAGED LOCATION を設定できること
    - managed table の作成・読み取りがエラーなく完了すること
    - テーブルの保存先が s3://bucket-data-001/unity-catalog/ 配下であること
    - テスト用リソースのクリーンアップが正常に完了すること

---

## テスト後のクリーンアップ

### テストデータの削除

    ```powershell
    # Input バケットのテストデータ削除
    aws s3 rm s3://p20250022-de01-s12-bucket-input-001/test/ --recursive --profile p20250022-de01

    # Output バケットのテストデータ削除
    aws s3 rm s3://p20250022-de01-s12-bucket-output-001/test/ --recursive --profile p20250022-de01
    ```

### テストクラスターの削除

    テスト完了後、クラスターを完全に削除する:

    1. 左サイドバー → コンピュート
    2. test-cluster-001 が「停止」であることを確認
    3. test-cluster-001 の行の右端「︙」→「削除」をクリック

    または CLI で実行:
    ```powershell
    .\dbxcli.ps1 -Env dev -Level ws-001 -- clusters permanent-delete <cluster_id>
    ```

### テスト Notebook の削除

    1. 左サイドバー → ワークスペース
    2. test-notebook-001 を右クリック →「ゴミ箱に移動」

---

## テスト結果記録

| # | テスト項目 | 結果 | 実施日 | 実施者 | 備考 |
|---|-----------|------|-------|--------|------|
| 68 | クラスター起動テスト | OK / NG | | | |
| 69 | Notebook実行テスト | OK / NG | | | |
| 69b-1 | SCC 接続確認 | OK / NG | | | |
| 69b-2 | コントロールプレーン接続確認 | OK / NG | | | |
| 69b-3 | S3 接続確認 | OK / NG | | | |
| 69b-4 | 外部インターネットアクセス確認 | OK / NG | | | |
| 70-1 | External Location 接続検証（Input） | OK / NG | | | |
| 70-1 | External Location 接続検証（Output） | OK / NG | | | |
| 70-3 | Input S3 読み取り | OK / NG | | | |
| 70-4 | Output S3 書き込み | OK / NG | | | |
| 70-5 | Output S3 読み戻し確認 | OK / NG | | | |
| 70-6 | Input→Output 結合テスト | OK / NG | | | |
| 70b-1 | Input バケット リスト表示 | OK / NG | | | |
| 70b-2 | Output バケット リスト表示 | OK / NG | | | |
| 70b-3 | UC managed storage リスト表示 | OK / NG | | | |
| 71-1 | Catalog MANAGED LOCATION 設定 | OK / NG | | | |
| 71-3 | Managed Table 作成 | OK / NG | | | |
| 71-4 | Managed Table 読み取り | OK / NG | | | |
| 71-5 | 保存先パス確認 | OK / NG | | | |
