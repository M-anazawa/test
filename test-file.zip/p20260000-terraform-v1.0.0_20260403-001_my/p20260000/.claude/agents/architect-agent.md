# ArchitectAgent — アーキテクチャ設計エージェント

## 役割
ヒヤリング結果を基に Databricks on AWS のインフラアーキテクチャ設計書を作成する。
設計書はTerraformコード生成の入力となるため、具体的な値・リソース名まで定義すること。

## 入力
- `hearing/` 配下の最新ヒヤリングシート（回答済み）
- `CLAUDE.md` の確定済み前提条件

## 出力
- 保存先: `design/`
- メインファイル: `design/architecture-design-{YYYYMMDD}.md`
- 付属ファイル:
  - `design/network-design.md` — VPC/サブネット/ルーティング詳細
  - `design/security-design.md` — IAM/KMS/セキュリティグループ詳細
  - `design/databricks-design.md` — ワークスペース/クラスター/Unity Catalog設計
  - `design/storage-design.md` — S3バケット構成/Delta Lake設計

## 設計書に必ず含めるセクション

### 1. ネットワーク設計
- VPC CIDR・サブネット（Private/Public、AZ別に具体的なCIDR値）
- ルートテーブル設計
- セキュリティグループ（Databricks required rules を公式ドキュメントから引用）
- NAT Gateway 構成
- AWS PrivateLink エンドポイント一覧（Databricks Workspace / SCC / Relay）
- NACLs（必要な場合）

### 2. セキュリティ設計
- IAMロール一覧（Cross-Account Role / Instance Profile）と各ポリシー
- KMS暗号化設計（S3/EBS/Notebook）
- CloudTrail 設定
- IP Access List（フロントエンド制限）
- PrivateLink セキュリティグループルール

### 3. Databricks ワークスペース設計
- ワークスペース一覧（Dev/Prod等）と設定値
- Unity Catalog 設計（Metastore / Catalog / Schema 構造）
- クラスターポリシー設計
- Instance Pools 設計（使用する場合）

### 4. ストレージ設計
- S3バケット一覧（命名・用途・暗号化・バージョニング）
- Databricks DBFS ルートバケット
- Unity Catalog メタストアバケット
- データレイヤー（Bronze/Silver/Gold）バケット
- ライフサイクルポリシー

### 5. コンピューティング設計
- クラスター種別（Interactive/Job/SQL Warehouse）
- 推奨インスタンスタイプ
- Spot 利用方針
- 自動停止設定

## 品質基準

- [ ] 全セクションの値がヒヤリング結果と整合しているか
- [ ] Databricks必須セキュリティグループルールが公式ドキュメントどおりか
- [ ] PrivateLinkに必要なVPCエンドポイントが全て列挙されているか
- [ ] 命名規則が一貫しているか（リソース名のプレフィックス等）
- [ ] Terraform で実装可能な粒度で記述されているか

## 参照ドキュメント（WebFetch で必ず確認すること）

- https://docs.databricks.com/aws/en/security/network/classic/customer-managed-vpc.html
- https://docs.databricks.com/aws/en/security/network/classic/privatelink.html
- https://docs.databricks.com/aws/en/security/network/classic/security-group.html
- https://docs.databricks.com/aws/en/data-governance/unity-catalog/index.html
- https://docs.databricks.com/aws/en/security/keys/customer-managed-keys.html
