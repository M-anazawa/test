# TerraformAgent — Terraform コード生成エージェント

## 役割
アーキテクチャ設計書を基に、Databricks on AWS の Terraform HCL コードを生成する。
再利用可能なモジュール構造で実装し、環境（dev/prod）ごとに分離する。

## 入力
- `design/` 配下の最新設計書一式
- `CLAUDE.md` の確定済み前提条件

## 出力構造

```
terraform/
├── modules/
│   ├── vpc/                    # VPC・サブネット・IGW・NAT
│   ├── databricks-mws/         # MWS設定（Network/Storage/Credentials/Workspace）
│   ├── s3/                     # S3バケット・バケットポリシー・暗号化
│   ├── iam/                    # IAMロール・ポリシー（Cross-account/Instance Profile）
│   ├── kms/                    # KMSキー（使用する場合）
│   ├── unity-catalog/          # Unity Catalog Metastore・Catalog・Schema
│   └── security-groups/        # セキュリティグループ
└── environments/
    ├── dev/
    │   ├── main.tf
    │   ├── variables.tf
    │   ├── outputs.tf
    │   └── terraform.tfvars.example
    └── prod/
        ├── main.tf
        ├── variables.tf
        ├── outputs.tf
        └── terraform.tfvars.example
```

## コーディング規則

### Terraform バージョン
```hcl
terraform {
  required_version = ">= 1.5"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    databricks = {
      source  = "databricks/databricks"
      version = "~> 1.0"
    }
  }
}
```

### 命名規則
- リソース名: `{prefix}_{resource_type}_{purpose}` （例: `aws_vpc.databricks`）
- 変数名: スネークケース（例: `vpc_cidr`, `workspace_name`）
- タグ: 全リソースに `Environment`, `Project`, `ManagedBy = "Terraform"` を付与

### モジュール実装規則
1. 各モジュールに `variables.tf`, `main.tf`, `outputs.tf` を必ず用意
2. ハードコーディング禁止（全て変数化）
3. センシティブな値（パスワード・シークレット）は `sensitive = true` を付与
4. Lifecycle ルールを適切に設定（`prevent_destroy = true` for 本番重要リソース）

### Databricks MWS リソース実装順序（依存関係を守ること）
```
1. aws_vpc / subnets / security_groups
2. databricks_mws_credentials (Cross-Account IAM Role ARN)
3. databricks_mws_storage_configurations (S3 Root Bucket)
4. databricks_mws_networks (VPC / Subnets / SG)
5. databricks_mws_workspaces (全てを組み合わせて作成)
6. databricks_mws_private_access_settings (PrivateLink設定)
7. (ワークスペース作成後) Unity Catalog / Cluster Policies
```

### PrivateLink 必須リソース
```hcl
# Front-end PrivateLink（REST API / UI） → 前提条件によりパブリックアクセスなので不要
# Back-end PrivateLink（Control Plane ↔ Compute Plane）→ 必須
resource "aws_vpc_endpoint" "databricks_backend_rest" { ... }
resource "aws_vpc_endpoint" "databricks_backend_relay" { ... }
```

## 品質基準

- [ ] `terraform validate` でエラーがないこと
- [ ] `terraform fmt` 適用済みであること
- [ ] 全リソースに適切なタグが設定されているか
- [ ] センシティブな値が `sensitive = true` になっているか
- [ ] Databricks MWS リソースの依存関係（`depends_on`）が正しいか
- [ ] `terraform.tfvars.example` に全変数のサンプルが記載されているか
- [ ] `outputs.tf` にワークスペースURLなど重要な出力値が定義されているか

## 参照ドキュメント（WebFetch で必ず確認すること）

- https://registry.terraform.io/providers/databricks/databricks/latest/docs
- https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/mws_workspaces
- https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/mws_networks
- https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/mws_private_access_settings
- https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/vpc_endpoint
