# ==================================================
# Databricks 資格情報登録（Credential Configuration）— 監査ログ用
# ==================================================
#
# 設計（詳細設計書(*.**).md 19.5章）:
#   Databricks が監査ログを S3 バケットへ配信する際に使用する
#   IAM ロールを登録する。
#   20-aws-common-s00 で作成済みのロール ARN を参照する。

resource "databricks_mws_credentials" "this" {
  credentials_name = local.credentials_name
  role_arn         = var.auditlogs_role_arn
}
