# ==================================================
# Databricks ストレージ構成登録（Storage Configuration）— 監査ログ用
# ==================================================
#
# 設計（詳細設計書(*.**).md 19.5章）:
#   監査ログ配信先の S3 バケットを Databricks アカウントに登録する。
#   20-aws-common-s00 で作成済みの S3 バケット名を locals から参照する。

resource "databricks_mws_storage_configurations" "this" {
  account_id                 = var.databricks_account_id
  storage_configuration_name = local.storage_configuration_name
  bucket_name                = local.storage_bucket_name
}
