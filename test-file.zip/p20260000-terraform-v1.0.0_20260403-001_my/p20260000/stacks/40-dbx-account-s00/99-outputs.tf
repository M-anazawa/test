# ==================================================
# 資格情報
# ==================================================

output "credentials_id" {
  description = "Databricks 資格情報 ID（監査ログ用）"
  value       = databricks_mws_credentials.this.credentials_id
}

# ==================================================
# ストレージ構成
# ==================================================

output "storage_configuration_id" {
  description = "Databricks ストレージ構成 ID（監査ログ用）"
  value       = databricks_mws_storage_configurations.this.storage_configuration_id
}

# ==================================================
# Audit log delivery
# ==================================================

output "log_delivery_config_id" {
  description = "Databricks Audit log delivery 設定 ID"
  value       = databricks_mws_log_delivery.audit_logs.config_id
}

# ==================================================
# メタストア
# ==================================================

output "metastore_id" {
  description = "Databricks メタストア ID"
  value       = databricks_metastore.this.metastore_id
}
