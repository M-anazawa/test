variable "account_id" {
  type = string
}

variable "region" {
  type    = string
  default = "ap-northeast-1"
}

variable "account_code" {
  type = string
}

variable "security_code_monitoring" {
  type    = string
  default = "s00"
}

# Databricks
variable "databricks_account_id" {
  description = "Databricks Account ID"
  type        = string
}

# Credentials（20-aws-common-s00 の output から取得）
variable "auditlogs_role_arn" {
  description = "監査ログ用 IAM ロール ARN（20-aws-common-s00 output iam_auditlogs_role_arn）"
  type        = string
}

# メタストア owner（共通 SP）
variable "sp_application_id" {
  description = "サービスプリンシパルの Application ID（メタストア owner に設定）"
  type        = string
}
