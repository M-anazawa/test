# メタストア作成
# NOTE: メタストアは全セキュリティレベル共有（s00）のリージョン単位リソース
#       storage_root は設定しない（metastore-level storage 未使用）
#       managed storage は catalog/schema レベルで別途設計する

resource "databricks_metastore" "this" {
  name          = local.metastore_name
  region        = var.region
  owner         = var.sp_application_id
  force_destroy = true
}
