locals {
  # ==============================================
  # 基本プレフィックス
  # ==============================================
  prefix = "${var.account_code}-${var.security_code_monitoring}"

  # ==============================================
  # Databricks 資格情報設定名
  # ==============================================
  credentials_name = "${local.prefix}-credentialconf-001"

  # ==============================================
  # Databricks ストレージ構成名・バケット名
  # ==============================================
  storage_configuration_name = "${local.prefix}-storageconf-001"
  storage_bucket_name        = "${local.prefix}-bucket-auditlogs-001"

  # ==============================================
  # Databricks Audit log delivery 設定名
  # ==============================================
  log_delivery_config_name = "${local.prefix}-logdelivery-auditlogs-001"

  # ==============================================
  # Databricks メタストア名
  # ==============================================
  metastore_name = "${local.prefix}-metastore-001"
}
