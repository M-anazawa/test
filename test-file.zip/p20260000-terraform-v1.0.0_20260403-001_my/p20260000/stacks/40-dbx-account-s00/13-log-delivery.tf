# ==================================================
# Audit log delivery 設定
# ==================================================
# 設計書: 19.5.3 Audit log delivery 設定
# 依存: 10-credentials, 11-storage
# Databricksアカウントあたり1回の設定（全WS共通）
# ==================================================

resource "databricks_mws_log_delivery" "audit_logs" {
  account_id               = var.databricks_account_id
  credentials_id           = databricks_mws_credentials.this.credentials_id
  storage_configuration_id = databricks_mws_storage_configurations.this.storage_configuration_id
  config_name              = local.log_delivery_config_name
  log_type                 = "AUDIT_LOGS"
  output_format            = "JSON"
  status                   = "ENABLED"
}
