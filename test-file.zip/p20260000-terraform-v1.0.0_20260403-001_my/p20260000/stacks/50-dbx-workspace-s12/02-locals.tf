locals {
  prefix = "${var.account_code}-${var.security_code_bronze}"

  # ==============================================
  # Storage Credential名
  # ==============================================
  storage_credential_name_storage = "${local.prefix}-storagecred-extloc-storage-001"
  storage_credential_name_input   = "${local.prefix}-storagecred-extloc-input-001"
  storage_credential_name_output  = "${local.prefix}-storagecred-extloc-output-001"

  # ==============================================
  # External Location名 / URL
  # ==============================================
  external_location_name_storage = "${local.prefix}-extloc-storage-001"
  external_location_name_input   = "${local.prefix}-extloc-input-001"
  external_location_name_output  = "${local.prefix}-extloc-output-001"
  external_location_url_storage  = "s3://${local.prefix}-bucket-data-001/unity-catalog/"
  external_location_url_input    = "s3://${local.prefix}-bucket-input-001/"
  external_location_url_output   = "s3://${local.prefix}-bucket-output-001/"

  # ==============================================
  # ユーザーグループ名
  # ==============================================
  group_name_001 = "${local.prefix}-users_group-001"
  group_name_002 = "${local.prefix}-users_group-002"
  group_name_003 = "${local.prefix}-users_group-003"
}
