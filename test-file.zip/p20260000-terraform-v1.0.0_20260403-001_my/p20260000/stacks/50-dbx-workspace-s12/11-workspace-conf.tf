# ==================================================
# ワークスペース設定
# ==================================================

resource "databricks_workspace_conf" "this" {
  custom_config = {
    # Verbose Audit Logs：有効
    "enableVerboseAuditLogs" = "true"

    # インタラクティブなノートブックの結果を顧客アカウントに保存する：有効
    "storeInteractiveNotebookResultsInCustomerAccount" = "true"
  }
}
