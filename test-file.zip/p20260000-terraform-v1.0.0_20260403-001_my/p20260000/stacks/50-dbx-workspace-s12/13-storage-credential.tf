# Storage Credential（UC managed storage用）
# catalog/schema の MANAGED LOCATION 用

resource "databricks_storage_credential" "storage" {
  name = local.storage_credential_name_storage

  aws_iam_role {
    role_arn = var.storage_role_arn
  }

  depends_on = [databricks_grants.metastore]
}

# Storage Credential（Input用）
# NotebookからInput S3にアクセスするための認証情報

resource "databricks_storage_credential" "input" {
  name = local.storage_credential_name_input

  aws_iam_role {
    role_arn = var.extloc_input_role_arn
  }

  depends_on = [databricks_grants.metastore]
}

# Storage Credential（Output用）
# NotebookからOutput S3にアクセスするための認証情報

resource "databricks_storage_credential" "output" {
  name = local.storage_credential_name_output

  aws_iam_role {
    role_arn = var.extloc_output_role_arn
  }

  depends_on = [databricks_grants.metastore]
}
