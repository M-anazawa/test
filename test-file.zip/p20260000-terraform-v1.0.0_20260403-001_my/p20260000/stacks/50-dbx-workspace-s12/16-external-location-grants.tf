# External Location 権限付与

resource "databricks_grants" "external_location_storage" {
  external_location = databricks_external_location.storage.id

  grant {
    principal  = local.group_name_001
    privileges = ["MANAGE", "BROWSE", "READ_FILES", "WRITE_FILES", "CREATE_MANAGED_STORAGE", "CREATE_EXTERNAL_TABLE", "CREATE_EXTERNAL_VOLUME"]
  }

  grant {
    principal  = local.group_name_002
    privileges = ["BROWSE", "READ_FILES", "WRITE_FILES", "CREATE_MANAGED_STORAGE", "CREATE_EXTERNAL_TABLE", "CREATE_EXTERNAL_VOLUME"]
  }

  grant {
    principal  = local.group_name_003
    privileges = ["BROWSE", "READ_FILES", "WRITE_FILES", "CREATE_MANAGED_STORAGE", "CREATE_EXTERNAL_TABLE", "CREATE_EXTERNAL_VOLUME"]
  }
}

resource "databricks_grants" "external_location_input" {
  external_location = databricks_external_location.input.id

  grant {
    principal  = local.group_name_001
    privileges = ["MANAGE", "BROWSE", "READ_FILES", "CREATE_EXTERNAL_TABLE", "CREATE_EXTERNAL_VOLUME"]
  }

  grant {
    principal  = local.group_name_002
    privileges = ["BROWSE", "READ_FILES", "CREATE_EXTERNAL_TABLE", "CREATE_EXTERNAL_VOLUME"]
  }

  grant {
    principal  = local.group_name_003
    privileges = ["BROWSE", "READ_FILES", "CREATE_EXTERNAL_TABLE", "CREATE_EXTERNAL_VOLUME"]
  }
}

resource "databricks_grants" "external_location_output" {
  external_location = databricks_external_location.output.id

  grant {
    principal  = local.group_name_001
    privileges = ["MANAGE", "BROWSE", "READ_FILES", "WRITE_FILES", "CREATE_EXTERNAL_TABLE", "CREATE_EXTERNAL_VOLUME"]
  }

  grant {
    principal  = local.group_name_002
    privileges = ["BROWSE", "READ_FILES", "WRITE_FILES", "CREATE_EXTERNAL_TABLE", "CREATE_EXTERNAL_VOLUME"]
  }

  grant {
    principal  = local.group_name_003
    privileges = ["BROWSE", "READ_FILES", "WRITE_FILES", "CREATE_EXTERNAL_TABLE", "CREATE_EXTERNAL_VOLUME"]
  }
}
