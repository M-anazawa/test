variable "account_id" {
  type = string
}

variable "region" {
  type    = string
  default = "ap-northeast-1"
}

variable "account_code" {
  type = string
}

variable "security_code_bronze" {
  type    = string
  default = "s12"
}

# Storage Credential 用 IAMロールARN（10-aws-main-s12 output から取得）
variable "storage_role_arn" {
  description = "UC managed storage 用 IAMロール ARN"
  type        = string
}

variable "extloc_input_role_arn" {
  description = "External Location Input用 IAMロール ARN"
  type        = string
}

variable "extloc_output_role_arn" {
  description = "External Location Output用 IAMロール ARN"
  type        = string
}

# メタストア権限付与用
variable "metastore_id" {
  description = "Databricks メタストア ID（40-dbx-account-s00 output から取得）"
  type        = string
}

variable "sp_application_id" {
  description = "サービスプリンシパルの Application ID（メタストア grants 用）"
  type        = string
}
