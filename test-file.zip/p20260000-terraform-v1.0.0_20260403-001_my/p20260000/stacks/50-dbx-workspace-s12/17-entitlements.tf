# グループ Entitlements 設定
# customer_users (group_name_002) にワークスペース権限を付与

data "databricks_group" "customer_users" {
  display_name = local.group_name_002
}

resource "databricks_entitlements" "customer_users" {
  group_id                   = data.databricks_group.customer_users.id
  workspace_access           = true
  databricks_sql_access      = true
  allow_cluster_create       = true
}

# customer_general (group_name_003) — USER 権限グループ

data "databricks_group" "customer_general" {
  display_name = local.group_name_003
}

resource "databricks_entitlements" "customer_general" {
  group_id                   = data.databricks_group.customer_general.id
  workspace_access           = true
  databricks_sql_access      = true
  allow_cluster_create       = false
}
