# Storage Credential 権限付与

resource "databricks_grants" "storage_credential_storage" {
  storage_credential = databricks_storage_credential.storage.id

  grant {
    principal  = local.group_name_001
    privileges = ["CREATE_EXTERNAL_LOCATION"]
  }
}

resource "databricks_grants" "storage_credential_input" {
  storage_credential = databricks_storage_credential.input.id

  grant {
    principal  = local.group_name_001
    privileges = ["CREATE_EXTERNAL_LOCATION"]
  }
}

resource "databricks_grants" "storage_credential_output" {
  storage_credential = databricks_storage_credential.output.id

  grant {
    principal  = local.group_name_001
    privileges = ["CREATE_EXTERNAL_LOCATION"]
  }
}
