# Databricks Workspace-level API provider（UC運用層）
# 認証情報は環境変数で設定:
#   DATABRICKS_HOST（ワークスペース URL）
#   DATABRICKS_CLIENT_ID / DATABRICKS_CLIENT_SECRET（サービスプリンシパル）

provider "databricks" {
  # host は環境変数 DATABRICKS_HOST で設定
}

# AWS provider（ガード用）
provider "aws" {
  region = var.region
}
