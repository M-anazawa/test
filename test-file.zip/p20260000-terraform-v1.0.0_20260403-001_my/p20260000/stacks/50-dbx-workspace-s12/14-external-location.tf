# External Location（UC managed storage用）
# catalog/schema の MANAGED LOCATION 用

resource "databricks_external_location" "storage" {
  name            = local.external_location_name_storage
  url             = local.external_location_url_storage
  credential_name = databricks_storage_credential.storage.name
  force_destroy   = true
}

# External Location（Input用）
# NotebookからInput S3バケットにアクセスするための外部ロケーション
# file events 有効：Auto Loader の managed file events / file arrival triggers に使用

resource "databricks_external_location" "input" {
  name            = local.external_location_name_input
  url             = local.external_location_url_input
  credential_name = databricks_storage_credential.input.name

  # Managed File Events（Databricks が SNS/SQS を自動管理）
  enable_file_events = true

  file_event_queue {
    managed_sqs {}
  }

}

# External Location（Output用）
# NotebookからOutput S3バケットにアクセスするための外部ロケーション
# file events 無効（file events 方針に基づき付与しない）

resource "databricks_external_location" "output" {
  name            = local.external_location_name_output
  url             = local.external_location_url_output
  credential_name = databricks_storage_credential.output.name

}
