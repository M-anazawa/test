# メタストア権限付与
# SP に Storage Credential / External Location の作成権限を付与
# lykeion_users に External Location の作成権限を付与

resource "databricks_grants" "metastore" {
  metastore = var.metastore_id

  grant {
    principal  = var.sp_application_id
    privileges = ["CREATE_CATALOG", "CREATE_EXTERNAL_LOCATION", "CREATE_STORAGE_CREDENTIAL"]
  }

  grant {
    principal  = local.group_name_001
    privileges = ["CREATE_CATALOG", "CREATE_EXTERNAL_LOCATION"]
  }

  grant {
    principal  = local.group_name_002
    privileges = ["CREATE_CATALOG"]
  }

  grant {
    principal  = local.group_name_003
    privileges = ["CREATE_CATALOG"]
  }
}
