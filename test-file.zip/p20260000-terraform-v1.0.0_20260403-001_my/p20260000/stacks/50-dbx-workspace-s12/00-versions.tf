# Terraform Version
# https://developer.hashicorp.com/terraform/language/expressions/version-constraints

# AWSプロバイダーバージョン
# https://registry.terraform.io/providers/hashicorp/aws/latest

terraform {
  required_version = "= 1.14.3"

  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = "~> 1.110"
    }
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.27"
    }
  }
}
