# ==================================================
# Storage Credential
# ==================================================

output "storage_credential_storage_id" {
  description = "Storage Credential ID（UC managed storage用）"
  value       = databricks_storage_credential.storage.id
}

output "storage_credential_storage_external_id" {
  description = "Storage Credential External ID（UC managed storage用） — trust policy 更新に使用"
  value       = databricks_storage_credential.storage.aws_iam_role[0].external_id
}

output "storage_credential_input_id" {
  description = "Storage Credential ID（Input用）"
  value       = databricks_storage_credential.input.id
}

output "storage_credential_input_external_id" {
  description = "Storage Credential External ID（Input用） — trust policy 更新に使用"
  value       = databricks_storage_credential.input.aws_iam_role[0].external_id
}

output "storage_credential_output_id" {
  description = "Storage Credential ID（Output用）"
  value       = databricks_storage_credential.output.id
}

output "storage_credential_output_external_id" {
  description = "Storage Credential External ID（Output用） — trust policy 更新に使用"
  value       = databricks_storage_credential.output.aws_iam_role[0].external_id
}

# ==================================================
# External Location
# ==================================================

output "external_location_storage_id" {
  description = "External Location ID（UC managed storage用）"
  value       = databricks_external_location.storage.id
}

output "external_location_input_id" {
  description = "External Location ID（Input用）"
  value       = databricks_external_location.input.id
}

output "external_location_output_id" {
  description = "External Location ID（Output用）"
  value       = databricks_external_location.output.id
}
