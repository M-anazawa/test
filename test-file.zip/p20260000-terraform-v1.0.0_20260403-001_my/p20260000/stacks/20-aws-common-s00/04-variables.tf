variable "account_id" {
  type = string
}

variable "region" {
  type    = string
  default = "ap-northeast-1"
}

variable "account_code" {
  type = string
}

variable "security_code_monitoring" {
  type    = string
  default = "s00"
}

# Databricks
variable "databricks_account_id" {
  description = "Databricks Account ID（信頼ポリシーの sts:ExternalId に使用）"
  type        = string
}

variable "databricks_audit_log_delivery_role_arn" {
  description = "Databricks 監査ログ配信用ロール ARN（SaasUsageDeliveryRole）"
  type        = string
}

