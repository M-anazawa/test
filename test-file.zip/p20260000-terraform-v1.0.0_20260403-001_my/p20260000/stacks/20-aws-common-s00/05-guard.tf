// ガード: 実行中のAWSアカウント/リージョンがtfvarsの値と一致しない場合はplan/applyを失敗させる
resource "terraform_data" "guard" {
  input = {
    account_id = data.aws_caller_identity.current.account_id
    region     = data.aws_region.current.id
  }

  lifecycle {
    precondition {
      condition     = data.aws_caller_identity.current.account_id == var.account_id
      error_message = "Wrong AWS account. expected=${var.account_id}, actual=${data.aws_caller_identity.current.account_id}"
    }

    precondition {
      condition     = data.aws_region.current.id == var.region
      error_message = "Wrong AWS region. expected=${var.region}, actual=${data.aws_region.current.id}"
    }

    precondition {
      // security_code_monitoring が s00 であることを検証する
      condition     = var.security_code_monitoring == "s00"
      error_message = "Wrong security code. expected=s00, actual=${var.security_code_monitoring}"
    }
  }
}



