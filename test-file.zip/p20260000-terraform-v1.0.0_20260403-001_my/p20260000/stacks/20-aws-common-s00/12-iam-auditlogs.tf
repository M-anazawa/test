# ==================================================
# IAMロール/ポリシー（監査ログ用）
# ==================================================
#
# 設計（詳細設計書(*.**).md 19.2 / 19.3章）:
#   Databricks 監査ログ配信（SaasUsageDeliveryRole）が
#   監査ログ用 S3 バケットにアクセスするためのロール
#   - policy-auditlogs-001: S3 オブジェクト操作

# --------------------------------------------------
# IAMポリシー: 監査ログ S3 アクセス
# --------------------------------------------------

module "iam_policy_auditlogs" {
  source = "../../modules/iam_policy"

  policies = {
    auditlogs = {
      name = local.iam_policy_names["auditlogs"]
      document = jsonencode({
        Version = "2012-10-17",
        Statement = [
          {
            Effect = "Allow",
            Action = [
              "s3:GetBucketLocation"
            ],
            Resource = [
              "arn:aws:s3:::${local.s3_names["auditlogs"]}"
            ]
          },
          {
            Effect = "Allow",
            Action = [
              "s3:PutObject",
              "s3:GetObject",
              "s3:DeleteObject",
              "s3:PutObjectAcl",
              "s3:AbortMultipartUpload"
            ],
            Resource = [
              "arn:aws:s3:::${local.s3_names["auditlogs"]}/",
              "arn:aws:s3:::${local.s3_names["auditlogs"]}/*"
            ]
          },
          {
            Effect = "Allow",
            Action = [
              "s3:ListBucket",
              "s3:ListMultipartUploadParts",
              "s3:ListBucketMultipartUploads"
            ],
            Resource = "arn:aws:s3:::${local.s3_names["auditlogs"]}"
          }
        ]
      })
    }
  }

  depends_on = [terraform_data.guard]
}

# --------------------------------------------------
# IAMロール
# --------------------------------------------------

module "iam_role_auditlogs" {
  source = "../../modules/iam_role"

  roles = {
    auditlogs = {
      name = local.iam_role_names["auditlogs"]
      assume_role_policy = jsonencode({
        Version = "2012-10-17",
        Statement = [
          {
            Effect = "Allow",
            Principal = {
              AWS = var.databricks_audit_log_delivery_role_arn
            },
            Action = "sts:AssumeRole",
            Condition = {
              StringEquals = {
                "sts:ExternalId" = var.databricks_account_id
              }
            }
          }
        ]
      })
      policy_arns = [
        module.iam_policy_auditlogs.policy_arns["auditlogs"]
      ]
      managed_policy_arns = []
    }
  }

  depends_on = [terraform_data.guard]
}
