# ==================================================
# S3バケット（監査ログ用）
# ==================================================
#
# 設計（詳細設計書(*.**).md 16.4章 / 19.4章）:
#   bucket-auditlogs-001: Databricks 監査ログ配信先
#   - SSE-S3, パブリックアクセス全ブロック, バージョニング無効
#   - ライフサイクル: 730日（2年）で Expire, 非現行バージョン30日で完全削除
#   - バケットポリシー: なし（IAMロール経由でアクセス制御）

module "s3_auditlogs" {
  source = "../../modules/s3"

  bucket_name   = local.s3_names["auditlogs"]
  force_destroy = true

  lifecycle_rules = [
    {
      id                         = "expire-after-2years"
      enabled                    = true
      expiration_days            = 730
      noncurrent_expiration_days = 30
    }
  ]

  depends_on = [terraform_data.guard]
}
