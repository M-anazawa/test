# ==================================================
# S3（監査ログ用）
# ==================================================

output "s3_auditlogs_bucket_name" {
  description = "監査ログ用 S3 バケット名"
  value       = module.s3_auditlogs.bucket_name
}

output "s3_auditlogs_bucket_arn" {
  description = "監査ログ用 S3 バケット ARN"
  value       = module.s3_auditlogs.bucket_arn
}

# ==================================================
# IAM（監査ログ用）
# ==================================================

output "iam_auditlogs_role_arn" {
  description = "監査ログ用 IAM ロール ARN"
  value       = module.iam_role_auditlogs.role_arns["auditlogs"]
}

# ==================================================
# Secrets Manager
# ==================================================

output "secret_arns" {
  description = "Secrets Manager ARNs (dbx_sp_account, dbx_sp_ws)"
  value = {
    dbx_sp_account = module.secret_dbx_sp_account.secret_arn
    dbx_sp_ws      = module.secret_dbx_sp_ws.secret_arn
  }
}

output "secret_names" {
  description = "Secrets Manager names (dbx_sp_account, dbx_sp_ws)"
  value = {
    dbx_sp_account = module.secret_dbx_sp_account.secret_name
    dbx_sp_ws      = module.secret_dbx_sp_ws.secret_name
  }
}
