locals {
  # ==============================================
  # 基本プレフィックス
  # ==============================================
  prefix = "${var.account_code}-${var.security_code_monitoring}"

  # ==============================================
  # S3
  # ==============================================
  s3_names = {
    auditlogs = "${local.prefix}-bucket-auditlogs-001"
  }

  # ==============================================
  # IAM
  # ==============================================
  iam_role_names = {
    auditlogs = "${local.prefix}-role-auditlogs-001"
  }

  iam_policy_names = {
    auditlogs = "${local.prefix}-policy-auditlogs-001"
  }

  # ==============================================
  # Secrets Manager（Databricks SP認証情報）
  # ==============================================
  secret_names = {
    dbx_sp_account = "${local.prefix}-secret-dbx-sp-account-001"
    dbx_sp_ws      = "${local.prefix}-secret-dbx-sp-ws-001"
  }
}
