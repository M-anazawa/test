# ==================================================
# Secrets Manager（Databricks サービスプリンシパル認証情報）
# ==================================================
#
# 設計（詳細設計書(*.**).md 22章）:
#   secret-dbx-sp-account-001: Account-level SP認証情報（30-dbx-account-s12/40-dbx-account-s00 用）
#   secret-dbx-sp-ws-001:      Workspace-level SP認証情報（50-dbx-workspace-s12 用）
#
# NOTE: シークレットの値（client_id, client_secret 等）は
#       AWSマネジメントコンソールで手動設定する

# --------------------------------------------------
# Account-level SP用
# --------------------------------------------------

module "secret_dbx_sp_account" {
  source = "../../modules/secrets_manager"

  secret_name = local.secret_names["dbx_sp_account"]

  depends_on = [terraform_data.guard]
}

# --------------------------------------------------
# Workspace-level SP用
# --------------------------------------------------

module "secret_dbx_sp_ws" {
  source = "../../modules/secrets_manager"

  secret_name = local.secret_names["dbx_sp_ws"]

  depends_on = [terraform_data.guard]
}
