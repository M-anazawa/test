# ==================================================
# ルートテーブル ルートエントリ
# ==================================================
#
# RT枠（aws_route_table）とサブネット関連付け（aws_route_table_association）は
# VPCモジュール（11-vpc.tf）で作成済み。
#
# 本ファイルではルートテーブルへのルートエントリ（aws_route）を管理する。
#
# 設計（詳細設計書(*.**).md 9章）:
#   WS用RT:  0.0.0.0/0 → NFW endpoint（同一AZ）
#   FW用RT:  0.0.0.0/0 → Regional NAT GW
#   END用RT: ルート追加なし（localのみ）
#   S3 GW VPCE ルート: WS用RTに自動追加 ← 16-vpc-endpoints.tf で反映
#
# RT キー分類は 02-locals.tf の ws/fw/end_route_table_keys を参照

# WS用サブネットRT: 0.0.0.0/0 → NFW endpoint（同一AZ）
resource "aws_route" "ws_to_nfw" {
  for_each = toset(local.ws_route_table_keys)

  route_table_id         = module.network.private_route_table_ids[each.key]
  destination_cidr_block = "0.0.0.0/0"
  vpc_endpoint_id        = module.network_firewall.endpoint_ids_by_az[local.az_suffix_to_full[local._subnet_key_to_az_suf[each.key]]]
}

# FW用サブネットRT: 0.0.0.0/0 → Regional NAT GW
resource "aws_route" "fw_to_nat" {
  for_each = toset(local.fw_route_table_keys)

  route_table_id         = module.network.private_route_table_ids[each.key]
  destination_cidr_block = "0.0.0.0/0"
  nat_gateway_id         = module.nat_gateway.nat_gateway_id
}
