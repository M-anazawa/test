# ==================================================
# Network Firewall
# ==================================================
#
# 初期ルール: Stateful Pass ALL（全許可）
# 将来: FQDN制御に切り替え予定（許可FQDNリスト決定後）

module "network_firewall" {
  source = "../../modules/network_firewall"

  firewall_name   = local.nfw_names["firewall"]
  policy_name     = local.nfw_names["policy"]
  rule_group_name = local.nfw_names["rule_group"]

  vpc_id = module.network.vpc_id

  # FW用サブネットにエンドポイントを配置
  subnet_ids = {
    for k in local.fw_route_table_keys :
    k => module.network.subnet_ids[k]
  }

  depends_on = [terraform_data.guard]
}
