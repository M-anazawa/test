# ==================================================
# Regional NAT Gateway
# ==================================================
#
# Regional NAT は VPC に直接作成（パブリックサブネット不要）
# AWS が RNAT 用 RT を自動作成し、IGW への経路を事前設定
# EIP は AWS が自動割り当て・管理（手動作成不要）
# FW 用サブネット RT の 0.0.0.0/0 ターゲットとして使用

module "nat_gateway" {
  source = "../../modules/nat_gateway"

  nat_name = local.rnat_name
  vpc_id   = module.network.vpc_id

  depends_on = [module.network]
}
