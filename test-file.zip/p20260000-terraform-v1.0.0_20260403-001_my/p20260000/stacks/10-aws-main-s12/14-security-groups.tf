# ==================================================
# セキュリティグループ
# ==================================================
#
# sg-001: WS用（Databricks クラスター間通信 + Control Plane 通信）
# sg-002: VPCエンドポイント用（WS/SCC/STS/Kinesis VPCE）
#
# 設計方針:
#   Databricks workspace SG は、実通信経路が PrivateLink/VPCE 経由であっても、
#   Databricks 公式の VPC validation 要件として 0.0.0.0/0 宛必要ポートの egress を求められる。
#   PrivateLink 利用時は TCP 6666（SCC relay）が必須。
#   endpoint SG は inbound ルール中心でよく、outbound は不要（AWS デフォルト全許可）。
#
# 参照: https://docs.databricks.com/aws/en/security/network/classic/customer-managed-vpc

module "security_groups" {
  source = "../../modules/security_groups"

  vpc_id = module.network.vpc_id

  groups = {
    # --------------------------------------------------
    # sg-001: WS用SG
    # Databricks 公式 VPC validation 要件に準拠
    # --------------------------------------------------
    sg_001 = {
      name        = local.sg_names["sg_001"]
      description = "Databricks workspace security group"

      ingress = [
        # Sparkノード間通信（self → self）
        {
          id        = "spark-tcp-self"
          protocol  = "tcp"
          from_port = 0
          to_port   = 65535
          source    = { type = "self" }
        },
        {
          id        = "spark-udp-self"
          protocol  = "udp"
          from_port = 0
          to_port   = 65535
          source    = { type = "self" }
        },
      ]

      egress = [
        # ===== self 宛（Spark ノード間通信）=====
        {
          id        = "spark-tcp-self"
          protocol  = "tcp"
          from_port = 0
          to_port   = 65535
          destination = { type = "self" }
        },
        {
          id        = "spark-udp-self"
          protocol  = "udp"
          from_port = 0
          to_port   = 65535
          destination = { type = "self" }
        },

        # ===== 0.0.0.0/0 宛（Databricks 公式 VPC validation 必須ポート）=====
        # NOTE: 実通信は VPCE/NAT GW 経由だが、Databricks の VPC validation が
        #       0.0.0.0/0 宛の egress ルールを検証するため、明示的に許可する必要がある
        {
          id          = "https-outbound"
          protocol    = "tcp"
          from_port   = 443
          to_port     = 443
          destination = { type = "cidr", cidr = "0.0.0.0/0" }
        },
        {
          id          = "metastore-outbound"
          protocol    = "tcp"
          from_port   = 3306
          to_port     = 3306
          destination = { type = "cidr", cidr = "0.0.0.0/0" }
        },
        {
          id          = "fips-outbound"
          protocol    = "tcp"
          from_port   = 2443
          to_port     = 2443
          destination = { type = "cidr", cidr = "0.0.0.0/0" }
        },
        {
          id          = "scc-relay-outbound"
          protocol    = "tcp"
          from_port   = 6666
          to_port     = 6666
          destination = { type = "cidr", cidr = "0.0.0.0/0" }
        },
        {
          id          = "cp-api-outbound"
          protocol    = "tcp"
          from_port   = 8443
          to_port     = 8443
          destination = { type = "cidr", cidr = "0.0.0.0/0" }
        },
        {
          id          = "uc-log-outbound"
          protocol    = "tcp"
          from_port   = 8444
          to_port     = 8444
          destination = { type = "cidr", cidr = "0.0.0.0/0" }
        },
        {
          id          = "future-outbound"
          protocol    = "tcp"
          from_port   = 8445
          to_port     = 8451
          destination = { type = "cidr", cidr = "0.0.0.0/0" }
        },

        # ===== DNS（0.0.0.0/0 宛）=====
        # Databricks 公式: custom DNS を使う場合に必要
        # VPC validation との整合性のため 0.0.0.0/0 宛で設定
        {
          id          = "dns-tcp"
          protocol    = "tcp"
          from_port   = 53
          to_port     = 53
          destination = { type = "cidr", cidr = "0.0.0.0/0" }
        },
        {
          id          = "dns-udp"
          protocol    = "udp"
          from_port   = 53
          to_port     = 53
          destination = { type = "cidr", cidr = "0.0.0.0/0" }
        },
      ]
    }

    # --------------------------------------------------
    # sg-002: VPCエンドポイント用SG
    # endpoint SG は inbound ルール中心。outbound は AWS デフォルト全許可。
    # --------------------------------------------------
    sg_002 = {
      name        = local.sg_names["sg_002"]
      description = "VPC endpoints security group"

      ingress = [
        {
          id        = "https-from-ws"
          protocol  = "tcp"
          from_port = 443
          to_port   = 443
          source    = { type = "sg", sg_key = "sg_001" }
        },
        {
          id        = "scc-from-ws"
          protocol  = "tcp"
          from_port = 6666
          to_port   = 6666
          source    = { type = "sg", sg_key = "sg_001" }
        },
        {
          id        = "fips-from-ws"
          protocol  = "tcp"
          from_port = 2443
          to_port   = 2443
          source    = { type = "sg", sg_key = "sg_001" }
        },
        {
          id        = "cp-api-from-ws"
          protocol  = "tcp"
          from_port = 8443
          to_port   = 8443
          source    = { type = "sg", sg_key = "sg_001" }
        },
        {
          id        = "uc-log-from-ws"
          protocol  = "tcp"
          from_port = 8444
          to_port   = 8444
          source    = { type = "sg", sg_key = "sg_001" }
        },
        {
          id        = "future-from-ws"
          protocol  = "tcp"
          from_port = 8445
          to_port   = 8451
          source    = { type = "sg", sg_key = "sg_001" }
        },
      ]

      # egress: AWS デフォルト全許可（null = デフォルト egress）
      # Databricks 公式では endpoint SG の outbound は不要
    }
  }

  depends_on = [terraform_data.guard]
}
