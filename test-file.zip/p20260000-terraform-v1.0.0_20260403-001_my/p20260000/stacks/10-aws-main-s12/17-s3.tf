# ==================================================
# S3バケット
# ==================================================
#
# 設計（詳細設計書(*.**).md 16章）:
#   bucket-data-001:   root storage / UC managed table用
#   bucket-input-001:  Input用（External Location）
#   bucket-output-001: Output用（External Location）
#
# 共通設定: SSE-S3, パブリックアクセス全ブロック
# input/output: バージョニング有効, 非現行バージョン7日で完全削除

# --------------------------------------------------
# data（root storage / UC managed tables）
# --------------------------------------------------

module "s3_data" {
  source = "../../modules/s3"

  bucket_name   = local.s3_names["data"]
  force_destroy = true

  bucket_policy_json = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "Grant Databricks Access"
        Effect    = "Allow"
        Principal = { AWS = "arn:aws:iam::${var.databricks_aws_account_id}:root" }
        Action = [
          "s3:GetObject",
          "s3:GetObjectVersion",
          "s3:PutObject",
          "s3:DeleteObject",
          "s3:ListBucket",
          "s3:GetBucketLocation",
        ]
        Resource = [
          "arn:aws:s3:::${local.s3_names["data"]}/*",
          "arn:aws:s3:::${local.s3_names["data"]}",
        ]
        Condition = {
          StringEquals = {
            "aws:PrincipalTag/DatabricksAccountId" = var.databricks_account_id
          }
        }
      },
      {
        Sid       = "Prevent DBFS from accessing Unity Catalog metastore"
        Effect    = "Deny"
        Principal = { AWS = "arn:aws:iam::${var.databricks_aws_account_id}:root" }
        Action    = "s3:*"
        Resource  = "arn:aws:s3:::${local.s3_names["data"]}/unity-catalog/*"
      },
    ]
  })

  depends_on = [terraform_data.guard]
}

# --------------------------------------------------
# input（External Location用）
# --------------------------------------------------

module "s3_input" {
  source = "../../modules/s3"

  bucket_name        = local.s3_names["input"]
  force_destroy      = true
  versioning_enabled = true

  lifecycle_rules = [
    {
      id                         = "delete-noncurrent-versions"
      enabled                    = true
      expiration_days            = null
      noncurrent_expiration_days = 7
    }
  ]

  bucket_policy_json = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "Grant Databricks Access"
        Effect    = "Allow"
        Principal = { AWS = "arn:aws:iam::${var.databricks_aws_account_id}:root" }
        Action = [
          "s3:GetObject",
          "s3:GetObjectVersion",
          "s3:PutObject",
          "s3:DeleteObject",
          "s3:ListBucket",
          "s3:GetBucketLocation",
        ]
        Resource = [
          "arn:aws:s3:::${local.s3_names["input"]}/*",
          "arn:aws:s3:::${local.s3_names["input"]}",
        ]
        Condition = {
          StringEquals = {
            "aws:PrincipalTag/DatabricksAccountId" = var.databricks_account_id
          }
        }
      },
    ]
  })

  depends_on = [terraform_data.guard]
}

# --------------------------------------------------
# output（External Location用）
# --------------------------------------------------

module "s3_output" {
  source = "../../modules/s3"

  bucket_name        = local.s3_names["output"]
  force_destroy      = true
  versioning_enabled = true

  lifecycle_rules = [
    {
      id                         = "delete-noncurrent-versions"
      enabled                    = true
      expiration_days            = null
      noncurrent_expiration_days = 7
    }
  ]

  bucket_policy_json = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "Grant Databricks Access"
        Effect    = "Allow"
        Principal = { AWS = "arn:aws:iam::${var.databricks_aws_account_id}:root" }
        Action = [
          "s3:GetObject",
          "s3:GetObjectVersion",
          "s3:PutObject",
          "s3:DeleteObject",
          "s3:ListBucket",
          "s3:GetBucketLocation",
        ]
        Resource = [
          "arn:aws:s3:::${local.s3_names["output"]}/*",
          "arn:aws:s3:::${local.s3_names["output"]}",
        ]
        Condition = {
          StringEquals = {
            "aws:PrincipalTag/DatabricksAccountId" = var.databricks_account_id
          }
        }
      },
    ]
  })

  depends_on = [terraform_data.guard]
}
