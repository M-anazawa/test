locals {
  # ==============================================
  # 基本プレフィックス
  # ==============================================
  prefix = "${var.account_code}-${var.security_code_bronze}"

  # ==============================================
  # VPC
  # ==============================================
  vpc_number = "001"
  vpc_name   = "${local.prefix}-vpc-${local.vpc_number}"

  # IGW
  igw_name = "${local.vpc_name}-igw"

  # Regional NAT Gateway（EIPはAWSが自動管理）
  rnat_name = "${local.vpc_name}-rnat"

  # ==============================================
  # サブネット名マップ
  # key = "purpose-az_suffix-number" (例: "priws-1a-001")
  # ==============================================
  _subnets_flat = flatten([
    for gk, g in var.subnet_groups : [
      for s in g.subnets : {
        key     = "${g.purpose}-${s.name_suffix}-${format("%03d", g.number)}"
        purpose = g.purpose
        az_suf  = s.name_suffix
        number  = g.number
      }
    ]
  ])

  subnet_names_by_key = {
    for s in local._subnets_flat :
    s.key => "${local.vpc_name}-${s.purpose}-sn-${s.az_suf}-${format("%03d", s.number)}"
  }

  # ==============================================
  # ルートテーブル名マップ
  # ==============================================
  # パブリックRT（本構成では未使用だがモジュール要件として定義）
  public_route_table_name = "${local.vpc_name}-pub-sn-001-rt"

  # プライベートRT: サブネット名-rt
  private_route_table_names_by_key = {
    for k, name in local.subnet_names_by_key :
    k => "${name}-rt"
  }

  # ==============================================
  # ルートテーブル キー分類（サブネット種別ごと）
  # ==============================================
  # WS用RT:  0.0.0.0/0 → NFW endpoint（同一AZ）
  # FW用RT:  0.0.0.0/0 → Regional NAT GW
  # END用RT: ルート追加なし（localのみ）
  ws_route_table_keys  = [for s in local._subnets_flat : s.key if s.purpose == "priws"]
  fw_route_table_keys  = [for s in local._subnets_flat : s.key if s.purpose == "prifw"]
  end_route_table_keys = [for s in local._subnets_flat : s.key if s.purpose == "priend"]

  # ==============================================
  # Network Firewall
  # ==============================================
  nfw_names = {
    firewall   = "${local.prefix}-nfw-001"
    policy     = "${local.prefix}-nfwpolicy-001"
    rule_group = "${local.prefix}-nfwrulegroup-001"
  }

  # AZサフィックス → フルAZ名マップ（NFW endpoint → RT 紐付け用）
  az_suffix_to_full = {
    for az in var.network.azs : substr(az, length(az) - 2, 2) => az
  }

  # サブネットキー → AZサフィックス（ルートテーブル → NFW endpoint 紐付け用）
  _subnet_key_to_az_suf = {
    for s in local._subnets_flat : s.key => s.az_suf
  }

  # ==============================================
  # セキュリティグループ
  # ==============================================
  sg_names = {
    sg_001 = "${local.prefix}-sg-001"
    sg_002 = "${local.prefix}-sg-002"
  }

  # ==============================================
  # VPCエンドポイント
  # ==============================================
  vpce_names = {
    s3      = "${local.prefix}-vpce-001"
    ws      = "${local.prefix}-vpce-002"
    scc     = "${local.prefix}-vpce-003"
    sts     = "${local.prefix}-vpce-004"
    kinesis = "${local.prefix}-vpce-005"
  }

  # ==============================================
  # S3
  # ==============================================
  s3_names = {
    data   = "${local.prefix}-bucket-data-001"
    input  = "${local.prefix}-bucket-input-001"
    output = "${local.prefix}-bucket-output-001"
  }

  # ==============================================
  # VPC Flow Log
  # ==============================================
  flowlog_number = "001"
  flowlog_name   = "${local.vpc_name}-flowlog-${local.flowlog_number}"

  log_group_names = {
    vpc_flowlog = "/aws/${local.vpc_name}/flowlog"
  }

  # ==============================================
  # IAM
  # ==============================================
  iam_role_names = {
    vpcflowlog   = "${local.prefix}-role-vpcflowlog-001"
    crossaccount = "${local.prefix}-role-crossaccount-001"
    storage      = "${local.prefix}-role-extloc-storage-001"
    extloc_input  = "${local.prefix}-role-extloc-input-001"
    extloc_output = "${local.prefix}-role-extloc-output-001"
  }

  iam_policy_names = {
    vpcflowlog    = "${local.prefix}-policy-vpcflowlog-001"
    crossaccount  = "${local.prefix}-policy-crossaccount-001"
    storage_001       = "${local.prefix}-policy-extloc-storage-001"
    extloc_input_001  = "${local.prefix}-policy-extloc-input-001"
    extloc_input_002  = "${local.prefix}-policy-extloc-input-002"
    extloc_output     = "${local.prefix}-policy-extloc-output-001"
  }

}
