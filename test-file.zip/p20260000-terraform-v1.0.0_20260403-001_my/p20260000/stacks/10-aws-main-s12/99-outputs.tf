# ==================================================
# VPC
# ==================================================

output "vpc_id" {
  value = module.network.vpc_id
}

output "vpc_name" {
  value = module.network.vpc_name
}

output "igw_id" {
  value = module.network.igw_id
}

output "subnet_ids" {
  description = "key=purpose-az-### の subnet_id map"
  value       = module.network.subnet_ids
}

output "private_route_table_ids" {
  description = "key=purpose-az-### の private rt id map"
  value       = module.network.private_route_table_ids
}

# ==================================================
# Regional NAT Gateway
# ==================================================

output "nat_gateway_id" {
  value = module.nat_gateway.nat_gateway_id
}

# ==================================================
# Security Groups
# ==================================================

output "sg_ids" {
  description = "SG key -> ID map (sg_001, sg_002)"
  value       = module.security_groups.sg_ids
}

# ==================================================
# Network Firewall
# ==================================================

output "nfw_endpoint_ids_by_az" {
  description = "AZ -> NFW endpoint ID map"
  value       = module.network_firewall.endpoint_ids_by_az
}

# ==================================================
# VPC Endpoints
# ==================================================

output "vpce_ids" {
  description = "VPCE key -> ID map (s3, ws, scc, sts, kinesis)"
  value       = module.vpc_endpoints.endpoint_ids
}

# ==================================================
# S3
# ==================================================

output "s3_bucket_arns" {
  description = "S3 bucket ARNs (data, input, output)"
  value = {
    data   = module.s3_data.bucket_arn
    input  = module.s3_input.bucket_arn
    output = module.s3_output.bucket_arn
  }
}

# ==================================================
# IAM（クロスアカウント）
# ==================================================

output "iam_crossaccount_role_arn" {
  description = "Databricks credential configuration 用クロスアカウントロール ARN"
  value       = module.iam_role_crossaccount.role_arns["crossaccount"]
}

# ==================================================
# IAM（ストレージ構成用）
# ==================================================

output "iam_storage_role_arn" {
  description = "Databricks storage configuration 用ストレージロール ARN"
  value       = module.iam_role_storage.role_arns["storage"]
}

# ==================================================
# IAM（ExtLoc Input用）
# ==================================================

output "iam_extloc_input_role_arn" {
  description = "Databricks External Location (Input) 用ロール ARN"
  value       = module.iam_role_extloc_input.role_arns["extloc_input"]
}

# ==================================================
# IAM（ExtLoc Output用）
# ==================================================

output "iam_extloc_output_role_arn" {
  description = "Databricks External Location (Output) 用ロール ARN"
  value       = module.iam_role_extloc_output.role_arns["extloc_output"]
}
