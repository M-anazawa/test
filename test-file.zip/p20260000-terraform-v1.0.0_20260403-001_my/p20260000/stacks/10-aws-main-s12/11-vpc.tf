# ==================================================
# VPC（IGW, Subnet, Route Table, Flow Log, NACL）
# ==================================================
#
# NACL: デフォルト NACL を使用（全トラフィック許可）
# - Databricks の customer-managed VPC 要件として 0.0.0.0/0 Allow が必須
# - トラフィック統制は Network Firewall で実施するため、NACL での制限は不要
# - デフォルト NACL は全サブネットに自動適用され、全トラフィック許可が初期設定

module "network" {
  source = "../../modules/vpc"

  vpc_cidr = var.network.vpc_cidr
  azs      = var.network.azs

  subnet_groups = var.subnet_groups

  log_retention_days = var.log_retention_days

  vpc_name            = local.vpc_name
  igw_name            = local.igw_name
  subnet_names_by_key = local.subnet_names_by_key

  public_route_table_name          = local.public_route_table_name
  private_route_table_names_by_key = local.private_route_table_names_by_key

  flowlog_name           = local.flowlog_name
  flowlog_log_group_name = local.log_group_names["vpc_flowlog"]

  flowlogs_role_name   = local.iam_role_names["vpcflowlog"]
  flowlogs_policy_name = local.iam_policy_names["vpcflowlog"]

  depends_on = [terraform_data.guard]
}
