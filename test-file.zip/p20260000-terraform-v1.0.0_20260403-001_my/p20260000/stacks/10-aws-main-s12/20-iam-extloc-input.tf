# ==================================================
# IAMロール/ポリシー（ExtLoc Input用）
# ==================================================
#
# 設計（詳細設計書(*.**).md 18.3章）:
#   Unity Catalog External Location 経由で Input S3 バケットに
#   アクセスするためのロール
#   - policy-extloc-input-001: S3 オブジェクト操作 + 自己 AssumeRole
#   - policy-extloc-input-002: Managed File Events (SNS/SQS)

# --------------------------------------------------
# IAMポリシー: Input S3 アクセス + 自己AssumeRole
# --------------------------------------------------

module "iam_policy_extloc_input_001" {
  source = "../../modules/iam_policy"

  policies = {
    extloc_input_001 = {
      name = local.iam_policy_names["extloc_input_001"]
      document = jsonencode({
        Version = "2012-10-17",
        Statement = [
          {
            Effect = "Allow",
            Action = [
              "s3:GetObject",
              "s3:PutObject",
              "s3:DeleteObject",
              "s3:ListMultipartUploadParts",
              "s3:AbortMultipartUpload"
            ],
            Resource = "arn:aws:s3:::${local.s3_names["input"]}/*"
          },
          {
            Effect = "Allow",
            Action = [
              "s3:ListBucket",
              "s3:GetBucketLocation",
              "s3:ListBucketMultipartUploads"
            ],
            Resource = "arn:aws:s3:::${local.s3_names["input"]}"
          },
          {
            Effect = "Allow",
            Action = [
              "sts:AssumeRole"
            ],
            Resource = [
              "arn:aws:iam::${var.account_id}:role/${local.iam_role_names["extloc_input"]}"
            ]
          }
        ]
      })
    }
  }

  depends_on = [terraform_data.guard]
}

# --------------------------------------------------
# IAMポリシー: Managed File Events (SNS/SQS)
# --------------------------------------------------

module "iam_policy_extloc_input_002" {
  source = "../../modules/iam_policy"

  policies = {
    extloc_input_002 = {
      name = local.iam_policy_names["extloc_input_002"]
      document = jsonencode({
        Version = "2012-10-17",
        Statement = [
          {
            Sid    = "ManagedFileEventsSetupStatement",
            Effect = "Allow",
            Action = [
              "s3:GetBucketNotification",
              "s3:PutBucketNotification",
              "sns:ListSubscriptionsByTopic",
              "sns:GetTopicAttributes",
              "sns:SetTopicAttributes",
              "sns:CreateTopic",
              "sns:TagResource",
              "sns:Publish",
              "sns:Subscribe",
              "sqs:CreateQueue",
              "sqs:DeleteMessage",
              "sqs:ReceiveMessage",
              "sqs:SendMessage",
              "sqs:GetQueueUrl",
              "sqs:GetQueueAttributes",
              "sqs:SetQueueAttributes",
              "sqs:TagQueue",
              "sqs:ChangeMessageVisibility",
              "sqs:PurgeQueue"
            ],
            Resource = [
              "arn:aws:s3:::${local.s3_names["input"]}",
              "arn:aws:sqs:*:*:csms-*",
              "arn:aws:sns:*:*:csms-*"
            ]
          },
          {
            Sid    = "ManagedFileEventsListStatement",
            Effect = "Allow",
            Action = [
              "sqs:ListQueues",
              "sqs:ListQueueTags",
              "sns:ListTopics"
            ],
            Resource = [
              "arn:aws:sqs:*:*:csms-*",
              "arn:aws:sns:*:*:csms-*"
            ]
          },
          {
            Sid    = "ManagedFileEventsTeardownStatement",
            Effect = "Allow",
            Action = [
              "sns:Unsubscribe",
              "sns:DeleteTopic",
              "sqs:DeleteQueue"
            ],
            Resource = [
              "arn:aws:sqs:*:*:csms-*",
              "arn:aws:sns:*:*:csms-*"
            ]
          }
        ]
      })
    }
  }

  depends_on = [terraform_data.guard]
}

# --------------------------------------------------
# IAMロール
# --------------------------------------------------

module "iam_role_extloc_input" {
  source = "../../modules/iam_role"

  roles = {
    extloc_input = {
      name = local.iam_role_names["extloc_input"]
      # 信頼ポリシー（Databricks公式 2段階更新方式）:
      #   1回目 apply (enable_extloc_input_self_assume=false):
      #     Statement 1 のみ — UCMasterRole + placeholder ExternalId("0000")
      #   2回目 apply (enable_extloc_input_self_assume=true):
      #     Statement 1 + Statement 2 — actual ExternalId + self-assume 追加
      assume_role_policy = jsonencode({
        Version = "2012-10-17",
        Statement = concat(
          [
            {
              Sid    = "UCMasterRoleAssumeRole",
              Effect = "Allow",
              Principal = {
                AWS = var.databricks_unity_catalog_role_arn
              },
              Action = "sts:AssumeRole",
              Condition = {
                StringEquals = {
                  "sts:ExternalId" = var.extloc_input_credential_external_id
                }
              }
            }
          ],
          var.enable_extloc_input_self_assume ? [
            {
              Sid    = "SelfAssumeRole",
              Effect = "Allow",
              Principal = {
                AWS = "arn:aws:iam::${var.account_id}:role/${local.iam_role_names["extloc_input"]}"
              },
              Action = "sts:AssumeRole",
              Condition = {
                StringEquals = {
                  "sts:ExternalId" = var.extloc_input_credential_external_id
                }
              }
            }
          ] : []
        )
      })
      policy_arns = [
        module.iam_policy_extloc_input_001.policy_arns["extloc_input_001"],
        module.iam_policy_extloc_input_002.policy_arns["extloc_input_002"]
      ]
      managed_policy_arns = []
    }
  }

  depends_on = [terraform_data.guard]
}
