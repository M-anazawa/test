# ==================================================
# IAMロール/ポリシー（ストレージ構成用）
# ==================================================
#
# 設計（詳細設計書(*.**).md 18.2章）:
#   Unity Catalog がお客様S3バケットにアクセスするためのロール
#   - policy-extloc-storage-001: S3 オブジェクト操作 + 自己 AssumeRole
#
# NOTE: Managed File Events は Input 系 ExtLoc 用ロール（role-extloc-input-001）で
#       扱うため、ストレージロールには付与しない。

# --------------------------------------------------
# IAMポリシー: S3アクセス + 自己AssumeRole
# --------------------------------------------------

module "iam_policy_storage_001" {
  source = "../../modules/iam_policy"

  policies = {
    storage_001 = {
      name = local.iam_policy_names["storage_001"]
      document = jsonencode({
        Version = "2012-10-17",
        Statement = [
          {
            Effect = "Allow",
            Action = [
              "s3:GetObject",
              "s3:PutObject",
              "s3:DeleteObject"
            ],
            Resource = "arn:aws:s3:::${local.s3_names["data"]}/unity-catalog/*"
          },
          {
            Effect = "Allow",
            Action = [
              "s3:ListBucket",
              "s3:GetBucketLocation"
            ],
            Resource = "arn:aws:s3:::${local.s3_names["data"]}"
          },
          {
            Effect = "Allow",
            Action = [
              "sts:AssumeRole"
            ],
            Resource = [
              "arn:aws:iam::${var.account_id}:role/${local.iam_role_names["storage"]}"
            ]
          }
        ]
      })
    }
  }

  depends_on = [terraform_data.guard]
}

# --------------------------------------------------
# IAMロール
# --------------------------------------------------

module "iam_role_storage" {
  source = "../../modules/iam_role"

  roles = {
    storage = {
      name = local.iam_role_names["storage"]
      # 信頼ポリシー（Databricks公式 2段階更新方式）:
      #   1回目 apply (enable_self_assume=false):
      #     Statement 1 のみ — UCMasterRole + placeholder ExternalId("0000")
      #   2回目 apply (enable_self_assume=true):
      #     Statement 1 + Statement 2 — actual ExternalId + self-assume 追加
      assume_role_policy = jsonencode({
        Version = "2012-10-17",
        Statement = concat(
          [
            {
              Sid    = "UCMasterRoleAssumeRole",
              Effect = "Allow",
              Principal = {
                AWS = var.databricks_unity_catalog_role_arn
              },
              Action = "sts:AssumeRole",
              Condition = {
                StringEquals = {
                  "sts:ExternalId" = var.storage_credential_external_id
                }
              }
            }
          ],
          var.enable_self_assume ? [
            {
              Sid    = "SelfAssumeRole",
              Effect = "Allow",
              Principal = {
                AWS = "arn:aws:iam::${var.account_id}:role/${local.iam_role_names["storage"]}"
              },
              Action = "sts:AssumeRole",
              Condition = {
                StringEquals = {
                  "sts:ExternalId" = var.storage_credential_external_id
                }
              }
            }
          ] : []
        )
      })
      policy_arns = [
        module.iam_policy_storage_001.policy_arns["storage_001"]
      ]
      managed_policy_arns = []
    }
  }

  depends_on = [terraform_data.guard]
}
