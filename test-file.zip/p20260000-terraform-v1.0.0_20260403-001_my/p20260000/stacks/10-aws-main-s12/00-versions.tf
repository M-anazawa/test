# Terraform Version
# https://developer.hashicorp.com/terraform/language/expressions/version-constraints

# AWSプロバイダーバージョン
# https://registry.terraform.io/providers/hashicorp/aws/latest

terraform {
  required_version = "= 1.14.3"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.27"
    }
  }
}

