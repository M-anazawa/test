# ==================================================
# IAMロール/ポリシー（ExtLoc Output用）
# ==================================================
#
# 設計（詳細設計書(*.**).md 18.4章）:
#   Unity Catalog External Location 経由で Output S3 バケットに
#   アクセスするためのロール
#   - policy-extloc-output-001: S3 オブジェクト操作 + 自己 AssumeRole

# --------------------------------------------------
# IAMポリシー: Output S3 アクセス + 自己AssumeRole
# --------------------------------------------------

module "iam_policy_extloc_output" {
  source = "../../modules/iam_policy"

  policies = {
    extloc_output = {
      name = local.iam_policy_names["extloc_output"]
      document = jsonencode({
        Version = "2012-10-17",
        Statement = [
          {
            Effect = "Allow",
            Action = [
              "s3:GetObject",
              "s3:PutObject",
              "s3:DeleteObject",
              "s3:ListMultipartUploadParts",
              "s3:AbortMultipartUpload"
            ],
            Resource = "arn:aws:s3:::${local.s3_names["output"]}/*"
          },
          {
            Effect = "Allow",
            Action = [
              "s3:ListBucket",
              "s3:GetBucketLocation",
              "s3:ListBucketMultipartUploads"
            ],
            Resource = "arn:aws:s3:::${local.s3_names["output"]}"
          },
          {
            Effect = "Allow",
            Action = [
              "sts:AssumeRole"
            ],
            Resource = [
              "arn:aws:iam::${var.account_id}:role/${local.iam_role_names["extloc_output"]}"
            ]
          }
        ]
      })
    }
  }

  depends_on = [terraform_data.guard]
}

# --------------------------------------------------
# IAMロール
# --------------------------------------------------

module "iam_role_extloc_output" {
  source = "../../modules/iam_role"

  roles = {
    extloc_output = {
      name = local.iam_role_names["extloc_output"]
      # 信頼ポリシー（Databricks公式 2段階更新方式）:
      #   1回目 apply (enable_extloc_output_self_assume=false):
      #     Statement 1 のみ — UCMasterRole + placeholder ExternalId("0000")
      #   2回目 apply (enable_extloc_output_self_assume=true):
      #     Statement 1 + Statement 2 — actual ExternalId + self-assume 追加
      assume_role_policy = jsonencode({
        Version = "2012-10-17",
        Statement = concat(
          [
            {
              Sid    = "UCMasterRoleAssumeRole",
              Effect = "Allow",
              Principal = {
                AWS = var.databricks_unity_catalog_role_arn
              },
              Action = "sts:AssumeRole",
              Condition = {
                StringEquals = {
                  "sts:ExternalId" = var.extloc_output_credential_external_id
                }
              }
            }
          ],
          var.enable_extloc_output_self_assume ? [
            {
              Sid    = "SelfAssumeRole",
              Effect = "Allow",
              Principal = {
                AWS = "arn:aws:iam::${var.account_id}:role/${local.iam_role_names["extloc_output"]}"
              },
              Action = "sts:AssumeRole",
              Condition = {
                StringEquals = {
                  "sts:ExternalId" = var.extloc_output_credential_external_id
                }
              }
            }
          ] : []
        )
      })
      policy_arns = [
        module.iam_policy_extloc_output.policy_arns["extloc_output"]
      ]
      managed_policy_arns = []
    }
  }

  depends_on = [terraform_data.guard]
}
