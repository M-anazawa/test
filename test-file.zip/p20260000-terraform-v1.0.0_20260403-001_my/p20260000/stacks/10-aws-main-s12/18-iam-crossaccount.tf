# ==================================================
# IAMロール/ポリシー（資格情報構成用: クロスアカウント）
# ==================================================
#
# 設計（詳細設計書(*.**).md 18.1章）:
#   Databricksがお客様AWSアカウント内でEC2等を操作するためのロール
#   Customer-managed VPC with custom restrictions ポリシー

# --------------------------------------------------
# IAMポリシー
# --------------------------------------------------

module "iam_policy_crossaccount" {
  source = "../../modules/iam_policy"

  policies = {
    crossaccount = {
      name = local.iam_policy_names["crossaccount"]
      document = jsonencode({
        Version = "2012-10-17",
        Statement = [
          {
            Sid    = "NonResourceBasedPermissions",
            Effect = "Allow",
            Action = [
              "ec2:AssignPrivateIpAddresses",
              "ec2:CancelSpotInstanceRequests",
              "ec2:DescribeAvailabilityZones",
              "ec2:DescribeIamInstanceProfileAssociations",
              "ec2:DescribeInstanceStatus",
              "ec2:DescribeInstances",
              "ec2:DescribeInternetGateways",
              "ec2:DescribeNatGateways",
              "ec2:DescribeNetworkAcls",
              "ec2:DescribePrefixLists",
              "ec2:DescribeReservedInstancesOfferings",
              "ec2:DescribeRouteTables",
              "ec2:DescribeSecurityGroups",
              "ec2:DescribeSpotInstanceRequests",
              "ec2:DescribeSpotPriceHistory",
              "ec2:DescribeSubnets",
              "ec2:DescribeVolumes",
              "ec2:DescribeVpcAttribute",
              "ec2:DescribeVpcs",
              "ec2:CreateTags",
              "ec2:DeleteTags",
              "ec2:GetSpotPlacementScores",
              "ec2:RequestSpotInstances",
              "ec2:DescribeFleetHistory",
              "ec2:ModifyFleet",
              "ec2:DeleteFleets",
              "ec2:DescribeFleetInstances",
              "ec2:DescribeFleets",
              "ec2:CreateFleet",
              "ec2:DeleteLaunchTemplate",
              "ec2:GetLaunchTemplateData",
              "ec2:CreateLaunchTemplate",
              "ec2:DescribeLaunchTemplates",
              "ec2:DescribeLaunchTemplateVersions",
              "ec2:ModifyLaunchTemplate",
              "ec2:DeleteLaunchTemplateVersions",
              "ec2:CreateLaunchTemplateVersion"
            ],
            Resource = ["*"]
          },
          {
            Sid    = "InstancePoolsSupport",
            Effect = "Allow",
            Action = [
              "ec2:AssociateIamInstanceProfile",
              "ec2:DisassociateIamInstanceProfile",
              "ec2:ReplaceIamInstanceProfileAssociation"
            ],
            Resource = "arn:aws:ec2:${var.region}:${var.account_id}:instance/*",
            Condition = {
              StringEquals = {
                "ec2:ResourceTag/Vendor" = "Databricks"
              }
            }
          },
          {
            Sid    = "AllowEc2RunInstancePerTag",
            Effect = "Allow",
            Action = "ec2:RunInstances",
            Resource = [
              "arn:aws:ec2:${var.region}:${var.account_id}:volume/*",
              "arn:aws:ec2:${var.region}:${var.account_id}:instance/*"
            ],
            Condition = {
              StringEquals = {
                "aws:RequestTag/Vendor" = "Databricks"
              }
            }
          },
          {
            Sid    = "AllowEc2RunInstanceImagePerTag",
            Effect = "Allow",
            Action = "ec2:RunInstances",
            Resource = [
              "arn:aws:ec2:${var.region}:${var.account_id}:image/*"
            ],
            Condition = {
              StringEquals = {
                "aws:ResourceTag/Vendor" = "Databricks"
              }
            }
          },
          {
            Sid    = "AllowEc2RunInstancePerVPCid",
            Effect = "Allow",
            Action = "ec2:RunInstances",
            Resource = [
              "arn:aws:ec2:${var.region}:${var.account_id}:network-interface/*",
              "arn:aws:ec2:${var.region}:${var.account_id}:subnet/*",
              "arn:aws:ec2:${var.region}:${var.account_id}:security-group/*"
            ],
            Condition = {
              StringEquals = {
                "ec2:vpc" = "arn:aws:ec2:${var.region}:${var.account_id}:vpc/${module.network.vpc_id}"
              }
            }
          },
          {
            Sid    = "AllowEc2RunInstanceOtherResources",
            Effect = "Allow",
            Action = "ec2:RunInstances",
            NotResource = [
              "arn:aws:ec2:${var.region}:${var.account_id}:image/*",
              "arn:aws:ec2:${var.region}:${var.account_id}:network-interface/*",
              "arn:aws:ec2:${var.region}:${var.account_id}:subnet/*",
              "arn:aws:ec2:${var.region}:${var.account_id}:security-group/*",
              "arn:aws:ec2:${var.region}:${var.account_id}:volume/*",
              "arn:aws:ec2:${var.region}:${var.account_id}:instance/*"
            ]
          },
          {
            Sid      = "EC2TerminateInstancesTag",
            Effect   = "Allow",
            Action   = ["ec2:TerminateInstances"],
            Resource = ["arn:aws:ec2:${var.region}:${var.account_id}:instance/*"],
            Condition = {
              StringEquals = {
                "ec2:ResourceTag/Vendor" = "Databricks"
              }
            }
          },
          {
            Sid    = "EC2AttachDetachVolumeTag",
            Effect = "Allow",
            Action = ["ec2:AttachVolume", "ec2:DetachVolume"],
            Resource = [
              "arn:aws:ec2:${var.region}:${var.account_id}:instance/*",
              "arn:aws:ec2:${var.region}:${var.account_id}:volume/*"
            ],
            Condition = {
              StringEquals = {
                "ec2:ResourceTag/Vendor" = "Databricks"
              }
            }
          },
          {
            Sid      = "EC2CreateVolumeByTag",
            Effect   = "Allow",
            Action   = ["ec2:CreateVolume"],
            Resource = ["arn:aws:ec2:${var.region}:${var.account_id}:volume/*"],
            Condition = {
              StringEquals = {
                "aws:RequestTag/Vendor" = "Databricks"
              }
            }
          },
          {
            Sid      = "EC2DeleteVolumeByTag",
            Effect   = "Allow",
            Action   = ["ec2:DeleteVolume"],
            Resource = ["arn:aws:ec2:${var.region}:${var.account_id}:volume/*"],
            Condition = {
              StringEquals = {
                "ec2:ResourceTag/Vendor" = "Databricks"
              }
            }
          },
          {
            Effect = "Allow",
            Action = ["iam:CreateServiceLinkedRole", "iam:PutRolePolicy"],
            Resource  = "arn:aws:iam::*:role/aws-service-role/spot.amazonaws.com/AWSServiceRoleForEC2Spot",
            Condition = {
              StringLike = {
                "iam:AWSServiceName" = "spot.amazonaws.com"
              }
            }
          },
          {
            Sid    = "VpcNonresourceSpecificActions",
            Effect = "Allow",
            Action = [
              "ec2:AuthorizeSecurityGroupEgress",
              "ec2:AuthorizeSecurityGroupIngress",
              "ec2:RevokeSecurityGroupEgress",
              "ec2:RevokeSecurityGroupIngress"
            ],
            Resource = "arn:aws:ec2:${var.region}:${var.account_id}:security-group/${module.security_groups.sg_ids["sg_001"]}",
            Condition = {
              StringEquals = {
                "ec2:vpc" = "arn:aws:ec2:${var.region}:${var.account_id}:vpc/${module.network.vpc_id}"
              }
            }
          }
        ]
      })
    }
  }

  depends_on = [terraform_data.guard]
}

# --------------------------------------------------
# IAMロール
# --------------------------------------------------

module "iam_role_crossaccount" {
  source = "../../modules/iam_role"

  roles = {
    crossaccount = {
      name = local.iam_role_names["crossaccount"]
      assume_role_policy = jsonencode({
        Version = "2012-10-17",
        Statement = [
          {
            Effect    = "Allow",
            Action    = "sts:AssumeRole",
            Principal = { AWS = var.databricks_aws_account_id },
            Condition = {
              StringEquals = {
                "sts:ExternalId" = var.databricks_account_id
              }
            }
          }
        ]
      })
      policy_arns         = [module.iam_policy_crossaccount.policy_arns["crossaccount"]]
      managed_policy_arns = []
    }
  }

  depends_on = [terraform_data.guard]
}
