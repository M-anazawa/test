variable "account_id" {
  type = string
}

variable "region" {
  type    = string
  default = "ap-northeast-1"
}

variable "account_code" {
  type = string
}

variable "security_code_bronze" {
  type    = string
  default = "s12"
}

# ==================================================
# VPC
# ==================================================

variable "network" {
  description = "VPC基本設定"
  type = object({
    vpc_cidr = string
    azs      = list(string)
  })
  default = {
    vpc_cidr = "10.0.0.0/16"
    azs      = ["ap-northeast-1a", "ap-northeast-1c", "ap-northeast-1d"]
  }
}

variable "subnet_groups" {
  description = "サブネットグループ定義"
  type = map(object({
    purpose   = string
    number    = number
    is_public = bool
    subnets = list(object({
      name_suffix = string
      cidr        = string
    }))
  }))
  default = {
    priws = {
      purpose   = "priws"
      number    = 1
      is_public = false
      subnets = [
        { name_suffix = "1a", cidr = "10.0.0.0/20" },
        { name_suffix = "1c", cidr = "10.0.16.0/20" },
        { name_suffix = "1d", cidr = "10.0.32.0/20" },
      ]
    }
    priend = {
      purpose   = "priend"
      number    = 1
      is_public = false
      subnets = [
        { name_suffix = "1a", cidr = "10.0.240.0/24" },
        { name_suffix = "1c", cidr = "10.0.241.0/24" },
        { name_suffix = "1d", cidr = "10.0.242.0/24" },
      ]
    }
    prifw = {
      purpose   = "prifw"
      number    = 1
      is_public = false
      subnets = [
        { name_suffix = "1a", cidr = "10.0.243.0/28" },
        { name_suffix = "1c", cidr = "10.0.243.16/28" },
        { name_suffix = "1d", cidr = "10.0.243.32/28" },
      ]
    }
  }
}

# ==================================================
# Databricks
# ==================================================

variable "databricks_account_id" {
  description = "Databricks Account ID"
  type        = string
}

variable "databricks_aws_account_id" {
  description = "Databricks AWS Account ID (for bucket policy)"
  type        = string
}

variable "databricks_unity_catalog_role_arn" {
  description = "Databricks Unity Catalog マスターロール ARN"
  type        = string
}

# --------------------------------------------------
# ストレージ構成用 IAM ロール（2段階 apply）
# --------------------------------------------------
# 1回目 apply: "0000"（仮）で IAM ロールを作成
# 2回目 apply: Databricks storage credential 作成後に取得した実際の External ID を設定
variable "storage_credential_external_id" {
  description = "Storage credential の External ID（1回目は 0000、2回目は実際の値）"
  type        = string
  default     = "0000"
}

# 1回目 apply: false（UCMasterRole のみの仮 trust policy）
# 2回目 apply: true（self-assume を追加した最終 trust policy）
variable "enable_self_assume" {
  description = "ストレージロールの self-assume を有効にするか（2回目 apply で true）"
  type        = bool
  default     = false
}

# --------------------------------------------------
# ExtLoc Input 用 IAM ロール（2段階 apply）
# --------------------------------------------------
variable "extloc_input_credential_external_id" {
  description = "ExtLoc Input storage credential の External ID（1回目は 0000、2回目は実際の値）"
  type        = string
  default     = "0000"
}

variable "enable_extloc_input_self_assume" {
  description = "ExtLoc Input ロールの self-assume を有効にするか（2回目 apply で true）"
  type        = bool
  default     = false
}

# --------------------------------------------------
# ExtLoc Output 用 IAM ロール（2段階 apply）
# --------------------------------------------------
variable "extloc_output_credential_external_id" {
  description = "ExtLoc Output storage credential の External ID（1回目は 0000、2回目は実際の値）"
  type        = string
  default     = "0000"
}

variable "enable_extloc_output_self_assume" {
  description = "ExtLoc Output ロールの self-assume を有効にするか（2回目 apply で true）"
  type        = bool
  default     = false
}

# ==================================================
# CloudWatch Logs
# ==================================================

variable "log_retention_days" {
  description = "CloudWatch Logs 保存日数"
  type        = number
  default     = 731
}

# ==================================================
# VPCエンドポイント
# ==================================================

variable "databricks_vpce_service" {
  description = "Databricks PrivateLink VPCエンドポイントサービス名"
  type = object({
    workspace = string
    scc       = string
  })
  default = {
    workspace = "com.amazonaws.vpce.ap-northeast-1.vpce-svc-02691fd610d24fd64"
    scc       = "com.amazonaws.vpce.ap-northeast-1.vpce-svc-02aa633bda3edbec0"
  }
}
