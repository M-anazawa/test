# ==================================================
# VPCエンドポイント
# ==================================================
#
# 設計（詳細設計書(*.**).md 15章）:
#   vpce-001: S3 Gateway     → WS用RTに関連付け
#   vpce-002: WS Interface   → priend サブネット, sg-002
#   vpce-003: SCC Interface  → priend サブネット, sg-002
#   vpce-004: STS Interface  → priend サブネット, sg-002
#   vpce-005: Kinesis Interface → priend サブネット, sg-002

module "vpc_endpoints" {
  source = "../../modules/vpc_endpoints"

  vpc_id = module.network.vpc_id

  # Interface VPCE → エンドポイント用サブネット
  interface_subnet_ids = [
    for k in local.end_route_table_keys :
    module.network.subnet_ids[k]
  ]

  # Interface VPCE → sg-002
  interface_security_group_ids = [module.security_groups.sg_ids["sg_002"]]

  # S3 Gateway VPCE → WS用RTのみに関連付け
  gateway_route_table_ids = [
    for k in local.ws_route_table_keys :
    module.network.private_route_table_ids[k]
  ]

  endpoints = {
    s3 = {
      name          = local.vpce_names["s3"]
      service_name  = "com.amazonaws.${var.region}.s3"
      endpoint_type = "Gateway"
    }
    ws = {
      name           = local.vpce_names["ws"]
      service_name   = var.databricks_vpce_service.workspace
      endpoint_type  = "Interface"
      policy_enabled = false  # Databricks PrivateLink: full-access のみ
    }
    scc = {
      name           = local.vpce_names["scc"]
      service_name   = var.databricks_vpce_service.scc
      endpoint_type  = "Interface"
      policy_enabled = false  # Databricks PrivateLink: full-access のみ
    }
    sts = {
      name          = local.vpce_names["sts"]
      service_name  = "com.amazonaws.${var.region}.sts"
      endpoint_type = "Interface"
    }
    kinesis = {
      name          = local.vpce_names["kinesis"]
      service_name  = "com.amazonaws.${var.region}.kinesis-streams"
      endpoint_type = "Interface"
    }
  }

  depends_on = [terraform_data.guard]
}
