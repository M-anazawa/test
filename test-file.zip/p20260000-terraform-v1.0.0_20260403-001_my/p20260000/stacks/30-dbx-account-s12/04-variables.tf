variable "account_id" {
  type = string
}

variable "region" {
  type    = string
  default = "ap-northeast-1"
}

variable "account_code" {
  type = string
}

variable "security_code_bronze" {
  type    = string
  default = "s12"
}

# Databricks
variable "databricks_account_id" {
  description = "Databricks Account ID"
  type        = string
}

# AWS VPC Endpoint IDs（10-aws-main-s12 の output から取得）
variable "ws_vpce_id" {
  description = "WS用 AWS VPC Endpoint ID（vpce-002）"
  type        = string
}

variable "scc_vpce_id" {
  description = "SCC用 AWS VPC Endpoint ID（vpce-003）"
  type        = string
}

# Network Object（10-aws-main-s12 の output から取得）
variable "vpc_id" {
  description = "VPC ID"
  type        = string
}

variable "ws_subnet_ids" {
  description = "WS用プライベートサブネットID（priws-sn-1a/1c/1d-001）"
  type        = list(string)
}

variable "sg_id" {
  description = "WS用セキュリティグループID（sg-001）"
  type        = string
}

# Credentials（10-aws-main-s12 の output から取得）
variable "crossaccount_role_arn" {
  description = "Databricks credential configuration 用クロスアカウントロール ARN"
  type        = string
}

# Storage Configuration（10-aws-main-s12 の output から取得）
variable "iam_storage_role_arn" {
  description = "ストレージ構成用 IAMロール ARN（19-iam-storage.tf で作成）"
  type        = string
}

# メタストア割り当て用（40-dbx-account-s00 の output から取得）
variable "metastore_id" {
  description = "Databricks メタストア ID（40-dbx-account-s00 output metastore_id）"
  type        = string
}

# サービスプリンシパル（グループ管理用）
variable "sp_application_id" {
  description = "サービスプリンシパルの Application ID"
  type        = string
}
