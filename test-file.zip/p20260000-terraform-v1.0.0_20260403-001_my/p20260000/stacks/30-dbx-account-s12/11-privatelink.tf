# ==================================================
# Databricks PrivateLinkオブジェクト登録
# ==================================================
#
# 設計（詳細設計書(*.**).md 20.1章）:
#   AWS VPCエンドポイント（WS用/SCC用）を
#   Databricksアカウントに PrivateLink オブジェクトとして登録する。
#   10-aws-main-s12 で作成済みの AWS VPCE ID を参照する。

# --------------------------------------------------
# WS用（REST API / Webapp）
# --------------------------------------------------

resource "databricks_mws_vpc_endpoint" "ws" {
  account_id          = var.databricks_account_id
  aws_vpc_endpoint_id = var.ws_vpce_id
  vpc_endpoint_name   = local.vpce_names["ws"]
  region              = var.region
}

# --------------------------------------------------
# SCC用（Secure Cluster Connectivity）
# --------------------------------------------------

resource "databricks_mws_vpc_endpoint" "scc" {
  account_id          = var.databricks_account_id
  aws_vpc_endpoint_id = var.scc_vpce_id
  vpc_endpoint_name   = local.vpce_names["scc"]
  region              = var.region
}
