# ユーザーグループ作成

resource "databricks_group" "customer_users" {
  display_name = local.group_name_002
}

resource "databricks_group" "lykeion_users" {
  display_name = local.group_name_001
}

resource "databricks_group" "customer_general" {
  display_name = local.group_name_003
}

# アカウント管理者ロール付与（lykeion_users のみ）

resource "databricks_group_role" "lykeion_admin" {
  group_id = databricks_group.lykeion_users.id
  role     = "account_admin"
}

# ワークスペース権限割り当て（customer_users を ws-001 に Admin で追加）

resource "databricks_mws_permission_assignment" "customer_users_ws" {
  workspace_id = databricks_mws_workspaces.this.workspace_id
  principal_id = databricks_group.customer_users.id
  permissions  = ["ADMIN"]
}

# ワークスペース権限割り当て（customer_general を ws-001 に User で追加）

resource "databricks_mws_permission_assignment" "customer_general_ws" {
  workspace_id = databricks_mws_workspaces.this.workspace_id
  principal_id = databricks_group.customer_general.id
  permissions  = ["USER"]
}

# グループ権限設定（customer_users が自グループを管理可能にする）

resource "databricks_access_control_rule_set" "customer_users_manage" {
  name = "accounts/${var.databricks_account_id}/groups/${databricks_group.customer_users.id}/ruleSets/default"

  grant_rules {
    principals = [
      "groups/${databricks_group.customer_users.display_name}",
      "servicePrincipals/${var.sp_application_id}",
    ]
    role = "roles/group.manager"
  }
}
