# ==================================================
# PrivateLink VPCエンドポイント
# ==================================================

output "vpc_endpoint_id_ws" {
  description = "Databricks PrivateLink VPC Endpoint ID（WS用）"
  value       = databricks_mws_vpc_endpoint.ws.vpc_endpoint_id
}

output "vpc_endpoint_id_scc" {
  description = "Databricks PrivateLink VPC Endpoint ID（SCC用）"
  value       = databricks_mws_vpc_endpoint.scc.vpc_endpoint_id
}

# ==================================================
# ネットワークオブジェクト
# ==================================================

output "network_id" {
  description = "Databricks ネットワーク構成 ID"
  value       = databricks_mws_networks.this.network_id
}

# ==================================================
# プライベートアクセス設定
# ==================================================

output "private_access_settings_id" {
  description = "Databricks プライベートアクセス設定 ID"
  value       = databricks_mws_private_access_settings.this.private_access_settings_id
}

# ==================================================
# 資格情報
# ==================================================

output "credentials_id" {
  description = "Databricks 資格情報 ID"
  value       = databricks_mws_credentials.this.credentials_id
}

# ==================================================
# ストレージ構成
# ==================================================

output "storage_configuration_id" {
  description = "Databricks ストレージ構成 ID"
  value       = databricks_mws_storage_configurations.this.storage_configuration_id
}

# ==================================================
# ワークスペース
# ==================================================

output "workspace_id" {
  description = "Databricks ワークスペース ID"
  value       = databricks_mws_workspaces.this.workspace_id
}

output "workspace_url" {
  description = "Databricks ワークスペース URL"
  value       = databricks_mws_workspaces.this.workspace_url
}

