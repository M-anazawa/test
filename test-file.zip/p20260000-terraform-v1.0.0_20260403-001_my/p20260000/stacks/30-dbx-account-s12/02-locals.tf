locals {
  # ==============================================
  # 基本プレフィックス
  # ==============================================
  prefix = "${var.account_code}-${var.security_code_bronze}"

  # ==============================================
  # Databricks PrivateLink VPCエンドポイント名
  # ==============================================
  vpce_names = {
    ws  = "${local.prefix}-vpce-002"
    scc = "${local.prefix}-vpce-003"
  }

  # ==============================================
  # Databricks ネットワークオブジェクト名
  # ==============================================
  network_name = "${local.prefix}-vpc-001-priws-sn-001"

  # ==============================================
  # Databricks プライベートアクセス設定名
  # ==============================================
  private_access_settings_name = "${local.prefix}-privateaccess-001"

  # ==============================================
  # Databricks 資格情報設定名
  # ==============================================
  credentials_name = "${local.prefix}-credentialconf-001"

  # ==============================================
  # Databricks ストレージ構成名・バケット名
  # ==============================================
  storage_configuration_name = "${local.prefix}-storageconf-001"
  storage_bucket_name        = "${local.prefix}-bucket-data-001"

  # ==============================================
  # Databricks ワークスペース名
  # ==============================================
  workspace_name = "${local.prefix}-ws-001"

  # ==============================================
  # ユーザーグループ名
  # ==============================================
  group_name_001 = "${local.prefix}-users_group-001"  # lykeion
  group_name_002 = "${local.prefix}-users_group-002"  # customer (Admin)
  group_name_003 = "${local.prefix}-users_group-003"  # customer (User)
}
