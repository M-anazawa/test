# ==================================================
# Databricks ワークスペース
# ==================================================
# 設計書: 20.6 ワークスペース作成
# 依存: 10-privatelink, 11-network, 12-private-access, 13-credentials, 14-storage
# ==================================================

resource "databricks_mws_workspaces" "this" {
  account_id     = var.databricks_account_id
  workspace_name = local.workspace_name
  aws_region     = var.region

  credentials_id           = databricks_mws_credentials.this.credentials_id
  storage_configuration_id = databricks_mws_storage_configurations.this.storage_configuration_id
  network_id               = databricks_mws_networks.this.network_id
  private_access_settings_id = databricks_mws_private_access_settings.this.private_access_settings_id
}
