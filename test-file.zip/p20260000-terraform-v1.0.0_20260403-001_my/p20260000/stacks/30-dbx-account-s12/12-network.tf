# ==================================================
# Databricks ネットワークオブジェクト登録
# ==================================================
#
# 設計（詳細設計書(*.**).md 20.2章）:
#   Customer-managed VPC のネットワーク構成を
#   Databricksアカウントに登録する。
#   10-aws-main-s12 で作成済みの VPC / サブネット / SG を参照し、
#   同スタック内の PrivateLink オブジェクトを vpc_endpoints で紐付ける。

resource "databricks_mws_networks" "this" {
  account_id         = var.databricks_account_id
  network_name       = local.network_name
  vpc_id             = var.vpc_id
  subnet_ids         = var.ws_subnet_ids
  security_group_ids = [var.sg_id]

  vpc_endpoints {
    dataplane_relay = [databricks_mws_vpc_endpoint.scc.vpc_endpoint_id]
    rest_api        = [databricks_mws_vpc_endpoint.ws.vpc_endpoint_id]
  }
}
