# ==================================================
# Databricks ストレージ構成登録（Storage Configuration）
# ==================================================
#
# 設計（詳細設計書(*.**).md 20.5章）:
#   ワークスペースのルートストレージとして使用する
#   S3 バケットを Databricks アカウントに登録する。
#   10-aws-main-s12 で作成済みの S3 バケット名を参照する。

resource "databricks_mws_storage_configurations" "this" {
  account_id                 = var.databricks_account_id
  storage_configuration_name = local.storage_configuration_name
  bucket_name                = local.storage_bucket_name
  role_arn                   = var.iam_storage_role_arn
}
