# メタストア割り当て
# NOTE: メタストア自体は 40-dbx-account-s00 で作成する（s00 = 全レベル共通）
#       ここでは WS へのメタストア割り当てのみ実施する

resource "databricks_metastore_assignment" "this" {
  metastore_id = var.metastore_id
  workspace_id = databricks_mws_workspaces.this.workspace_id
}
