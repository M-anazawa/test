# ==================================================
# Databricks プライベートアクセス設定オブジェクト
# ==================================================
#
# 設計（詳細設計書(*.**).md 20.3章）:
#   フロントエンド（UI）はパブリックアクセス、
#   バックエンド（Control Plane ↔ Compute Plane）は PrivateLink。
#   プライベートアクセスレベルを ACCOUNT に設定し、
#   Databricksアカウントに登録済みの VPC Endpoint のみ許可する。

resource "databricks_mws_private_access_settings" "this" {
  private_access_settings_name = local.private_access_settings_name
  region                       = var.region
  public_access_enabled        = true
  private_access_level         = "ACCOUNT"
}
