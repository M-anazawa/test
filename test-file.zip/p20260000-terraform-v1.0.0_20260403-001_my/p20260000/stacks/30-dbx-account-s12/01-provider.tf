# Databricks Account-level API provider
# 認証情報は環境変数で設定:
#   DATABRICKS_CLIENT_ID / DATABRICKS_CLIENT_SECRET（サービスプリンシパル）
#   または DATABRICKS_USERNAME / DATABRICKS_PASSWORD

provider "databricks" {
  host       = "https://accounts.cloud.databricks.com"
  account_id = var.databricks_account_id
}

# AWS provider（ガード用）
provider "aws" {
  region = var.region
}
