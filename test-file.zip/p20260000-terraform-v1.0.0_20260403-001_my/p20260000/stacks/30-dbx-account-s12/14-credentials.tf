# ==================================================
# Databricks 資格情報登録（Credential Configuration）
# ==================================================
#
# 設計（詳細設計書(*.**).md 20.4章）:
#   Databricks がクラスターを起動する際に使用する
#   クロスアカウント IAM ロールを登録する。
#   10-aws-main-s12 で作成済みのロール ARN を参照する。

resource "databricks_mws_credentials" "this" {
  credentials_name = local.credentials_name
  role_arn         = var.crossaccount_role_arn
}
