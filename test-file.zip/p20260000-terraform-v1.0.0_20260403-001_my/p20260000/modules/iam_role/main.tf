locals {
  policy_attachments = flatten([
    for role_key, role in var.roles : [
      for policy_arn in role.policy_arns : {
        role_key   = role_key
        policy_arn = policy_arn
      }
    ]
  ])

  managed_policy_attachments = flatten([
    for role_key, role in var.roles : [
      for policy_arn in role.managed_policy_arns : {
        role_key   = role_key
        policy_arn = policy_arn
      }
    ]
  ])

  all_attachments = concat(local.policy_attachments, local.managed_policy_attachments)
}

resource "aws_iam_role" "this" {
  for_each = var.roles

  name               = each.value.name
  assume_role_policy = each.value.assume_role_policy
}

resource "aws_iam_role_policy_attachment" "this" {
  for_each = {
    for idx, item in local.all_attachments : "${item.role_key}-${idx}" => item
  }

  role       = aws_iam_role.this[each.value.role_key].name
  policy_arn = each.value.policy_arn
}
