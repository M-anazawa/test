variable "roles" {
  type = map(object({
    name                = string
    assume_role_policy  = string
    policy_arns         = list(string)
    managed_policy_arns = list(string)
  }))
  default = {}
}
