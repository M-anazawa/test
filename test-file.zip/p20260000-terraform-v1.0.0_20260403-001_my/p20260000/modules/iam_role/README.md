﻿# modules/iam_role

IAM ロールを複数まとめて作成します。

## Usage

```hcl
module "iam_role" {
  source = "../../modules/iam_role"

  roles = {
    ecsdef = {
      name                = local.iam_role_names_for_main.ecsdef
      assume_role_policy  = data.aws_iam_policy_document.ecsdef_assume.json
      policy_arns         = [module.iam_policy.policy_arns.ecsdef]
      managed_policy_arns = []
    }
    ecsTaskExecution = {
      name                = local.iam_role_names_for_main.ecsTaskExecution
      assume_role_policy  = data.aws_iam_policy_document.ecs_task_execution_assume.json
      policy_arns         = [module.iam_policy.policy_arns.ecsdef]
      managed_policy_arns = ["arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"]
    }
    bedrock = {
      name                = local.iam_role_names_for_main.bedrock
      assume_role_policy  = data.aws_iam_policy_document.bedrock_assume.json
      policy_arns         = [module.iam_policy.policy_arns.bedrock]
      managed_policy_arns = []
    }
    OpenSearchIngestion = {
      name                = local.iam_role_names_for_main.OpenSearchIngestion
      assume_role_policy  = data.aws_iam_policy_document.opensearch_ingestion_assume.json
      policy_arns         = [module.iam_policy.policy_arns.OpenSearchIngestion]
      managed_policy_arns = []
    }
    GitHubActions = {
      name                = local.iam_role_names_for_main.GitHubActions
      assume_role_policy  = data.aws_iam_policy_document.github_actions_assume.json
      policy_arns         = [module.iam_policy.policy_arns.GitHubActions]
      managed_policy_arns = []
    }
    tds3 = {
      name                = local.iam_role_names_for_main.tds3
      assume_role_policy  = data.aws_iam_policy_document.tds3_assume.json
      policy_arns         = [module.iam_policy.policy_arns.tds3]
      managed_policy_arns = []
    }
  }

  depends_on = [terraform_data.guard]
}
```

## Notes

- `policy_arns` と `managed_policy_arns` は両方アタッチされます。

## Inputs

- `roles` (map, optional): ロール定義マップ
  - `name` (string): ロール名
  - `assume_role_policy` (string): 信頼ポリシー (JSON)
  - `policy_arns` (list(string)): アタッチするポリシー ARN
  - `managed_policy_arns` (list(string)): 管理ポリシー ARN

## Outputs

- `role_arns`: ロールキー -> ARN のマップ
