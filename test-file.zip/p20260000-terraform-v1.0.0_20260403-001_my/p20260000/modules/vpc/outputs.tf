output "vpc_id" {
  value = aws_vpc.this.id
}

output "vpc_name" {
  value = var.vpc_name
}

output "igw_id" {
  value = aws_internet_gateway.this.id
}

output "subnet_ids" {
  description = "key=purpose-az-### の subnet_id map"
  value       = { for k, s in aws_subnet.this : k => s.id }
}

output "public_route_table_id" {
  value = aws_route_table.public.id
}

output "private_route_table_ids" {
  description = "key=purpose-az-### の private rt id map"
  value       = { for k, rt in aws_route_table.private : k => rt.id }
}

output "flow_log_id" {
  value = aws_flow_log.vpc.id
}

output "flowlog_log_group_name" {
  value = aws_cloudwatch_log_group.vpc_flowlog.name
}