locals {
  az_by_suffix = {
    for az in var.azs :
    substr(az, length(az) - 2, 2) => az
  }

  subnets = flatten([
    for _, g in var.subnet_groups : [
      for s in g.subnets : {
        purpose   = g.purpose
        az_suf    = s.name_suffix
        cidr      = s.cidr
        number    = g.number
        is_public = g.is_public
      }
    ]
  ])

  subnet_keys = {
    for s in local.subnets :
    "${s.purpose}-${s.az_suf}-${format("%03d", s.number)}" => s
  }

  flowlog_log_group_name = coalesce(
    var.flowlog_log_group_name,
    "/aws/${var.vpc_name}/flowlog"
  )
}

resource "aws_vpc" "this" {
  cidr_block           = var.vpc_cidr
  enable_dns_support   = true
  enable_dns_hostnames = true

  tags = { Name = var.vpc_name }
}

resource "aws_vpc_encryption_control" "this" {
  vpc_id = aws_vpc.this.id
  mode   = "monitor"
}

resource "aws_internet_gateway" "this" {
  vpc_id = aws_vpc.this.id
  tags   = { Name = var.igw_name }
}

resource "aws_subnet" "this" {
  for_each = local.subnet_keys

  vpc_id                  = aws_vpc.this.id
  cidr_block              = each.value.cidr
  availability_zone       = local.az_by_suffix[each.value.az_suf]
  map_public_ip_on_launch = each.value.is_public

  tags = {
    Name = var.subnet_names_by_key[each.key]
  }
}

resource "aws_route_table" "public" {
  vpc_id = aws_vpc.this.id
  tags   = { Name = var.public_route_table_name }
}

resource "aws_route" "public_default" {
  route_table_id         = aws_route_table.public.id
  destination_cidr_block = "0.0.0.0/0"
  gateway_id             = aws_internet_gateway.this.id
}

resource "aws_route_table_association" "public" {
  for_each = {
    for k, v in local.subnet_keys : k => v
    if v.is_public
  }

  subnet_id      = aws_subnet.this[each.key].id
  route_table_id = aws_route_table.public.id
}

resource "aws_route_table" "private" {
  for_each = {
    for k, v in local.subnet_keys : k => v
    if !v.is_public
  }

  vpc_id = aws_vpc.this.id

  tags = {
    Name = var.private_route_table_names_by_key[each.key]
  }
}

resource "aws_route_table_association" "private" {
  for_each = aws_route_table.private

  subnet_id      = aws_subnet.this[each.key].id
  route_table_id = each.value.id
}

resource "aws_cloudwatch_log_group" "vpc_flowlog" {
  name              = local.flowlog_log_group_name
  retention_in_days = var.log_retention_days
}

data "aws_iam_policy_document" "flowlogs_assume" {
  statement {
    effect = "Allow"
    principals {
      type        = "Service"
      identifiers = ["vpc-flow-logs.amazonaws.com"]
    }
    actions = ["sts:AssumeRole"]
  }
}

resource "aws_iam_role" "flowlogs" {
  name               = var.flowlogs_role_name
  assume_role_policy = data.aws_iam_policy_document.flowlogs_assume.json
}

data "aws_iam_policy_document" "flowlogs_write" {
  statement {
    effect = "Allow"
    actions = [
      "logs:CreateLogStream",
      "logs:PutLogEvents",
      "logs:DescribeLogGroups",
      "logs:DescribeLogStreams"
    ]
    resources = [
      aws_cloudwatch_log_group.vpc_flowlog.arn,
      "${aws_cloudwatch_log_group.vpc_flowlog.arn}:*"
    ]
  }
}

resource "aws_iam_role_policy" "flowlogs_write" {
  name   = var.flowlogs_policy_name
  role   = aws_iam_role.flowlogs.id
  policy = data.aws_iam_policy_document.flowlogs_write.json
}

resource "aws_flow_log" "vpc" {
  vpc_id               = aws_vpc.this.id
  traffic_type         = "ALL"
  log_destination_type = "cloud-watch-logs"
  log_destination      = aws_cloudwatch_log_group.vpc_flowlog.arn
  iam_role_arn         = aws_iam_role.flowlogs.arn

  tags = { Name = var.flowlog_name }
}
