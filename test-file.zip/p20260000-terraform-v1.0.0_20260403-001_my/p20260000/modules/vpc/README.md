﻿# modules/vpc

VPC と Subnet/Route Table/VPC Flow Logs を作成します。

## Usage

```hcl
module "network" {
  source = "../../modules/vpc"

  vpc_cidr = var.network.vpc_cidr
  azs      = var.network.azs

  subnet_groups = var.subnet_groups

  log_retention_days = var.log_retention_days

  vpc_name            = local.vpc_name
  igw_name            = local.igw_name
  subnet_names_by_key = local.subnet_names_by_key

  public_route_table_name          = local.public_route_table_name
  private_route_table_names_by_key = local.private_route_table_names_by_key

  flowlog_name           = local.flowlog_name
  flowlog_log_group_name = local.log_group_names["vpc_flowlog"]

  flowlogs_role_name   = local.iam_role_names["vpcflowlog"]
  flowlogs_policy_name = local.iam_policy_names["vpcflowlog"]

  depends_on = [terraform_data.guard]
}
```

## Notes

- `subnet_names_by_key` は自動生成される全 Subnet キーに対応している必要があります。
- `flowlog_log_group_name` 未指定時は `/aws/<vpc_name>/flowlog` を使用します。

## Inputs

- `vpc_name` (string): VPC 名称
- `vpc_cidr` (string): VPC CIDR
- `azs` (list(string)): 利用する AZ
- `subnet_groups` (map): Subnet 定義
- `subnet_names_by_key` (map(string)): `purpose-az-###` をキーにした Subnet 名称マップ
- `igw_name` (string): Internet Gateway 名称
- `public_route_table_name` (string): Public Route Table 名称
- `private_route_table_names_by_key` (map(string)): `purpose-az-###` をキーにした Private Route Table 名称マップ
- `flowlog_name` (string): VPC Flow Logs 名称
- `flowlog_log_group_name` (string, optional): VPC Flow Logs 用 Log Group 名称
- `log_retention_days` (number, optional): CloudWatch Logs の保存日数
- `flowlogs_role_name` (string): VPC Flow Logs 用 IAM Role 名称
- `flowlogs_policy_name` (string): VPC Flow Logs 用 IAM Policy 名称

## Outputs

- `vpc_id`
- `vpc_name`
- `igw_id`
- `subnet_ids`: `purpose-az-###` をキーにした Subnet ID マップ
- `public_route_table_id`
- `private_route_table_ids`: `purpose-az-###` をキーにした Private Route Table ID マップ
- `flow_log_id`
- `flowlog_log_group_name`
