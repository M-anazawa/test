variable "vpc_name" { type = string }
variable "vpc_cidr" { type = string }
variable "azs" { type = list(string) }

variable "subnet_groups" {
  type = map(object({
    purpose   = string
    number    = number
    is_public = bool
    subnets   = list(object({ name_suffix = string, cidr = string }))
  }))
}

variable "igw_name" {
  description = "IGW Name"
  type        = string
}

variable "subnet_names_by_key" {
  description = "key=purpose-az-### to subnet name map"
  type        = map(string)

  validation {
    condition     = length(var.subnet_names_by_key) > 0
    error_message = "subnet_names_by_key must not be empty."
  }
}

variable "public_route_table_name" {
  description = "Public Route Table Name"
  type        = string
}

variable "private_route_table_names_by_key" {
  description = "key=purpose-az-### to private route table name map"
  type        = map(string)
}

variable "flowlog_name" {
  description = "VPC Flow Log Name"
  type        = string
}

variable "flowlog_log_group_name" {
  description = "CloudWatch Logs name for VPC flow logs (default: /aws/<vpc_name>/flowlog)"
  type        = string
  default     = null
}

variable "log_retention_days" {
  description = "CloudWatch Logs retention days"
  type        = number
  default     = 731
}

variable "flowlogs_role_name" {
  description = "IAM Role name for VPC flow logs"
  type        = string
}

variable "flowlogs_policy_name" {
  description = "IAM Policy name for VPC flow logs"
  type        = string
}
