variable "bucket_name" {
  type = string
}

variable "force_destroy" {
  type    = bool
  default = false
}

variable "versioning_enabled" {
  type    = bool
  default = false
}

variable "sse_algorithm" {
  type    = string
  default = "AES256"
}

variable "kms_key_arn" {
  type    = string
  default = null
}

variable "bucket_key_enabled" {
  type    = bool
  default = true
}

variable "logging" {
  type = object({
    target_bucket = string
    target_prefix = string
  })
  default = null
}

variable "bucket_policy_json" {
  type    = string
  default = null
}

variable "lifecycle_rules" {
  type = list(object({
    id                         = string
    enabled                    = bool
    expiration_days            = optional(number)
    noncurrent_expiration_days = optional(number)
  }))
  default = []
}

variable "queue_notifications" {
  type = list(object({
    id            = string
    queue_arn     = string
    events        = list(string)
    filter_prefix = optional(string)
    filter_suffix = optional(string)
  }))
  default = []
}

variable "folder_keys" {
  type    = list(string)
  default = []
}
