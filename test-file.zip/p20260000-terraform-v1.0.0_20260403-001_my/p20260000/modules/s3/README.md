﻿# modules/s3

S3 バケットを作成し、暗号化/ログ/ライフサイクル/通知を設定します。

## Usage

```hcl
module "s3_data_bucket" {
  source = "../../modules/s3"

  bucket_name   = local.data_bucket_name
  kms_key_arn   = module.cmk_s3.key_arn
  force_destroy = true

  logging = {
    target_bucket = local.s3_accesslog_bucket_name
    target_prefix = "${local.data_bucket_name}/"
  }

  bucket_policy_json = local.data_bucket_policy

  queue_notifications = [
    {
      id            = "cast-vectors-notification"
      queue_arn     = module.sqs_queue.queue_arn
      events        = ["s3:ObjectCreated:*"]
      filter_prefix = "cast_vectors/"
      filter_suffix = ".jsonl"
    },
    {
      id            = "user-vectors-notification"
      queue_arn     = module.sqs_queue.queue_arn
      events        = ["s3:ObjectCreated:*"]
      filter_prefix = "user_vectors/"
      filter_suffix = ".jsonl"
    }
  ]

  folder_keys = [
    "cast_vectors",
    "user_vectors"
  ]

  depends_on = [terraform_data.guard]
}
```

## Notes

- `kms_key_arn` を指定すると SSE アルゴリズムは自動的に `aws:kms` になります。
- `folder_keys` は末尾に `/` が付与されます。
- `queue_notifications` を使う場合、SQS 側に S3 からの送信許可が必要です。

## Inputs

- `bucket_name` (string): バケット名
- `force_destroy` (bool, optional): 強制削除
- `versioning_enabled` (bool, optional): バージョニング
- `sse_algorithm` (string, optional): SSE アルゴリズム
- `kms_key_arn` (string, optional): SSE-KMS のキー ARN
- `bucket_key_enabled` (bool, optional): バケットキー有効化
- `logging` (object, optional): アクセスログ設定
  - `target_bucket` (string): 出力先バケット
  - `target_prefix` (string): プレフィックス
- `bucket_policy_json` (string, optional): バケットポリシー (JSON)
- `lifecycle_rules` (list(object), optional): ライフサイクルルール
- `queue_notifications` (list(object), optional): SQS 通知設定
- `folder_keys` (list(string), optional): 空フォルダキー

## Outputs

- `bucket_name`: バケット名
- `bucket_arn`: バケット ARN
