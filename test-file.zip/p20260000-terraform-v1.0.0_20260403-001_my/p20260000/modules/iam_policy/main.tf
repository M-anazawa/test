resource "aws_iam_policy" "this" {
  for_each = var.policies

  name   = each.value.name
  policy = each.value.document
}
