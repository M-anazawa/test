﻿# modules/iam_policy

IAM ポリシーを複数まとめて作成します。

## Usage

```hcl
module "iam_policy" {
  source = "../../modules/iam_policy"

  policies = {
    ecsdef = {
      name     = local.iam_policy_names_for_main.ecsdef
      document = data.aws_iam_policy_document.ecsdef_policy.json
    }
    bedrock = {
      name     = local.iam_policy_names_for_main.bedrock
      document = data.aws_iam_policy_document.bedrock_policy.json
    }
    OpenSearchIngestion = {
      name     = local.iam_policy_names_for_main.OpenSearchIngestion
      document = data.aws_iam_policy_document.opensearch_ingestion_policy.json
    }
    GitHubActions = {
      name     = local.iam_policy_names_for_main.GitHubActions
      document = data.aws_iam_policy_document.github_actions_policy.json
    }
    tds3 = {
      name     = local.iam_policy_names_for_main.tds3
      document = data.aws_iam_policy_document.tds3_policy.json
    }
  }

  depends_on = [terraform_data.guard]
}
```

## Notes

- `policies` が空の場合はリソースを作成しません。

## Inputs

- `policies` (map, optional): ポリシー定義マップ
  - `name` (string): ポリシー名
  - `document` (string): ポリシードキュメント (JSON)

## Outputs

- `policy_arns`: ポリシーキー -> ARN のマップ
