variable "policies" {
  type = map(object({
    name     = string
    document = string
  }))
  default = {}
}
