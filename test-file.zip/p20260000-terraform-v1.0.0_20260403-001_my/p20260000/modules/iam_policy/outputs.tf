output "policy_arns" {
  value = {
    for key, policy in aws_iam_policy.this : key => policy.arn
  }
}
