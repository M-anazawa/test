# Regional NAT Gateway
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/nat_gateway
# https://docs.aws.amazon.com/vpc/latest/userguide/nat-gateways-regional.html
#
# Regional NAT は EIP を自動で割り当て・管理する。
# 手動で allocation_id を指定しても無視されるため、aws_eip は作成しない。

resource "aws_nat_gateway" "this" {
  connectivity_type = "public"
  availability_mode = "regional"

  # Regional NAT は subnet_id ではなく vpc_id を指定
  vpc_id = var.vpc_id

  tags = { Name = var.nat_name }
}
