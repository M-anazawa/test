# modules/nat_gateway

Regional NAT Gateway を作成します。

## Usage

```hcl
module "nat_gateway" {
  source = "../../modules/nat_gateway"

  nat_name = local.rnat_name
  vpc_id   = module.network.vpc_id

  depends_on = [module.network]
}
```

## Notes

- Regional NAT Gateway は `subnet_id` ではなく `vpc_id` を指定します（パブリックサブネット不要）
- AWS が RNAT 用ルートテーブルを自動作成し、IGW への経路が事前設定されます
- EIP は Regional NAT が自動で割り当て・管理します（手動作成不要）
- 複数 AZ に自動拡張されます

## Inputs

- `nat_name` (string): NAT Gateway 名称
- `vpc_id` (string): VPC ID

## Outputs

- `nat_gateway_id`: NAT Gateway ID
