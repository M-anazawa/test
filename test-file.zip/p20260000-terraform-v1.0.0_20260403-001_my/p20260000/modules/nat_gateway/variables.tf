variable "nat_name" {
  description = "NAT Gateway Name"
  type        = string
}

variable "vpc_id" {
  description = "VPC ID (Regional NAT Gateway 用)"
  type        = string
}
