﻿# modules/kms

KMS CMK を作成し、暗号化やローテーションを設定します。

## Usage

```hcl
module "cmk_opensearch_serverless" {
  source = "../../modules/kms"

  key_name    = local.cmk_names.opensearch_serverless
  description = "For OpenSearch Serverless"
  key_policy  = local.cmk_policy_opensearch_serverless

  depends_on = [terraform_data.guard]
}

module "cmk_s3" {
  source = "../../modules/kms"

  key_name    = local.cmk_names.s3
  description = "For S3"
  key_policy  = null

  depends_on = [terraform_data.guard]
}
resource "aws_kms_key_policy" "cmk_s3" {
  key_id = module.cmk_s3.key_id
  policy = local.cmk_policy_s3

  depends_on = [module.iam_role]
}

module "cmk_sqs" {
  source = "../../modules/kms"

  key_name    = local.cmk_names.sqs
  description = "For SQS"
  key_policy  = null

  depends_on = [terraform_data.guard]
}
resource "aws_kms_key_policy" "cmk_sqs" {
  key_id = module.cmk_sqs.key_id
  policy = local.cmk_policy_sqs

  depends_on = [module.iam_role]
}
```

## Notes

- `key_policy` が null の場合、AWS のデフォルトポリシーが適用されます。
- `rotation_period_in_days` は `enable_key_rotation = true` の場合に有効です。

## Inputs

- `key_name` (string): キー名
- `description` (string, optional): 説明
- `key_usage` (string, optional): キー用途
- `customer_master_key_spec` (string, optional): キー仕様
- `origin` (string, optional): キー作成元
- `multi_region` (bool, optional): マルチリージョン設定
- `enable_key_rotation` (bool, optional): 自動ローテーション
- `rotation_period_in_days` (number, optional): ローテーション周期 (日)
- `key_policy` (string, optional): キーポリシー (JSON)
- `tags` (map(string), optional): タグ

## Outputs

- `key_arn`: キー ARN
- `key_id`: キー ID
- `key_name`: キー名
