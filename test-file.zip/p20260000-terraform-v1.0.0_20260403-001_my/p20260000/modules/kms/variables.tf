variable "key_name" {
  type = string
}

variable "description" {
  type    = string
  default = null
}

variable "key_usage" {
  type    = string
  default = "ENCRYPT_DECRYPT"
}

variable "customer_master_key_spec" {
  type    = string
  default = "SYMMETRIC_DEFAULT"
}

variable "origin" {
  type    = string
  default = "AWS_KMS"
}

variable "multi_region" {
  type    = bool
  default = false
}

variable "enable_key_rotation" {
  type    = bool
  default = true
}

variable "rotation_period_in_days" {
  type    = number
  default = 365
}

variable "key_policy" {
  type    = string
  default = null
}

variable "tags" {
  type    = map(string)
  default = {}
}
