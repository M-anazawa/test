# modules/security_groups

Security Group と Ingress / Egress ルールをマップ定義から作成します。

## Usage

```hcl
module "security_groups" {
  source = "../../modules/security_groups"

  vpc_id = module.network.vpc_id

  groups = {
    ws = {
      name        = local.sg_names["sg_001"]
      description = "WS security group"

      ingress = [
        {
          id        = "spark-tcp-self"
          protocol  = "tcp"
          from_port = 0
          to_port   = 65535
          source    = { type = "self" }
        },
      ]

      egress = [
        {
          id        = "https-to-vpce"
          protocol  = "tcp"
          from_port = 443
          to_port   = 443
          destination = {
            type   = "sg"
            sg_key = "vpce"
          }
        },
      ]
    }

    vpce = {
      name        = local.sg_names["sg_002"]
      description = "VPC endpoints security group"

      ingress = [
        {
          id        = "https-from-ws"
          protocol  = "tcp"
          from_port = 443
          to_port   = 443
          source = {
            type   = "sg"
            sg_key = "ws"
          }
        },
      ]
      # egress 省略 = 全許可（デフォルト）
    }
  }

  depends_on = [terraform_data.guard]
}
```

## Notes

- `source.type` / `destination.type` は `cidr` / `sg` / `self` のいずれかです。
- `sg_key` は `groups` のキーを参照します。
- `egress` を省略（null）すると全許可（0.0.0.0/0 / all protocols）がデフォルト適用されます。
- `egress` を明示的に指定すると、指定したルールのみ作成されます。

## Inputs

- `vpc_id` (string): VPC ID
- `groups` (map): Security Group 定義マップ
  - `name` (string): Security Group 名称
  - `description` (string, optional): 説明
  - `ingress` (list, optional): Ingress ルール一覧
    - `id` (string, optional): ルール識別子
    - `protocol` (string)
    - `from_port` (number)
    - `to_port` (number)
    - `source` (object): 送信元定義
      - `type` (string): `cidr` | `sg` | `self`
      - `cidr` (string, optional): type が `cidr` の場合に必須
      - `sg_key` (string, optional): type が `sg` の場合に必須
  - `egress` (list, optional): Egress ルール一覧（null = 全許可）
    - `id` (string, optional): ルール識別子
    - `protocol` (string)
    - `from_port` (number, optional)
    - `to_port` (number, optional)
    - `destination` (object): 送信先定義
      - `type` (string): `cidr` | `sg` | `self`
      - `cidr` (string, optional): type が `cidr` の場合に必須
      - `sg_key` (string, optional): type が `sg` の場合に必須
- `tags` (map(string), optional): 共通タグ

## Outputs

- `sg_ids`: Security Group キー -> ID のマップ
- `sg_ids_by_name`: Security Group 名称 -> ID のマップ
