output "sg_ids" {
  description = "env security_groups key -> sg id"
  value       = { for k, sg in aws_security_group.this : k => sg.id }
}

output "sg_ids_by_name" {
  description = "sg name -> sg id"
  value       = { for k, sg in aws_security_group.this : sg.name => sg.id }
}
