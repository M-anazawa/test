locals {
  # すべての ingress ルールを平坦化（sg_key + rule_id で一意に）
  ingress_rules = flatten([
    for sg_key, sg in var.groups : [
      for idx, r in try(sg.ingress, []) : {
        sg_key    = sg_key
        rule_key  = "${sg_key}/${coalesce(try(r.id, null), tostring(idx))}"
        protocol  = r.protocol
        from_port = r.from_port
        to_port   = r.to_port
        source    = r.source
      }
    ]
  ])

  ingress_rule_map = {
    for r in local.ingress_rules : r.rule_key => r
  }

  # すべての egress ルールを平坦化
  # egress が null の場合はデフォルト全許可
  _resolved_egress = {
    for sg_key, sg in var.groups : sg_key => (
      sg.egress != null ? sg.egress : []
    )
  }

  _sgs_needing_default_egress = [
    for sg_key, sg in var.groups : sg_key if sg.egress == null
  ]

  egress_rules = concat(
    # カスタム egress ルール
    flatten([
      for sg_key, rules in local._resolved_egress : [
        for idx, r in rules : {
          sg_key      = sg_key
          rule_key    = "${sg_key}/${coalesce(try(r.id, null), tostring(idx))}"
          protocol    = r.protocol
          from_port   = try(r.from_port, null)
          to_port     = try(r.to_port, null)
          destination = r.destination
        }
      ]
    ]),
    # デフォルト全許可 egress
    [
      for sg_key in local._sgs_needing_default_egress : {
        sg_key      = sg_key
        rule_key    = "${sg_key}/allow-all"
        protocol    = "-1"
        from_port   = null
        to_port     = null
        destination = { type = "cidr", cidr = "0.0.0.0/0", sg_key = null }
      }
    ]
  )

  egress_rule_map = {
    for r in local.egress_rules : r.rule_key => r
  }
}

resource "aws_security_group" "this" {
  for_each = var.groups

  name        = each.value.name
  description = coalesce(try(each.value.description, null), "security group (${each.key})")
  vpc_id      = var.vpc_id

  tags = merge(
    var.tags,
    { Name = each.value.name }
  )

  lifecycle {
    create_before_destroy = true
  }
}

# Ingress rules（CIDR/SG/self対応）
resource "aws_vpc_security_group_ingress_rule" "this" {
  for_each = local.ingress_rule_map

  security_group_id = aws_security_group.this[each.value.sg_key].id
  ip_protocol       = each.value.protocol
  from_port         = each.value.from_port
  to_port           = each.value.to_port

  # CIDR
  cidr_ipv4 = (
    each.value.source.type == "cidr"
    ? each.value.source.cidr
    : null
  )

  # SG参照 or self
  referenced_security_group_id = (
    each.value.source.type == "sg"
    ? aws_security_group.this[each.value.source.sg_key].id
    : each.value.source.type == "self"
    ? aws_security_group.this[each.value.sg_key].id
    : null
  )

  lifecycle {
    precondition {
      condition     = contains(["cidr", "sg", "self"], each.value.source.type)
      error_message = "Invalid ingress source.type for ${each.key}. allowed: cidr|sg|self"
    }
    precondition {
      condition = (
        each.value.source.type != "cidr" || try(each.value.source.cidr, "") != ""
      )
      error_message = "source.type==cidr requires source.cidr for ${each.key}"
    }
    precondition {
      condition = (
        each.value.source.type != "sg" || try(each.value.source.sg_key, "") != ""
      )
      error_message = "source.type==sg requires source.sg_key for ${each.key}"
    }
  }
}

# Egress rules（CIDR/SG/self対応）
resource "aws_vpc_security_group_egress_rule" "this" {
  for_each = local.egress_rule_map

  security_group_id = aws_security_group.this[each.value.sg_key].id
  ip_protocol       = each.value.protocol
  from_port         = each.value.from_port
  to_port           = each.value.to_port

  # CIDR
  cidr_ipv4 = (
    each.value.destination.type == "cidr"
    ? each.value.destination.cidr
    : null
  )

  # SG参照 or self
  referenced_security_group_id = (
    each.value.destination.type == "sg"
    ? aws_security_group.this[each.value.destination.sg_key].id
    : each.value.destination.type == "self"
    ? aws_security_group.this[each.value.sg_key].id
    : null
  )

  lifecycle {
    precondition {
      condition     = contains(["cidr", "sg", "self"], each.value.destination.type)
      error_message = "Invalid egress destination.type for ${each.key}. allowed: cidr|sg|self"
    }
    precondition {
      condition = (
        each.value.destination.type != "cidr" || try(each.value.destination.cidr, "") != ""
      )
      error_message = "destination.type==cidr requires destination.cidr for ${each.key}"
    }
    precondition {
      condition = (
        each.value.destination.type != "sg" || try(each.value.destination.sg_key, "") != ""
      )
      error_message = "destination.type==sg requires destination.sg_key for ${each.key}"
    }
  }
}
