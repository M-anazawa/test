variable "vpc_id" {
  type = string
}

# SG定義（tfvarsから渡す）
variable "groups" {
  type = map(object({
    name        = string
    description = optional(string)
    ingress = optional(list(object({
      id        = optional(string) # ルール安定キー（推奨）
      protocol  = string
      from_port = number
      to_port   = number
      source = object({
        type   = string # "cidr" | "sg" | "self"
        cidr   = optional(string)
        sg_key = optional(string) # source.type=="sg" のとき必須（tfvars security_groups のキー）
      })
    })), [])
    egress = optional(list(object({
      id        = optional(string) # ルール安定キー（推奨）
      protocol  = string
      from_port = optional(number)
      to_port   = optional(number)
      destination = object({
        type   = string # "cidr" | "sg" | "self"
        cidr   = optional(string)
        sg_key = optional(string)
      })
    }))) # null = 全許可（デフォルト）
  }))
}

variable "tags" {
  description = "Common tags for resources in this module"
  type        = map(string)
  default     = {}
}
