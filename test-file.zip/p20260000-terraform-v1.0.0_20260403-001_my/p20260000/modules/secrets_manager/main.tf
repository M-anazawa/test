resource "aws_secretsmanager_secret" "this" {
  name = var.secret_name
  tags = var.tags

  dynamic "replica" {
    for_each = var.replica_regions
    content {
      region = replica.value
    }
  }
}

resource "aws_secretsmanager_secret_rotation" "this" {
  count = var.rotation_enabled ? 1 : 0

  secret_id           = aws_secretsmanager_secret.this.id
  rotation_lambda_arn = var.rotation_lambda_arn

  rotation_rules {
    automatically_after_days = var.rotation_interval_days
  }
}
