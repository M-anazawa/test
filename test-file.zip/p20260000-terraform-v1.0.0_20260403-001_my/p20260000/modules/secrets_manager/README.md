﻿# modules/secrets_manager

Secrets Manager のシークレットを作成し、必要に応じてローテーションを設定します。

## Usage

```hcl
module "secrets_manager" {
  source = "../../modules/secrets_manager"

  secret_name = local.secret_name

  depends_on = [terraform_data.guard]
}
```

## Notes

- `rotation_enabled = true` の場合、`rotation_lambda_arn` が必須です。
- `replica_regions` を指定するとリージョンレプリカが作成されます。

## Inputs

- `secret_name` (string): シークレット名
- `rotation_enabled` (bool, optional): ローテーション有効化
- `rotation_lambda_arn` (string, optional): ローテーション Lambda ARN
- `rotation_interval_days` (number, optional): ローテーション間隔 (日)
- `replica_regions` (list(string), optional): レプリカリージョン一覧
- `tags` (map(string), optional): タグ

## Outputs

- `secret_arn`: シークレット ARN
- `secret_name`: シークレット名
