variable "secret_name" {
  type = string
}

variable "rotation_enabled" {
  type    = bool
  default = false
}

variable "rotation_lambda_arn" {
  type    = string
  default = null

  validation {
    condition     = var.rotation_enabled ? (var.rotation_lambda_arn != null && var.rotation_lambda_arn != "") : true
    error_message = "rotation_lambda_arn is required when rotation_enabled is true."
  }
}

variable "rotation_interval_days" {
  type    = number
  default = 30
}

variable "replica_regions" {
  type    = list(string)
  default = []
}

variable "tags" {
  type    = map(string)
  default = {}
}
