variable "firewall_name" {
  description = "Network Firewall name"
  type        = string
}

variable "policy_name" {
  description = "Firewall Policy name"
  type        = string
}

variable "rule_group_name" {
  description = "Stateful Rule Group name"
  type        = string
}

variable "vpc_id" {
  description = "VPC ID"
  type        = string
}

variable "subnet_ids" {
  description = "Subnet IDs to deploy firewall endpoints (map of key => subnet_id)"
  type        = map(string)
}

variable "rule_group_capacity" {
  description = "Stateful rule group capacity"
  type        = number
  default     = 100
}

variable "log_retention_in_days" {
  description = "CloudWatch Logs retention period in days for firewall logs"
  type        = number
  default     = 731
}
