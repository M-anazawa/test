# Stateful Rule Group（初期: 全許可）
resource "aws_networkfirewall_rule_group" "this" {
  capacity = var.rule_group_capacity
  name     = var.rule_group_name
  type     = "STATEFUL"

  rule_group {
    rules_source {
      stateful_rule {
        action = "PASS"
        header {
          destination      = "ANY"
          destination_port = "ANY"
          direction        = "ANY"
          protocol         = "IP"
          source           = "ANY"
          source_port      = "ANY"
        }
        rule_option {
          keyword  = "sid"
          settings = ["1"]
        }
      }
    }
  }

  tags = { Name = var.rule_group_name }
}

# Firewall Policy
resource "aws_networkfirewall_firewall_policy" "this" {
  name = var.policy_name

  firewall_policy {
    stateless_default_actions          = ["aws:forward_to_sfe"]
    stateless_fragment_default_actions = ["aws:forward_to_sfe"]

    stateful_rule_group_reference {
      resource_arn = aws_networkfirewall_rule_group.this.arn
    }
  }

  tags = { Name = var.policy_name }
}

# Firewall
resource "aws_networkfirewall_firewall" "this" {
  name                = var.firewall_name
  firewall_policy_arn = aws_networkfirewall_firewall_policy.this.arn
  vpc_id              = var.vpc_id

  dynamic "subnet_mapping" {
    for_each = var.subnet_ids
    content {
      subnet_id = subnet_mapping.value
    }
  }

  tags = { Name = var.firewall_name }
}

# ==================================================
# Logging（Alert / Flow / TLS → CloudWatch Logs）
# ==================================================

resource "aws_cloudwatch_log_group" "alert" {
  name              = "/aws/${var.firewall_name}/alert"
  retention_in_days = var.log_retention_in_days

  tags = { Name = "/aws/${var.firewall_name}/alert" }
}

resource "aws_cloudwatch_log_group" "flow" {
  name              = "/aws/${var.firewall_name}/flow"
  retention_in_days = var.log_retention_in_days

  tags = { Name = "/aws/${var.firewall_name}/flow" }
}

resource "aws_cloudwatch_log_group" "tls" {
  name              = "/aws/${var.firewall_name}/tls"
  retention_in_days = var.log_retention_in_days

  tags = { Name = "/aws/${var.firewall_name}/tls" }
}

# ==================================================
# モニタリング設定
# ==================================================
# ファイアウォールモニタリングダッシュボード: 無効（Terraform Provider 未対応）
# トラフィック分析モード: 無効（Terraform Provider 未対応）

resource "aws_networkfirewall_logging_configuration" "this" {
  firewall_arn = aws_networkfirewall_firewall.this.arn

  logging_configuration {
    log_destination_config {
      log_destination = {
        logGroup = aws_cloudwatch_log_group.alert.name
      }
      log_destination_type = "CloudWatchLogs"
      log_type             = "ALERT"
    }

    log_destination_config {
      log_destination = {
        logGroup = aws_cloudwatch_log_group.flow.name
      }
      log_destination_type = "CloudWatchLogs"
      log_type             = "FLOW"
    }

    log_destination_config {
      log_destination = {
        logGroup = aws_cloudwatch_log_group.tls.name
      }
      log_destination_type = "CloudWatchLogs"
      log_type             = "TLS"
    }
  }
}
