# modules/network_firewall

AWS Network Firewall（Firewall + Policy + Stateful Rule Group + Logging）を作成します。

## Usage

```hcl
module "network_firewall" {
  source = "../../modules/network_firewall"

  firewall_name   = local.nfw_names["firewall"]
  policy_name     = local.nfw_names["policy"]
  rule_group_name = local.nfw_names["rule_group"]

  vpc_id = module.network.vpc_id

  subnet_ids = {
    for k in local.fw_route_table_keys :
    k => module.network.subnet_ids[k]
  }

  depends_on = [terraform_data.guard]
}
```

## Notes

- 初期ルールは Stateful Pass ALL（全許可）です。
- 将来 FQDN 制御に切り替える際は、rule_group の rules_source を変更します。
- `endpoint_ids_by_az` 出力は、ルートテーブルの 0.0.0.0/0 ターゲットとして使用できます。
- Alert / Flow / TLS ログは CloudWatch Logs に出力されます（デフォルト保存期間: 731日）。
- ファイアウォールモニタリングダッシュボード・トラフィック分析モードは無効です（Terraform Provider 未対応）。

## Inputs

- `firewall_name` (string): Firewall 名称
- `policy_name` (string): Firewall Policy 名称
- `rule_group_name` (string): Stateful Rule Group 名称
- `vpc_id` (string): VPC ID
- `subnet_ids` (map(string)): Firewall endpoint を配置するサブネット ID マップ
- `rule_group_capacity` (number, optional): Stateful Rule Group のキャパシティ（default: 100）
- `log_retention_in_days` (number, optional): CloudWatch Logs 保存期間（default: 731）

## Outputs

- `firewall_id`: Firewall ID
- `firewall_arn`: Firewall ARN
- `endpoint_ids_by_az`: AZ → NFW endpoint ID のマップ（ルートテーブル設定用）
- `log_group_names`: ログタイプ → CloudWatch Log Group 名のマップ（alert, flow, tls）
