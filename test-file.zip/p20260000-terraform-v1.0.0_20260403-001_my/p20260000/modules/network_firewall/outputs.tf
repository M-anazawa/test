output "firewall_id" {
  description = "Network Firewall ID"
  value       = aws_networkfirewall_firewall.this.id
}

output "firewall_arn" {
  description = "Network Firewall ARN"
  value       = aws_networkfirewall_firewall.this.arn
}

output "endpoint_ids_by_az" {
  description = "AZ -> NFW endpoint ID map (for route table targets)"
  value = {
    for ss in aws_networkfirewall_firewall.this.firewall_status[0].sync_states :
    ss.availability_zone => ss.attachment[0].endpoint_id
  }
}

output "log_group_names" {
  description = "Log type -> CloudWatch Log Group name map"
  value = {
    alert = aws_cloudwatch_log_group.alert.name
    flow  = aws_cloudwatch_log_group.flow.name
    tls   = aws_cloudwatch_log_group.tls.name
  }
}
