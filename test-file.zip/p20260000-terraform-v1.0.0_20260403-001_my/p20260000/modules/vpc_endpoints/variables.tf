variable "vpc_id" {
  type = string
}

variable "interface_subnet_ids" {
  description = "Interface endpoints will be placed into these subnets"
  type        = list(string)
}

variable "interface_security_group_ids" {
  description = "Security groups for Interface endpoints"
  type        = list(string)
}

variable "gateway_route_table_ids" {
  description = "Route tables for Gateway endpoints"
  type        = list(string)
}

variable "endpoints" {
  description = "VPC endpoints definition map"
  type = map(object({
    name          = string
    service_name  = string
    endpoint_type  = string                # "Interface" | "Gateway"
    private_dns    = optional(bool)        # for Interface only
    policy_enabled = optional(bool, true)  # false = skip policy (for services that only accept full-access)
  }))
}

variable "tags" {
  description = "Common tags"
  type        = map(string)
  default     = {}
}
