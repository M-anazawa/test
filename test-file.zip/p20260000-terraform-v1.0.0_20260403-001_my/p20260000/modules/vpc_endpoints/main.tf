locals {
  allow_all_policy = jsonencode({
    Version = "2008-10-17"
    Statement = [
      {
        Effect    = "Allow"
        Principal = "*"
        Action    = "*"
        Resource  = "*"
      }
    ]
  })
}

resource "aws_vpc_endpoint" "this" {
  for_each = var.endpoints

  vpc_id            = var.vpc_id
  service_name      = each.value.service_name
  vpc_endpoint_type = each.value.endpoint_type

  # policy: AllowAll（サービスが明示ポリシーを拒否する場合は省略）
  policy = each.value.policy_enabled ? local.allow_all_policy : null

  # Interface: priend subnet + sg + private dns true
  subnet_ids = (
    each.value.endpoint_type == "Interface"
    ? var.interface_subnet_ids
    : null
  )

  security_group_ids = (
    each.value.endpoint_type == "Interface"
    ? var.interface_security_group_ids
    : null
  )

  private_dns_enabled = (
    each.value.endpoint_type == "Interface"
    ? coalesce(try(each.value.private_dns, null), true)
    : null
  )

  # Gateway: route tables
  route_table_ids = (
    each.value.endpoint_type == "Gateway"
    ? var.gateway_route_table_ids
    : null
  )

  tags = merge(
    var.tags,
    { Name = each.value.name }
  )
}
