﻿# modules/vpc_endpoints

VPC Endpoint (Interface/Gateway) を定義マップから作成します。

## Usage

```hcl
module "vpc_endpoints" {
  source = "../../modules/vpc_endpoints"

  vpc_id = module.network.vpc_id

  interface_subnet_ids         = local.interface_subnet_ids
  interface_security_group_ids = [module.security_groups.sg_ids["endpoint"]]
  gateway_route_table_ids      = local.private_route_table_ids

  endpoints = {
    s3 = {
      name          = local.generic_names_by_key["vpce_s3"]
      service_name  = "com.amazonaws.${data.aws_region.current.region}.s3"
      endpoint_type = "Gateway"
    }

    ecr_api = {
      name          = local.generic_names_by_key["vpce_ecr_api"]
      service_name  = "com.amazonaws.${data.aws_region.current.region}.ecr.api"
      endpoint_type = "Interface"
      private_dns   = true
    }

    ecr_dkr = {
      name          = local.generic_names_by_key["vpce_ecr_dkr"]
      service_name  = "com.amazonaws.${data.aws_region.current.region}.ecr.dkr"
      endpoint_type = "Interface"
      private_dns   = true
    }

    logs = {
      name          = local.generic_names_by_key["vpce_logs"]
      service_name  = "com.amazonaws.${data.aws_region.current.region}.logs"
      endpoint_type = "Interface"
      private_dns   = true
    }

    ssm = {
      name          = local.generic_names_by_key["vpce_ssm"]
      service_name  = "com.amazonaws.${data.aws_region.current.region}.ssm"
      endpoint_type = "Interface"
      private_dns   = true
    }

    ssmmessages = {
      name          = local.generic_names_by_key["vpce_ssmmessages"]
      service_name  = "com.amazonaws.${data.aws_region.current.region}.ssmmessages"
      endpoint_type = "Interface"
      private_dns   = true
    }

    ec2messages = {
      name          = local.generic_names_by_key["vpce_ec2messages"]
      service_name  = "com.amazonaws.${data.aws_region.current.region}.ec2messages"
      endpoint_type = "Interface"
      private_dns   = true
    }

    bedrock_runtime = {
      name          = local.generic_names_by_key["vpce_bedrock_runtime"]
      service_name  = "com.amazonaws.${data.aws_region.current.region}.bedrock-runtime"
      endpoint_type = "Interface"
      private_dns   = true
    }

    secretsmanager = {
      name          = local.generic_names_by_key["vpce_secretsmanager"]
      service_name  = "com.amazonaws.${data.aws_region.current.region}.secretsmanager"
      endpoint_type = "Interface"
      private_dns   = true
    }

    sqs = {
      name          = local.generic_names_by_key["vpce_sqs"]
      service_name  = "com.amazonaws.${data.aws_region.current.region}.sqs"
      endpoint_type = "Interface"
      private_dns   = true
    }

    kms = {
      name          = local.generic_names_by_key["vpce_kms"]
      service_name  = "com.amazonaws.${data.aws_region.current.region}.kms"
      endpoint_type = "Interface"
      private_dns   = true
    }

    sts = {
      name          = local.generic_names_by_key["vpce_sts"]
      service_name  = "com.amazonaws.${data.aws_region.current.region}.sts"
      endpoint_type = "Interface"
      private_dns   = true
    }

    bedrock = {
      name          = local.generic_names_by_key["vpce_bedrock"]
      service_name  = "com.amazonaws.${data.aws_region.current.region}.bedrock"
      endpoint_type = "Interface"
      private_dns   = true
    }
  }

  depends_on = [terraform_data.guard]
}
```

## Notes

- Endpoint ポリシーは全許可 (AllowAll) で作成されます。
- `endpoint_type = "Interface"` の場合は `interface_subnet_ids` と `interface_security_group_ids` が必須です。
- `endpoint_type = "Gateway"` の場合は `gateway_route_table_ids` が必須です。

## Inputs

- `vpc_id` (string): VPC ID
- `interface_subnet_ids` (list(string)): Interface 用サブネット
- `interface_security_group_ids` (list(string)): Interface 用 Security Group
- `gateway_route_table_ids` (list(string)): Gateway 用 Route Table
- `endpoints` (map): Endpoint 定義マップ
  - `name` (string): Endpoint 名称
  - `service_name` (string): AWS サービス名
  - `endpoint_type` (string): `Interface` | `Gateway`
  - `private_dns` (bool, optional): Interface のみ
- `tags` (map(string), optional): 共通タグ

## Outputs

- `endpoint_ids`: Endpoint キー -> ID のマップ
