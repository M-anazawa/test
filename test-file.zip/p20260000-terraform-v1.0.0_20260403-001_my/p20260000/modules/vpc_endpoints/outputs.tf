output "endpoint_ids" {
  description = "map of endpoint ids"
  value       = { for k, v in aws_vpc_endpoint.this : k => v.id }
}
