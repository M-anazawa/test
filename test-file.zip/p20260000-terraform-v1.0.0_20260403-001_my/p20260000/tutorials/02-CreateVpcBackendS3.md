### 02-CreateVpcBackendS3.md
# Terraform チュートリアル
このチュートリアルでは **VPC（private subnet * 2 / IGW * 1 / リージョナルNAT * 1）を作成**して、`plan → apply → destroy` を体験します。

作るもの：**VPC一式（private×2, IGW×1, Regional NAT×1）**  
前提：**tutorials/01-CreateS3LocalBackend.md** が完了していること  
方針：**state（状態ファイル）は S3 backend（tutorials/01-CreateS3LocalBackend.mdで作成したS3バケット）に保存**（`use_lockfile = true`）

---

## 1. フォルダ構成
次のフォルダ構成になるように **任意の場所にフォルダを作成** してください。
```
tutorial-02/
  main/
    backend.tf
    main.tf
    variables.tf
    terraform.tfvars
    outputs.tf
  modules/
    vpc_basic/
      main.tf
      variables.tf
      outputs.tf
```

## 2. モジュール側（ローカルモジュール）
次のファイルを作成してください。

参考：
- Modules（概要）: https://developer.hashicorp.com/terraform/language/modules
- Resource ブロック: https://developer.hashicorp.com/terraform/language/block/resource

### 2-1. modules/vpc_basic/main.tf
```
data "aws_availability_zones" "available" {
  state = "available"
}

locals {
  # 先頭2つのAZを使う（例: ap-northeast-1a, ap-northeast-1c など）
  azs = slice(data.aws_availability_zones.available.names, 0, 2)

  # private subnet を2つ作る（/16 -> /24 を想定）
  private_subnet_cidrs = [
    cidrsubnet(var.vpc_cidr, 8, 0),
    cidrsubnet(var.vpc_cidr, 8, 1),
  ]
}

resource "aws_vpc" "this" {
  cidr_block           = var.vpc_cidr
  enable_dns_support   = true
  enable_dns_hostnames = true

  tags = merge(var.tags, {
    Name = "${var.name_prefix}-vpc"
  })
}

# Internet Gateway（Regional NAT が外へ出るために必要）
resource "aws_internet_gateway" "this" {
  vpc_id = aws_vpc.this.id

  tags = merge(var.tags, {
    Name = "${var.name_prefix}-igw"
  })
}

# Private Subnets (2)
resource "aws_subnet" "private" {
  count             = 2
  vpc_id            = aws_vpc.this.id
  cidr_block        = local.private_subnet_cidrs[count.index]
  availability_zone = local.azs[count.index]

  tags = merge(var.tags, {
    Name = "${var.name_prefix}-private-${local.azs[count.index]}"
  })
}

# NAT Gateway (Regional)
# Regional NAT は public subnet を指定しない（subnet_id 不要）
# EIP は Regional NAT が自動で割り当て・管理する（手動作成不要）
resource "aws_nat_gateway" "this" {
  connectivity_type = "public"
  availability_mode = "regional"

  # Regional NAT は VPC に作る（subnet_id の代わりに vpc_id）
  vpc_id = aws_vpc.this.id

  tags = merge(var.tags, {
    Name = "${var.name_prefix}-natgw"
  })
}

# Route Table (Private) - private subnet から NAT へデフォルトルート
resource "aws_route_table" "private" {
  vpc_id = aws_vpc.this.id

  tags = merge(var.tags, {
    Name = "${var.name_prefix}-rtb-private"
  })
}

resource "aws_route" "private_nat" {
  route_table_id         = aws_route_table.private.id
  destination_cidr_block = "0.0.0.0/0"
  nat_gateway_id         = aws_nat_gateway.this.id
}

resource "aws_route_table_association" "private" {
  count          = 2
  subnet_id      = aws_subnet.private[count.index].id
  route_table_id = aws_route_table.private.id
}
```

参考（主要リソース / データソース）：
- `aws_vpc`: https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/vpc
- `aws_subnet`: https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/subnet
- `aws_internet_gateway`: https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/internet_gateway.html
- `aws_route_table`: https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route_table
- `aws_route`: https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route
- `aws_route_table_association`: https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/route_table_association
- `aws_nat_gateway`（availability_mode=regional など）: https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/nat_gateway
- `aws_availability_zones`: https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/availability_zones
- AWS公式：Regional NAT gateway: https://docs.aws.amazon.com/vpc/latest/userguide/nat-gateways-regional.html

### 2-2. modules/vpc_basic/variables.tf
```
variable "name_prefix" {
    type = string
    description = "リソース名のプレフィックス"
}

variable "vpc_cidr" {
    type = string
    description = "VPC CIDR（例: 10.0.0.0/16）"
}

variable "tags" {
    type = map(string)
    description = "タグ"
    default = {}
}
```

参考：
- Input Variables: https://developer.hashicorp.com/terraform/language/values/variables
- Type Constraints: https://developer.hashicorp.com/terraform/language/expressions/type-constraints

### 2-3. modules/vpc_basic/outputs.tf
```
output "vpc_id" {
  value = aws_vpc.this.id
}

output "private_subnet_ids" {
  value = [for s in aws_subnet.private : s.id]
}

output "internet_gateway_id" {
  value = aws_internet_gateway.this.id
}

output "nat_gateway_id" {
  value = aws_nat_gateway.this.id
}
```

参考：
- Outputs: https://developer.hashicorp.com/terraform/language/values/outputs

---

## 3. ファイルを作成
次のファイルを作成してください。

### 3-1. tutorial-02/main/backend.tf（S3 backend）
**01-CreateS3LocalBackend.mdで作成したS3バケット名**に置き換えてください。
```
terraform {
    backend "s3" {
    bucket = "YOUR_TFSTATE_BUCKET_NAME" # ← 01-CreateS3LocalBackend.mdで確認した terraform output -raw bucket_name の値に置換
    key = "tutorial-02/vpc/terraform.tfstate"
    region = "ap-northeast-1"
    use_lockfile = true
    }
}
```

参考：
- S3 backend: https://developer.hashicorp.com/terraform/language/backend/s3

### 3-2. tutorial-02/main/main.tf
```
provider "aws" {
    region = var.aws_region
}

module "demo_vpc" {
    source = "../modules/vpc_basic"
    name_prefix = var.name_prefix
    vpc_cidr = var.vpc_cidr
    tags = var.tags
}
```

参考：
- Provider ブロック: https://developer.hashicorp.com/terraform/language/block/provider
- Module ブロック: https://developer.hashicorp.com/terraform/language/block/module
- Modules: https://developer.hashicorp.com/terraform/language/modules/configuration

### 3-3. tutorial-02/main/variables.tf
```
variable "aws_region" {
    type = string
    description = "AWS region"
    default = "ap-northeast-1"
}

variable "name_prefix" {
    type = string
    description = "リソース名のプレフィックス"
    default = "tutorial-02"
}

variable "vpc_cidr" {
    type = string
    description = "VPC CIDR（例: 10.0.0.0/16）"
    default = "10.0.0.0/16"
}

variable "tags" {
    type = map(string)
    description = "タグ"
    default = {}
}
```

参考：
- Input Variables: https://developer.hashicorp.com/terraform/language/values/variables

### 3-4. tutorial-02/main/terraform.tfvars
```
name_prefix = "tutorial-02"
vpc_cidr = "10.0.0.0/16"
tags = {
    Project = "terraform-tutorial"
    Env = "dev"
}
```

参考：
- 変数定義ファイル（`terraform.tfvars` など）: https://developer.hashicorp.com/terraform/language/values/variables

### 3-5. tutorial-02/main/outputs.tf
```
output "vpc_id" {
  value = module.demo_vpc.vpc_id
}

output "private_subnet_ids" {
  value = module.demo_vpc.private_subnet_ids
}

output "internet_gateway_id" {
  value = module.demo_vpc.internet_gateway_id
}

output "nat_gateway_id" {
  value = module.demo_vpc.nat_gateway_id
}
```


参考：
- Output ブロック: https://developer.hashicorp.com/terraform/language/block/output
- Outputs: https://developer.hashicorp.com/terraform/language/values/outputs

---

## 4. 実行

参考（コマンド全体）:
- Terraform CLI コマンド一覧: https://developer.hashicorp.com/terraform/cli/commands

### 4-1. 実行フォルダへ移動
```
cd tutorial-02/main
```

### 4-2. 初期化
次のコマンドを実行すると ローカル に次のファイル/フォルダが保存されます。
- .terraform/              ： AWS操作用の部品
- .terraform.lock.hcl      ： Providerバージョン固定情報
```
terraform init
```

参考：
- `terraform init`: https://developer.hashicorp.com/terraform/cli/commands/init

### 4-3. 変更点確認
```
terraform plan
```

参考：
- `terraform plan`: https://developer.hashicorp.com/terraform/cli/commands/plan

### 4-4. 作成
```
terraform apply
Enter a value: yes
```

参考：
- `terraform apply`: https://developer.hashicorp.com/terraform/cli/commands/apply

### 4-5. 作成できたか確認（AWS CLI）
#### VPC ID を表示
```
terraform output -raw vpc_id
```

#### VPC を AWS CLI で確認（例：VPC一覧）
```
aws ec2 describe-vpcs --query "Vpcs[].VpcId" --output text
```

参考：
- `terraform output`: https://developer.hashicorp.com/terraform/cli/commands/output
- AWS CLI `describe-vpcs`: https://docs.aws.amazon.com/cli/latest/reference/ec2/describe-vpcs.html

#### terraform.tfstate の保存場所確認
**01-CreateS3LocalBackend.md で作成した S3 の tutorial-02/vpc/ 配下**に **terraform.tfstate が保存**されていることを確認

### 4-6. 後片付け(削除)
```
terraform destroy
Enter a value: yes
```

参考：
- `terraform destroy`: https://developer.hashicorp.com/terraform/cli/commands/destroy

---


## 5. コードの詳細解説
このチュートリアルは「S3 backend に state を保存しながら、VPC 一式（privateサブネット×2、IGW、Regional NAT）を作成する」流れになっています。  
各ファイルの役割と流れを順番に説明します。

### 5-1. まず覚える用語 
- **state**: 作ったものの記録ファイル（S3に保存）

### 5-2. フォルダ構成の意図
- `modules/vpc_basic/` は「VPC 一式を作る部品」を置く場所  
- `main/` は「その部品を使って実際に作る場所」  
- backend を S3 にするので、state はローカルではなく S3 に保存されます

### 5-3. モジュール側の役割（部品側）
#### modules/vpc_basic/main.tf
- 使える AZ を取得し、先頭 2 つを使います  
- private subnet の CIDR を 2 つ作ります  
- `aws_vpc` を中心に、IGW / private subnet / ルートテーブル / Regional NAT をまとめて作ります  
- private subnet は NAT に向けて `0.0.0.0/0` の道（ルート）を作ります  
- Regional NAT は public subnet を必要としないため、このチュートリアルでは public subnet を作りません

#### modules/vpc_basic/variables.tf
- `name_prefix` は名前の先頭に付ける文字です  
- `vpc_cidr` は VPC の範囲を決める値です  
- `tags` は任意のメモです

#### modules/vpc_basic/outputs.tf
- 作成した VPC、privateサブネット、IGW、NAT の ID を外に返します  
- これで、あとから `terraform output` で確認できます

### 5-4. ルートモジュール側の役割（実行側）
#### main/backend.tf
- `backend "s3"` は「記録（state）を S3 に置く」設定です  
- `bucket` は 01 で作ったバケット名に置き換えます  
- `key` は保存先のパスです  
- `use_lockfile = true` により、S3上のロックファイル方式を使います

#### main/main.tf
- `provider "aws"` は「どの AWS（リージョン）を操作するか」を決めます  
- `module "demo_vpc"` は「部品を使います」という宣言です  
- 必要な値（name_prefix / vpc_cidr / tags）を渡します

#### main/variables.tf / main/terraform.tfvars
- 実行時に変えたい値を `variables.tf` で定義し、`terraform.tfvars` で値を入れます  
- `terraform.tfvars` に書くと、毎回コマンドで入力しなくて済みます

#### main/outputs.tf
- モジュールから返ってきた値を、さらに外に出します  
- `terraform output -raw vpc_id` などで確認できます

### 5-5. `plan` / `apply` / `destroy` と state
- `terraform plan` は「何が作られるかの予告」です  
- `terraform apply` は「実際に作る」操作です  
- 作った結果は S3 の `key` に記録されます  
- `terraform destroy` は「作ったものを消す」操作です

### 5-6. S3 backend のポイント
- `backend.tf` は `terraform init` で読み込まれます  
- `bucket` や `key` を変えたら `terraform init -reconfigure` が必要です  
- state を S3 に置くと、紛失や複数人作業のリスクを下げられます

### 5-7. 出力値の活用例
- `terraform output -raw vpc_id` で VPC ID をすぐ確認できます  
- AWS CLI と組み合わせると、作成結果を確認できます
