# Terraform チュートリアル
このチュートリアルでは **実際にAWSリソースを1つ作成**して、`plan → apply → destroy` を体験します。  

作るもの：**S3バケット（1個）**  
前提：**AWS CLI認証**（ローカルモジュール構成）  
方針：**state（状態ファイル）はローカル保存**

---

## 0. 事前準備
### 0-1. ツール確認
PowerShellで次を実行し、terraformとAWS CLIがインストールされていることを確認する。

参考：
- AWS CLI（インストール）: https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html
- Terraform CLI インストール: 
  1. PowerShellを開き次を実行する
    ```
    winget install Hashicorp.Terraform --version 1.14.3​
    ```
  2. PowerShellを開きなおして次を実行する​
    ```
    terraform --version​
    ```

### 0-2. AWS認証確認
AWS CLIプロファイル(default)を設定後、PowerShellで次を実行し、**AWSアカウントが正しいこと** を必ず確認してください。
```
aws sts get-caller-identity
```

参考：
- AWS CLI `sts get-caller-identity`: https://docs.aws.amazon.com/cli/latest/reference/sts/get-caller-identity.html

## 1. フォルダ構成
次のフォルダ構成になるように **任意の場所にフォルダを作成** してください。
```
tutorial-01/
  main/
    main.tf
    variables.tf
    terraform.tfvars
    outputs.tf
  modules/
    s3_bucket/
      main.tf
      variables.tf
      outputs.tf
```

## 2. モジュール側（ローカルモジュール）
次のファイルを作成してください。

参考：
- Modules（概要）: https://developer.hashicorp.com/terraform/language/modules
- Resource ブロック: https://developer.hashicorp.com/terraform/language/block/resource

### 2-1. modules/s3_bucket/main.tf
```
resource "aws_s3_bucket" "this" {
  bucket = var.bucket_name
  force_destroy = true
  tags   = var.tags
}
```

参考：
- `aws_s3_bucket`（Terraform AWS Provider）: https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket

### 2-2. modules/s3_bucket/variables.tf
```
variable "bucket_name" {
  type        = string
  description = "作成するS3バケット名（全世界で一意）"
}

variable "tags" {
  type        = map(string)
  description = "タグ"
  default     = {}
}
```

参考：
- Input Variables: https://developer.hashicorp.com/terraform/language/values/variables

### 2-3. modules/s3_bucket/outputs.tf
```
output "bucket_name" {
  value = aws_s3_bucket.this.bucket
}
```

参考：
- Outputs: https://developer.hashicorp.com/terraform/language/values/outputs

## 3. ファイルを作成
次のファイルを作成してください。

### 3-1. tutorial-01/main/main.tf
```
provider "aws" {
  region = var.aws_region
}

module "demo_bucket" {
  source      = "../modules/s3_bucket"
  bucket_name = var.bucket_name
  tags        = var.tags
}
```

参考：
- Provider ブロック: https://developer.hashicorp.com/terraform/language/block/provider
- Module ブロック: https://developer.hashicorp.com/terraform/language/block/module
- Modules: https://developer.hashicorp.com/terraform/language/modules/configuration

### 3-2. tutorial-01/main/variables.tf
```
variable "aws_region" {
  type        = string
  description = "AWS region"
  default     = "ap-northeast-1"
}

variable "bucket_name" {
  type        = string
  description = "作成するS3バケット名（全世界で一意）"
}

variable "tags" {
  type        = map(string)
  description = "タグ"
  default     = {}
}
```

参考：
- Input Variables: https://developer.hashicorp.com/terraform/language/values/variables
- Type Constraints（`string` / `map(string)` など）: https://developer.hashicorp.com/terraform/language/expressions/type-constraints

### 3-3. tutorial-01/main/terraform.tfvars
**S3バケット名は 全世界で一意** にする必要があります。
```
bucket_name = "YOUR-UNIQUE-BUCKET-NAME-20260222"
tags = {
  Project = "terraform-tutorial"
  Env     = "dev"
}
```

参考：
- 変数定義ファイル（`terraform.tfvars` など）: https://developer.hashicorp.com/terraform/language/values/variables
- S3バケット命名規則: https://docs.aws.amazon.com/AmazonS3/latest/userguide/bucketnamingrules.html
- S3バケットの基本: https://docs.aws.amazon.com/AmazonS3/latest/userguide/UsingBucket.html

### 3-4. tutorial-01/main/outputs.tf
```
output "bucket_name" {
  value = module.demo_bucket.bucket_name
}
```

参考：
- Output ブロック: https://developer.hashicorp.com/terraform/language/block/output
- Outputs: https://developer.hashicorp.com/terraform/language/values/outputs

## 4. 実行

参考（コマンド全体）:
- Terraform CLI コマンド一覧: https://developer.hashicorp.com/terraform/cli/commands

### 4-1. 実行フォルダへ移動

```
cd tutorial-01/main
```

### 4-2. 初期化
次のコマンドを実行すると ローカル に次のファイル/フォルダが保存されます。
- .terraform/              ： AWS操作用の部品
- .terraform.lock.hcl      ： Providerバージョン固定情報
```
terraform init
```

参考：
- `terraform init`: https://developer.hashicorp.com/terraform/cli/commands/init

### 4-3. 変更点確認
```
terraform plan
```

参考：
- `terraform plan`: https://developer.hashicorp.com/terraform/cli/commands/plan

### 4-4. 作成
次のコマンドを実行すると ローカル に次のファイルが保存されます。
- terraform.tfstate        ： Terraformのリソース管理台帳（現状の記録）
```
terraform apply
Enter a value: yes
```

参考：
- `terraform apply`: https://developer.hashicorp.com/terraform/cli/commands/apply

### 4-5. 作成できたか確認（AWS CLI）
```
aws s3api head-bucket --bucket "$(terraform output -raw bucket_name)"
```

参考：
- AWS CLI `s3api head-bucket`: https://docs.aws.amazon.com/cli/latest/reference/s3api/head-bucket.html
- `terraform output`: https://developer.hashicorp.com/terraform/cli/commands/output

### 4-6. 後片付け(削除)
**tutorials/01-CreateS3LocalBackend.md** を実施する場合は、**tutorials/01-CreateS3LocalBackend.md**　完了後に削除する
```
terraform destroy
Enter a value: yes
```

参考：
- `terraform destroy`: https://developer.hashicorp.com/terraform/cli/commands/destroy

---

## 5. コードの詳細解説
このチュートリアルは「ローカルに state を保存しつつ、最小構成で S3 バケットを 1 つ作る」流れになっています。  
各ファイルの役割と流れを順番に説明します。

### 5-1. まず覚える用語
- **モジュール**: 使い回せる部品の集まりです  
- **ルートモジュール**: 実際に実行する本体です  
- **state**: 作成したリソースの記録ファイルです  
- **変数**: 後から入れ替えられる値です  
- **出力**: 作成結果を取り出すための窓口です

### 5-2. フォルダ構成の意図
- `modules/s3_bucket/` は「S3 バケットを作る部品」を置く場所です  
- `main/` は「この部品を使って実際に作る場所」です  
- backend を指定していないので、state は `main/` 配下に保存されます

### 5-3. モジュール側の役割（部品側）
#### modules/s3_bucket/main.tf
- `aws_s3_bucket` は「S3 バケットを作る」という宣言です  
- `bucket = var.bucket_name` は「バケット名は変数から受け取る」という意味です  
- `force_destroy = true` は「中身があっても削除できるようにする」という意味です  
- `tags = var.tags` は「タグも変数から受け取る」という意味です  
- ここでは名前を決めず、受け取った値で作るだけにしています

#### modules/s3_bucket/variables.tf
- `bucket_name` は必須入力です（空だと作れません）  
- S3 の名前は全世界で一意なので、被らない文字列が必要です  
- `tags` は任意入力で、未指定なら空の `{}` が使われます

#### modules/s3_bucket/outputs.tf
- 作成したバケット名を外に返す設定です  
- これにより、あとで `terraform output` で名前を確認できます

### 5-4. ルートモジュール側の役割（実行側）
#### main/main.tf
- `provider "aws"` は「どの AWS を操作するか」を決めます  
- `module "demo_bucket"` は「部品を使います」という宣言です  
- `bucket_name` と `tags` をここで渡します

#### main/variables.tf
- `aws_region` はリージョンの初期値です  
- `bucket_name` は必須なので、必ず入力が必要です  
- `tags` は任意です

#### main/terraform.tfvars
- 変数に入れる具体的な値を書きます  
- ここに書くことで、毎回コマンドで入力しなくて済みます

#### main/outputs.tf
- モジュールから返ってきた値を、さらに外に出します  
- `terraform output -raw bucket_name` はここで定義した名前を使います

### 5-5. `plan` / `apply` / `destroy` と state
- `terraform plan` は「何が作られるかの予告」です  
- `terraform apply` は「実際に作る」操作です  
- 作成結果は `terraform.tfstate` に記録されます  
- `terraform destroy` は「作ったものを消す」操作です  
- state を消すと履歴が追えないため、削除は `destroy` を使います

### 5-6. `terraform.tfvars` の使いどころ
- 変数の値をファイルにまとめると入力ミスが減ります  
- `bucket_name` は環境ごとに変えることが多いので、ここに置くのが安全です

### 5-7. 出力値の活用例
- `terraform output -raw bucket_name` で作成した名前を確認できます  
- AWS CLI と組み合わせることで、作成結果を確認できます
